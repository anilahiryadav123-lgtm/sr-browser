package com.sr.browser;

import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * First-run welcome page in the UC Browser style: hero artwork, three feature lines,
 * a language switch in the corner, the agreement text and one big "Agree and Continue" button.
 * The launch splash and the default-browser prompt / tips that follow live in MainActivity.
 */
final class Intro extends FrameLayout {

    interface Done {
        void finish(String lang);
    }

    private static final int RED = 0xFFE5121B;

    private final Done done;
    private String lang;

    Intro(Context c, String startLang, Done done) {
        super(c);
        this.done = done;
        this.lang = "hi".equals(startLang) ? "hi" : "en";
        setBackgroundColor(Color.WHITE);
        setClickable(true);
        build();
    }

    private int dp(float v) {
        return Ui.dp(getContext(), v);
    }

    private String t(String en, String hi) {
        return "hi".equals(lang) ? hi : en;
    }

    /** Back key on the welcome page closes the app, like UC. */
    boolean back() {
        return false;
    }

    private void build() {
        removeAllViews();
        Context c = getContext();

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(28), dp(56), dp(28), dp(26));

        Art art = new Art(c, 0, RED, 0xFFB80F16,
                new int[]{R.drawable.ic_bolt, R.drawable.ic_shield, R.drawable.ic_download, R.drawable.ic_video});
        col.addView(art, new LinearLayout.LayoutParams(-1, 0, 1.15f));

        TextView title = Ui.text(c, t("Welcome to S.R Browser", "S.R Browser में आपका स्वागत है"), 25, 0xFF14161B, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(8), 0, dp(6));
        col.addView(title);
        TextView sub = Ui.text(c, t("Faster speed, Made in India", "तेज़ स्पीड, भारत में बना"), 15, 0xFF8A90A0, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, dp(18));
        col.addView(sub);

        LinearLayout feats = new LinearLayout(c);
        feats.setOrientation(LinearLayout.VERTICAL);
        feats.addView(feat(R.drawable.ic_bolt, 0xFFFF7A2F, t("Fast browsing, even on 2G/3G", "धीमे नेटवर्क पर भी तेज़ ब्राउज़िंग")));
        feats.addView(feat(R.drawable.ic_shield, 0xFF16A34A, t("Built-in ad and pop-up blocker", "इन-बिल्ट एड और पॉप-अप ब्लॉकर")));
        feats.addView(feat(R.drawable.ic_download, 0xFF2563EB, t("One-tap video download", "एक टैप में वीडियो डाउनलोड")));
        col.addView(feats, new LinearLayout.LayoutParams(-2, -2));

        View grow = new View(c);
        col.addView(grow, new LinearLayout.LayoutParams(-1, 0, 0.35f));

        col.addView(terms(), new LinearLayout.LayoutParams(-1, -2));

        final TextView go = Ui.text(c, t("Agree and Continue", "सहमत हैं, आगे बढ़ें"), 17, Color.WHITE, true);
        go.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xFFFF4B2B, RED});
        g.setCornerRadius(dp(27));
        go.setBackground(g);
        go.setElevation(dp(3));
        go.setOnClickListener(v -> {
            go.setEnabled(false);
            animate().alpha(0f).setDuration(240).withEndAction(() -> done.finish(lang)).start();
        });
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, dp(54));
        gp.topMargin = dp(14);
        col.addView(go, gp);

        TextView india = Ui.text(c, "🇮🇳  " + t("Made in India", "भारत में निर्मित"), 13, 0xFF6B7180, true);
        india.setGravity(Gravity.CENTER);
        india.setPadding(0, dp(14), 0, 0);
        col.addView(india);

        addView(col, new LayoutParams(-1, -1));

        // Language switch, top right, like UC
        final TextView lang = Ui.text(c, ("hi".equals(this.lang) ? "हिन्दी" : "English") + "  ▾", 14, 0xFF3B4150, true);
        lang.setPadding(dp(14), dp(8), dp(14), dp(8));
        GradientDrawable lg = new GradientDrawable();
        lg.setCornerRadius(dp(18));
        lg.setColor(0xFFF2F3F6);
        lang.setBackground(lg);
        lang.setOnClickListener(v -> new AlertDialog.Builder(getContext())
                .setTitle("Language / भाषा")
                .setSingleChoiceItems(new String[]{"English", "हिन्दी"}, "hi".equals(this.lang) ? 1 : 0, (d, which) -> {
                    this.lang = which == 1 ? "hi" : "en";
                    d.dismiss();
                    build();
                }).show());
        LayoutParams lp = new LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        lp.topMargin = dp(16);
        lp.rightMargin = dp(16);
        addView(lang, lp);

        col.setAlpha(0f);
        col.setTranslationY(dp(24));
        col.animate().alpha(1f).translationY(0).setDuration(420).setInterpolator(new DecelerateInterpolator()).start();
        art.setScaleX(0.8f);
        art.setScaleY(0.8f);
        art.animate().scaleX(1f).scaleY(1f).setDuration(600).setInterpolator(new OvershootInterpolator(1.3f)).start();
    }

    private View feat(int icon, int color, String text) {
        Context c = getContext();
        LinearLayout r = new LinearLayout(c);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(0, dp(5), 0, dp(5));
        FrameLayout b = new FrameLayout(c);
        GradientDrawable o = new GradientDrawable();
        o.setShape(GradientDrawable.OVAL);
        o.setColor(color);
        b.setBackground(o);
        b.addView(Ui.icon(c, icon, 16, Color.WHITE), new FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(28), dp(28));
        bp.rightMargin = dp(12);
        r.addView(b, bp);
        r.addView(Ui.text(c, text, 15, 0xFF3B4150, false));
        return r;
    }

    private TextView terms() {
        final String ua = t("User Agreement", "यूज़र एग्रीमेंट");
        final String pp = t("Privacy Policy", "प्राइवेसी पॉलिसी");
        String full = "hi".equals(lang)
                ? "आगे बढ़कर आप S.R Browser के " + ua + " और " + pp + " को स्वीकार करते हैं।"
                : "By tapping Agree and Continue, you accept the " + ua + " and " + pp + ".";
        SpannableString ss = new SpannableString(full);
        link(ss, full, ua, () -> info(getContext(), lang, true));
        link(ss, full, pp, () -> info(getContext(), lang, false));
        TextView tv = Ui.text(getContext(), "", 12.5f, 0xFF8A90A0, false);
        tv.setText(ss);
        tv.setGravity(Gravity.CENTER);
        tv.setMovementMethod(LinkMovementMethod.getInstance());
        tv.setHighlightColor(Color.TRANSPARENT);
        return tv;
    }

    private static void link(SpannableString ss, String full, String word, final Runnable r) {
        int s = full.indexOf(word);
        if (s < 0) return;
        ss.setSpan(new ClickableSpan() {
            @Override
            public void onClick(View w) {
                r.run();
            }

            @Override
            public void updateDrawState(TextPaint p) {
                p.setColor(RED);
                p.setUnderlineText(false);
                p.setFakeBoldText(true);
            }
        }, s, s + word.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    /** User Agreement / Privacy Policy text, used here and in Settings. */
    static void info(Context c, String lang, boolean agreement) {
        boolean hi = "hi".equals(lang);
        String title = agreement ? (hi ? "यूज़र एग्रीमेंट" : "User Agreement") : (hi ? "प्राइवेसी पॉलिसी" : "Privacy Policy");
        String msg = agreement
                ? (hi ? "S.R Browser मुफ़्त है। कृपया इसे ज़िम्मेदारी से इस्तेमाल करें और जिन वेबसाइट पर जाएं उनके नियम मानें। सिर्फ़ वही वीडियो और फ़ाइलें डाउनलोड करें जिनकी आपको अनुमति है। डाउनलोड आपके फ़ोन में सेव होते हैं और उनकी ज़िम्मेदारी आपकी है।"
                : "S.R Browser is free to use. Please use it responsibly and follow the rules of the websites you visit. Only download videos and files you have the right to save. Downloads are stored on your phone and you are responsible for them.")
                : (hi ? "S.R Browser आपकी हिस्ट्री, बुकमार्क, नोट्स, डाउनलोड लिस्ट और सेटिंग्स सिर्फ़ इसी फ़ोन में रखता है। हम आपका डेटा नहीं बेचते और किसी सर्वर पर नहीं भेजते। इन्कॉग्निटो मोड में हिस्ट्री सेव नहीं होती। सब कुछ सेटिंग्स > रिकॉर्ड साफ़ करें से हटा सकते हैं।"
                : "S.R Browser keeps your history, bookmarks, notes, download list and settings only on this phone. We do not sell your data or send it to any server. Incognito mode does not save history. You can clear everything from Settings > Clear Records.");
        new AlertDialog.Builder(c).setTitle(title).setMessage(msg).setPositiveButton(hi ? "ठीक है" : "OK", null).show();
    }

    /* ------------------------------------------------------------------ */
    /* Animated hero artwork                                              */
    /* ------------------------------------------------------------------ */

    static final class Art extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int c1, c2;
        private final Drawable main;
        private final Drawable[] sats;
        private Bitmap logo;
        private final RectF rf = new RectF();
        private final Rect r = new Rect();
        private ValueAnimator loop;
        private float phase = 0f;
        private Shader glow, disc;

        Art(Context c, int iconRes, int c1, int c2, int[] satRes) {
            super(c);
            this.c1 = c1;
            this.c2 = c2;
            if (iconRes != 0) {
                main = c.getDrawable(iconRes).mutate();
                main.setTint(Color.WHITE);
            } else {
                main = null;
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inSampleSize = 2;
                logo = BitmapFactory.decodeResource(c.getResources(), R.drawable.intro_logo, o);
            }
            sats = new Drawable[satRes.length];
            for (int i = 0; i < satRes.length; i++) {
                sats[i] = c.getDrawable(satRes[i]).mutate();
                sats[i].setTint(c1);
            }
            ring.setStyle(Paint.Style.STROKE);
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            loop = ValueAnimator.ofFloat(0f, 1f);
            loop.setDuration(4200);
            loop.setRepeatCount(ValueAnimator.INFINITE);
            loop.setInterpolator(new LinearInterpolator());
            loop.addUpdateListener(a -> {
                phase = (float) a.getAnimatedValue();
                if (getVisibility() == VISIBLE && isShown()) invalidate();
            });
            loop.start();
        }

        @Override
        protected void onDetachedFromWindow() {
            if (loop != null) loop.cancel();
            loop = null;
            super.onDetachedFromWindow();
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            float cx = w / 2f, cy = h / 2f;
            float R = Math.min(w, h) * 0.42f;
            if (R <= 0) return;
            glow = new RadialGradient(cx, cy, R * 1.15f, (c1 & 0x00FFFFFF) | 0x33000000,
                    (c1 & 0x00FFFFFF), Shader.TileMode.CLAMP);
            float cr = R * 0.52f;
            disc = new LinearGradient(cx - cr, cy - cr, cx + cr, cy + cr, c1, c2, Shader.TileMode.CLAMP);
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            float cx = w / 2f, cy = h / 2f;
            float R = Math.min(w, h) * 0.42f;
            if (R <= 0) return;
            float dens = getResources().getDisplayMetrics().density;

            // soft glow
            if (glow == null || disc == null) return;
            p.setShader(glow);
            cv.drawCircle(cx, cy, R * 1.15f, p);
            p.setShader(null);

            // pulsing rings
            for (int i = 0; i < 3; i++) {
                float f = (phase + i / 3f) % 1f;
                float rr = R * (0.55f + 0.55f * f);
                int alpha = (int) (110 * (1f - f));
                ring.setStrokeWidth(2f * dens);
                ring.setColor((alpha << 24) | (c1 & 0x00FFFFFF));
                cv.drawCircle(cx, cy, rr, ring);
            }

            // centre disc
            float cr = R * 0.52f;
            float bob = (float) Math.sin(phase * Math.PI * 2) * 4f * dens;
            p.setShader(disc);
            p.setShadowLayer(14f * dens, 0, 6f * dens, (c2 & 0x00FFFFFF) | 0x55000000);
            cv.drawCircle(cx, cy + bob, cr, p);
            p.clearShadowLayer();
            p.setShader(null);
            if (main != null) {
                int ir = (int) (cr * 0.55f);
                r.set((int) (cx - ir), (int) (cy + bob - ir), (int) (cx + ir), (int) (cy + bob + ir));
                main.setBounds(r);
                main.draw(cv);
            } else if (logo != null) {
                p.setColor(Color.WHITE);
                cv.drawCircle(cx, cy + bob, cr * 0.94f, p);
                float lr = cr * 0.86f;
                rf.set(cx - lr, cy + bob - lr, cx + lr, cy + bob + lr);
                cv.drawBitmap(logo, null, rf, p);
            }

            // orbiting satellites
            float orbit = R * 0.88f;
            for (int i = 0; i < sats.length; i++) {
                double a = Math.PI * 2 * (phase * 0.35f + i / (float) sats.length) - Math.PI / 2;
                float sx = cx + (float) Math.cos(a) * orbit;
                float sy = cy + (float) Math.sin(a) * orbit * 0.92f;
                float sr = R * 0.16f;
                p.setColor(Color.WHITE);
                p.setShadowLayer(8f * dens, 0, 3f * dens, 0x33000000);
                cv.drawCircle(sx, sy, sr, p);
                p.clearShadowLayer();
                int ir = (int) (sr * 0.58f);
                r.set((int) (sx - ir), (int) (sy - ir), (int) (sx + ir), (int) (sy + ir));
                sats[i].setBounds(r);
                sats[i].draw(cv);
            }

            // sparkles
            p.setColor((c1 & 0x00FFFFFF) | 0x99000000);
            for (int i = 0; i < 6; i++) {
                double a = Math.PI * 2 * (i / 6f) + phase * Math.PI;
                float d = R * (1.05f + 0.08f * (float) Math.sin(phase * Math.PI * 2 + i));
                float s = dens * (2f + (i % 3));
                cv.drawCircle(cx + (float) Math.cos(a) * d, cy + (float) Math.sin(a) * d, s, p);
            }
        }
    }
}
