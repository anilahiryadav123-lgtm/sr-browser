package com.sr.browser;

import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * First-run intro in the UC Browser style: language choice, swipeable feature
 * slides with animated artwork, page dots, Skip, and a final Agree &amp; Continue page.
 * All artwork is drawn in code with S.R Browser's own colours and logo.
 */
final class Intro extends FrameLayout {

    interface Done {
        void finish(String lang);
    }

    private static final int RED = 0xFFE5121B;

    private final Done done;
    private String lang;
    private int step = 0;              // 0 = language, 1 = slides
    private FrameLayout stage;         // current step's content
    private Pager pager;
    private LinearLayout dots;
    private TextView nextBtn, skipBtn, terms;

    Intro(Context c, String startLang, Done done) {
        super(c);
        this.done = done;
        this.lang = "hi".equals(startLang) ? "hi" : "en";
        setBackgroundColor(Color.WHITE);
        setClickable(true);
        stage = new FrameLayout(c);
        addView(stage, new LayoutParams(-1, -1));
        showLanguage();
    }

    private int dp(float v) {
        return Ui.dp(getContext(), v);
    }

    private boolean hi() {
        return "hi".equals(lang);
    }

    private String t(String en, String hiText) {
        return hi() ? hiText : en;
    }

    /** Back key: go to the previous slide or step. Returns false when the intro should close the app. */
    boolean back() {
        if (step == 1 && pager != null && pager.index > 0) {
            pager.go(pager.index - 1, true);
            return true;
        }
        if (step == 1) {
            showLanguage();
            return true;
        }
        return false;
    }

    /* ------------------------------------------------------------------ */
    /* Step 1: language                                                   */
    /* ------------------------------------------------------------------ */

    private void showLanguage() {
        step = 0;
        stage.removeAllViews();
        Context c = getContext();

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(26), dp(40), dp(26), dp(28));

        ImageView logo = new ImageView(c);
        logo.setImageResource(R.drawable.intro_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        col.addView(logo, new LinearLayout.LayoutParams(dp(150), dp(150)));

        TextView title = Ui.text(c, "Choose your language", 23, 0xFF1A1D23, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(18), 0, dp(4));
        col.addView(title);
        TextView sub = Ui.text(c, "अपनी भाषा चुनें", 16, 0xFF6B7180, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, dp(26));
        col.addView(sub);

        final List<View> cards = new ArrayList<>();
        final String[][] langs = {{"en", "English", "Hello"}, {"hi", "हिन्दी", "नमस्ते"}};
        for (final String[] l : langs) {
            final LinearLayout card = new LinearLayout(c);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(18), dp(16), dp(18), dp(16));
            card.setTag(l[0]);
            FrameLayout badge = new FrameLayout(c);
            badge.setBackground(oval(0xFFFFEDEE));
            TextView bl = Ui.text(c, l[0].equals("en") ? "A" : "अ", 19, RED, true);
            bl.setGravity(Gravity.CENTER);
            badge.addView(bl, new FrameLayout.LayoutParams(-1, -1));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(44), dp(44));
            bp.rightMargin = dp(14);
            card.addView(badge, bp);
            LinearLayout txt = new LinearLayout(c);
            txt.setOrientation(LinearLayout.VERTICAL);
            txt.addView(Ui.text(c, l[1], 18, 0xFF1A1D23, true));
            txt.addView(Ui.text(c, l[2], 13.5f, 0xFF8A90A0, false));
            card.addView(txt, new LinearLayout.LayoutParams(0, -2, 1));
            ImageView tick = Ui.icon(c, R.drawable.ic_check, 22, Color.WHITE);
            FrameLayout tickBox = new FrameLayout(c);
            tickBox.addView(tick, new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER));
            tickBox.setTag("tick");
            card.addView(tickBox, new LinearLayout.LayoutParams(dp(28), dp(28)));
            card.setOnClickListener(v -> {
                lang = l[0];
                paintLangCards(cards);
            });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
            cp.bottomMargin = dp(12);
            col.addView(card, cp);
            cards.add(card);
        }
        paintLangCards(cards);

        View grow = new View(c);
        col.addView(grow, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView go = button(t("Continue", "आगे बढ़ें"));
        go.setOnClickListener(v -> showSlides());
        col.addView(go, new LinearLayout.LayoutParams(-1, dp(54)));

        stage.addView(col, new FrameLayout.LayoutParams(-1, -1));
        enter(col);
    }

    private void paintLangCards(List<View> cards) {
        for (View v : cards) {
            boolean on = lang.equals(v.getTag());
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(16));
            g.setColor(on ? 0xFFFFF5F5 : 0xFFF4F5F8);
            g.setStroke(dp(on ? 2 : 1), on ? RED : 0xFFE4E7EE);
            v.setBackground(g);
            View tick = v.findViewWithTag("tick");
            if (tick != null) {
                GradientDrawable o = new GradientDrawable();
                o.setShape(GradientDrawable.OVAL);
                if (on) o.setColor(RED);
                else {
                    o.setColor(Color.WHITE);
                    o.setStroke(dp(2), 0xFFCDD1DA);
                }
                tick.setBackground(o);
                ((FrameLayout) tick).getChildAt(0).setVisibility(on ? View.VISIBLE : View.INVISIBLE);
            }
        }
    }

    /* ------------------------------------------------------------------ */
    /* Step 2: slides                                                     */
    /* ------------------------------------------------------------------ */

    private void showSlides() {
        step = 1;
        stage.removeAllViews();
        Context c = getContext();

        final Object[][] slides = {
                {R.drawable.ic_bolt, 0xFFFF7A2F, 0xFFE5121B,
                        t("Super Fast Browsing", "सुपर फ़ास्ट ब्राउज़िंग"),
                        t("Pages open in a flash, even on a slow 2G or 3G network.", "धीमे 2G या 3G नेटवर्क पर भी पेज तुरंत खुलते हैं।"),
                        new int[]{R.drawable.ic_globe, R.drawable.ic_search, R.drawable.ic_refresh}},
                {R.drawable.ic_shield, 0xFF22C55E, 0xFF0E9F6E,
                        t("Block Annoying Ads", "परेशान करने वाले विज्ञापन बंद"),
                        t("Built-in ad and pop-up blocker keeps every page clean and safe.", "इन-बिल्ट एड और पॉप-अप ब्लॉकर हर पेज को साफ़ और सुरक्षित रखता है।"),
                        new int[]{R.drawable.ic_adblock, R.drawable.ic_close, R.drawable.ic_check}},
                {R.drawable.ic_download, 0xFF3B82F6, 0xFF1D4ED8,
                        t("Fast Video Downloads", "तेज़ वीडियो डाउनलोड"),
                        t("Download videos, songs and files in one tap and watch them offline.", "एक टैप में वीडियो, गाने और फ़ाइलें डाउनलोड करें, बाद में बिना नेट देखें।"),
                        new int[]{R.drawable.ic_video, R.drawable.ic_dl_hex, R.drawable.ic_star}},
                {R.drawable.ic_ghost, 0xFF8B5CF6, 0xFF6D28D9,
                        t("Private & Night Mode", "प्राइवेट और नाइट मोड"),
                        t("Browse in incognito, switch to night mode and save your data.", "इन्कॉग्निटो में ब्राउज़ करें, नाइट मोड चलाएं और डेटा बचाएं।"),
                        new int[]{R.drawable.ic_moon, R.drawable.ic_mask, R.drawable.ic_cloud}},
                {0, RED, 0xFFB80F16,
                        t("Welcome to S.R Browser", "S.R Browser में आपका स्वागत है"),
                        t("Fast. Simple. Made in India.", "तेज़। आसान। भारत में बना।"),
                        new int[]{R.drawable.ic_bolt, R.drawable.ic_shield, R.drawable.ic_download}}
        };

        pager = new Pager(c);
        for (Object[] s : slides) pager.addPage(slidePage(s));
        stage.addView(pager, new FrameLayout.LayoutParams(-1, -1));

        // Skip (top right)
        skipBtn = Ui.text(c, t("Skip", "छोड़ें"), 15, 0xFF6B7180, true);
        skipBtn.setPadding(dp(16), dp(8), dp(16), dp(8));
        skipBtn.setBackground(round(0xFFF1F2F5, 18));
        skipBtn.setOnClickListener(v -> pager.go(pager.count() - 1, true));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        sp.topMargin = dp(18);
        sp.rightMargin = dp(18);
        stage.addView(skipBtn, sp);

        // Bottom: dots, terms, button
        LinearLayout bottom = new LinearLayout(c);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setGravity(Gravity.CENTER_HORIZONTAL);
        bottom.setPadding(dp(26), 0, dp(26), dp(28));

        dots = new LinearLayout(c);
        dots.setOrientation(LinearLayout.HORIZONTAL);
        dots.setGravity(Gravity.CENTER);
        for (int i = 0; i < pager.count(); i++) {
            View d = new View(c);
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(7), dp(7));
            dl.leftMargin = dp(4);
            dl.rightMargin = dp(4);
            dots.addView(d, dl);
        }
        LinearLayout.LayoutParams dsp = new LinearLayout.LayoutParams(-2, dp(10));
        dsp.bottomMargin = dp(22);
        bottom.addView(dots, dsp);

        terms = termsText();
        terms.setPadding(0, 0, 0, dp(12));
        bottom.addView(terms, new LinearLayout.LayoutParams(-1, -2));

        nextBtn = button(t("Next", "आगे"));
        nextBtn.setOnClickListener(v -> {
            if (pager.index < pager.count() - 1) pager.go(pager.index + 1, true);
            else finishIntro();
        });
        bottom.addView(nextBtn, new LinearLayout.LayoutParams(-1, dp(54)));

        stage.addView(bottom, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));

        pager.listener = this::onPage;
        onPage(0);
    }

    private void onPage(int i) {
        boolean last = i == pager.count() - 1;
        for (int k = 0; k < dots.getChildCount(); k++) {
            View d = dots.getChildAt(k);
            boolean on = k == i;
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) d.getLayoutParams();
            lp.width = dp(on ? 22 : 7);
            d.setLayoutParams(lp);
            d.setBackground(round(on ? RED : 0xFFD9DCE3, 4));
        }
        skipBtn.animate().alpha(last ? 0f : 1f).setDuration(200).start();
        skipBtn.setClickable(!last);
        terms.setVisibility(last ? View.VISIBLE : View.INVISIBLE);
        nextBtn.setText(last ? t("Agree & Continue", "सहमत हैं, आगे बढ़ें") : t("Next", "आगे"));
        View page = pager.page(i);
        if (page != null) {
            View txt = page.findViewWithTag("txt");
            if (txt != null) {
                txt.setAlpha(0f);
                txt.setTranslationY(dp(26));
                txt.animate().alpha(1f).translationY(0).setStartDelay(90).setDuration(420)
                        .setInterpolator(new DecelerateInterpolator()).start();
            }
            View art = page.findViewWithTag("art");
            if (art != null) {
                art.setScaleX(0.82f);
                art.setScaleY(0.82f);
                art.animate().scaleX(1f).scaleY(1f).setDuration(520)
                        .setInterpolator(new OvershootInterpolator(1.4f)).start();
            }
        }
    }

    private View slidePage(Object[] s) {
        Context c = getContext();
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(30), dp(70), dp(30), dp(190));

        Art art = new Art(c, (Integer) s[0], (Integer) s[1], (Integer) s[2], (int[]) s[5]);
        art.setTag("art");
        col.addView(art, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout txt = new LinearLayout(c);
        txt.setOrientation(LinearLayout.VERTICAL);
        txt.setGravity(Gravity.CENTER_HORIZONTAL);
        txt.setTag("txt");
        TextView title = Ui.text(c, (String) s[3], 26, 0xFF14161B, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(20), 0, dp(10));
        txt.addView(title);
        TextView sub = Ui.text(c, (String) s[4], 16, 0xFF6B7180, false);
        sub.setGravity(Gravity.CENTER);
        sub.setLineSpacing(dp(3), 1f);
        txt.addView(sub);
        if ((Integer) s[0] == 0) {
            LinearLayout india = indiaLine();
            india.setPadding(0, dp(14), 0, 0);
            txt.addView(india);
        }
        col.addView(txt, new LinearLayout.LayoutParams(-1, -2));
        return col;
    }

    private LinearLayout indiaLine() {
        Context c = getContext();
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER);
        LinearLayout flag = new LinearLayout(c);
        flag.setOrientation(LinearLayout.VERTICAL);
        for (int col : new int[]{0xFFFF9933, 0xFFFFFFFF, 0xFF138808}) {
            View s = new View(c);
            s.setBackgroundColor(col);
            flag.addView(s, new LinearLayout.LayoutParams(dp(20), dp(4)));
        }
        flag.setBackground(round(0xFFDDDDDD, 2));
        flag.setPadding(dp(1), dp(1), dp(1), dp(1));
        l.addView(flag);
        TextView t = Ui.text(c, t("Made in India", "भारत में निर्मित"), 14, 0xFF1A1D23, true);
        t.setPadding(dp(8), 0, 0, 0);
        l.addView(t);
        return l;
    }

    private TextView termsText() {
        final String ua = t("User Agreement", "यूज़र एग्रीमेंट");
        final String pp = t("Privacy Policy", "प्राइवेसी पॉलिसी");
        String full = hi()
                ? "आगे बढ़कर आप S.R Browser के " + ua + " और " + pp + " से सहमत होते हैं।"
                : "By continuing, you agree to S.R Browser's " + ua + " and " + pp + ".";
        SpannableString ss = new SpannableString(full);
        link(ss, full, ua, () -> info(ua, t(
                "S.R Browser is free to use. Please use it responsibly and follow the rules of the websites you visit. Downloads are saved on your phone and you are responsible for the files you download.",
                "S.R Browser मुफ़्त है। कृपया इसे ज़िम्मेदारी से इस्तेमाल करें और जिन वेबसाइट पर जाएं उनके नियम मानें। डाउनलोड आपके फ़ोन में सेव होते हैं और फ़ाइलों की ज़िम्मेदारी आपकी है।")));
        link(ss, full, pp, () -> info(pp, t(
                "S.R Browser keeps your history, bookmarks, notes and settings only on this phone. We do not sell your data. Incognito mode does not save history. You can clear everything from Settings > Clear Records.",
                "S.R Browser आपकी हिस्ट्री, बुकमार्क, नोट्स और सेटिंग्स सिर्फ़ इसी फ़ोन में रखता है। हम आपका डेटा नहीं बेचते। इन्कॉग्निटो मोड में हिस्ट्री सेव नहीं होती। सब कुछ सेटिंग्स > रिकॉर्ड साफ़ करें से हटा सकते हैं।")));
        TextView tv = Ui.text(getContext(), "", 12.5f, 0xFF8A90A0, false);
        tv.setText(ss);
        tv.setGravity(Gravity.CENTER);
        tv.setMovementMethod(LinkMovementMethod.getInstance());
        tv.setHighlightColor(Color.TRANSPARENT);
        return tv;
    }

    private void link(SpannableString ss, String full, String word, final Runnable r) {
        int s = full.indexOf(word);
        if (s < 0) return;
        ss.setSpan(new ClickableSpan() {
            @Override
            public void onClick(View w) {
                r.run();
            }

            @Override
            public void updateDrawState(TextPaint p) {
                p.setColor(RED);
                p.setUnderlineText(false);
                p.setFakeBoldText(true);
            }
        }, s, s + word.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private void info(String title, String msg) {
        new AlertDialog.Builder(getContext()).setTitle(title).setMessage(msg)
                .setPositiveButton(t("OK", "ठीक है"), null).show();
    }

    private void finishIntro() {
        nextBtn.setEnabled(false);
        animate().alpha(0f).translationY(-dp(30)).setDuration(260).withEndAction(() -> done.finish(lang)).start();
    }

    /* ------------------------------------------------------------------ */
    /* Helpers                                                            */
    /* ------------------------------------------------------------------ */

    private TextView button(String label) {
        TextView b = Ui.text(getContext(), label, 17, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xFFFF4B2B, RED});
        g.setCornerRadius(dp(27));
        b.setBackground(g);
        b.setElevation(dp(3));
        return b;
    }

    private GradientDrawable round(int color, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    private GradientDrawable oval(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    private void enter(View v) {
        v.setAlpha(0f);
        v.setTranslationY(dp(20));
        v.animate().alpha(1f).translationY(0).setDuration(380).setInterpolator(new DecelerateInterpolator()).start();
    }

    /* ------------------------------------------------------------------ */
    /* Swipe pager                                                        */
    /* ------------------------------------------------------------------ */

    interface PageListener {
        void on(int index);
    }

    static final class Pager extends FrameLayout {
        final List<View> pages = new ArrayList<>();
        int index = 0;
        PageListener listener;
        private float downX, downY, offset;
        private boolean dragging;
        private VelocityTracker vt;
        private ValueAnimator anim;
        private final int slop;

        Pager(Context c) {
            super(c);
            slop = ViewConfiguration.get(c).getScaledTouchSlop();
        }

        void addPage(View v) {
            pages.add(v);
            addView(v, new LayoutParams(-1, -1));
            place();
        }

        int count() {
            return pages.size();
        }

        View page(int i) {
            return i >= 0 && i < pages.size() ? pages.get(i) : null;
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            place();
        }

        private void place() {
            int w = getWidth();
            for (int i = 0; i < pages.size(); i++) {
                View p = pages.get(i);
                float x = (i - index) * w + offset;
                p.setTranslationX(x);
                p.setVisibility(Math.abs(x) < w + 1 ? View.VISIBLE : View.INVISIBLE);
            }
        }

        void go(int target, boolean animateIt) {
            target = Math.max(0, Math.min(pages.size() - 1, target));
            final int w = getWidth();
            if (anim != null) anim.cancel();
            final float from = offset + (index - target) * (float) w;
            final boolean changed = target != index;
            index = target;
            if (!animateIt || w == 0) {
                offset = 0;
                place();
            } else {
                offset = from;
                anim = ValueAnimator.ofFloat(from, 0f);
                anim.setDuration(320);
                anim.setInterpolator(new DecelerateInterpolator(1.6f));
                anim.addUpdateListener(a -> {
                    offset = (float) a.getAnimatedValue();
                    place();
                });
                anim.start();
            }
            if (changed && listener != null) listener.on(index);
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getX();
                    downY = e.getY();
                    dragging = false;
                    return false;
                case MotionEvent.ACTION_MOVE:
                    float dx = Math.abs(e.getX() - downX), dy = Math.abs(e.getY() - downY);
                    if (dx > slop && dx > dy) {
                        dragging = true;
                        downX = e.getX();
                        if (anim != null) anim.cancel();
                        return true;
                    }
                    return false;
                default:
                    return false;
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (vt == null) vt = VelocityTracker.obtain();
            vt.addMovement(e);
            int w = Math.max(1, getWidth());
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getX();
                    if (anim != null) anim.cancel();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float d = e.getX() - downX;
                    if ((index == 0 && d > 0) || (index == pages.size() - 1 && d < 0)) d *= 0.3f;
                    offset = d;
                    place();
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    vt.computeCurrentVelocity(1000);
                    float vx = vt.getXVelocity();
                    vt.recycle();
                    vt = null;
                    dragging = false;
                    int target = index;
                    if (offset < -w * 0.25f || vx < -900) target = index + 1;
                    else if (offset > w * 0.25f || vx > 900) target = index - 1;
                    target = Math.max(0, Math.min(pages.size() - 1, target));
                    if (target == index) {
                        final float from = offset;
                        if (anim != null) anim.cancel();
                        anim = ValueAnimator.ofFloat(from, 0f);
                        anim.setDuration(240);
                        anim.setInterpolator(new DecelerateInterpolator());
                        anim.addUpdateListener(a -> {
                            offset = (float) a.getAnimatedValue();
                            place();
                        });
                        anim.start();
                    } else {
                        go(target, true);
                    }
                    return true;
                default:
                    return true;
            }
        }
    }

    /* ------------------------------------------------------------------ */
    /* Animated artwork                                                   */
    /* ------------------------------------------------------------------ */

    static final class Art extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int c1, c2;
        private final Drawable main;
        private final Drawable[] sats;
        private Bitmap logo;
        private final RectF rf = new RectF();
        private final Rect r = new Rect();
        private ValueAnimator loop;
        private float phase = 0f;
        private Shader glow, disc;

        Art(Context c, int iconRes, int c1, int c2, int[] satRes) {
            super(c);
            this.c1 = c1;
            this.c2 = c2;
            if (iconRes != 0) {
                main = c.getDrawable(iconRes).mutate();
                main.setTint(Color.WHITE);
            } else {
                main = null;
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inSampleSize = 2;
                logo = BitmapFactory.decodeResource(c.getResources(), R.drawable.intro_logo, o);
            }
            sats = new Drawable[satRes.length];
            for (int i = 0; i < satRes.length; i++) {
                sats[i] = c.getDrawable(satRes[i]).mutate();
                sats[i].setTint(c1);
            }
            ring.setStyle(Paint.Style.STROKE);
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            loop = ValueAnimator.ofFloat(0f, 1f);
            loop.setDuration(4200);
            loop.setRepeatCount(ValueAnimator.INFINITE);
            loop.setInterpolator(new LinearInterpolator());
            loop.addUpdateListener(a -> {
                phase = (float) a.getAnimatedValue();
                if (getVisibility() == VISIBLE && isShown()) invalidate();
            });
            loop.start();
        }

        @Override
        protected void onDetachedFromWindow() {
            if (loop != null) loop.cancel();
            loop = null;
            super.onDetachedFromWindow();
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            float cx = w / 2f, cy = h / 2f;
            float R = Math.min(w, h) * 0.42f;
            if (R <= 0) return;
            glow = new RadialGradient(cx, cy, R * 1.15f, (c1 & 0x00FFFFFF) | 0x33000000,
                    (c1 & 0x00FFFFFF), Shader.TileMode.CLAMP);
            float cr = R * 0.52f;
            disc = new LinearGradient(cx - cr, cy - cr, cx + cr, cy + cr, c1, c2, Shader.TileMode.CLAMP);
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            float cx = w / 2f, cy = h / 2f;
            float R = Math.min(w, h) * 0.42f;
            if (R <= 0) return;
            float dens = getResources().getDisplayMetrics().density;

            // soft glow
            if (glow == null || disc == null) return;
            p.setShader(glow);
            cv.drawCircle(cx, cy, R * 1.15f, p);
            p.setShader(null);

            // pulsing rings
            for (int i = 0; i < 3; i++) {
                float f = (phase + i / 3f) % 1f;
                float rr = R * (0.55f + 0.55f * f);
                int alpha = (int) (110 * (1f - f));
                ring.setStrokeWidth(2f * dens);
                ring.setColor((alpha << 24) | (c1 & 0x00FFFFFF));
                cv.drawCircle(cx, cy, rr, ring);
            }

            // centre disc
            float cr = R * 0.52f;
            float bob = (float) Math.sin(phase * Math.PI * 2) * 4f * dens;
            p.setShader(disc);
            p.setShadowLayer(14f * dens, 0, 6f * dens, (c2 & 0x00FFFFFF) | 0x55000000);
            cv.drawCircle(cx, cy + bob, cr, p);
            p.clearShadowLayer();
            p.setShader(null);
            if (main != null) {
                int ir = (int) (cr * 0.55f);
                r.set((int) (cx - ir), (int) (cy + bob - ir), (int) (cx + ir), (int) (cy + bob + ir));
                main.setBounds(r);
                main.draw(cv);
            } else if (logo != null) {
                p.setColor(Color.WHITE);
                cv.drawCircle(cx, cy + bob, cr * 0.94f, p);
                float lr = cr * 0.86f;
                rf.set(cx - lr, cy + bob - lr, cx + lr, cy + bob + lr);
                cv.drawBitmap(logo, null, rf, p);
            }

            // orbiting satellites
            float orbit = R * 0.88f;
            for (int i = 0; i < sats.length; i++) {
                double a = Math.PI * 2 * (phase * 0.35f + i / (float) sats.length) - Math.PI / 2;
                float sx = cx + (float) Math.cos(a) * orbit;
                float sy = cy + (float) Math.sin(a) * orbit * 0.92f;
                float sr = R * 0.16f;
                p.setColor(Color.WHITE);
                p.setShadowLayer(8f * dens, 0, 3f * dens, 0x33000000);
                cv.drawCircle(sx, sy, sr, p);
                p.clearShadowLayer();
                int ir = (int) (sr * 0.58f);
                r.set((int) (sx - ir), (int) (sy - ir), (int) (sx + ir), (int) (sy + ir));
                sats[i].setBounds(r);
                sats[i].draw(cv);
            }

            // sparkles
            p.setColor((c1 & 0x00FFFFFF) | 0x99000000);
            for (int i = 0; i < 6; i++) {
                double a = Math.PI * 2 * (i / 6f) + phase * Math.PI;
                float d = R * (1.05f + 0.08f * (float) Math.sin(phase * Math.PI * 2 + i));
                float s = dens * (2f + (i % 3));
                cv.drawCircle(cx + (float) Math.cos(a) * d, cy + (float) Math.sin(a) * d, s, p);
            }
        }
    }
}
