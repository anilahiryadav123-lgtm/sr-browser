package com.sr.browser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.Dialog;
import android.app.role.RoleManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.Gravity;
import android.view.View;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.JsResult;
import android.webkit.WebViewClient;
import android.webkit.WebViewDatabase;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/** S.R Browser: a UC style browser built on Android WebView. Made in India. */
public class MainActivity extends Activity {

    interface Renderer {
        void render(LinearLayout body);
    }

    interface BoolCb {
        void on(boolean v);
    }

    static final class Row {
        final String title, sub;
        final int icon;
        final Runnable click, delete;

        Row(String title, String sub, int icon, Runnable click, Runnable delete) {
            this.title = title;
            this.sub = sub;
            this.icon = icon;
            this.click = click;
            this.delete = delete;
        }
    }

    static final class Tab {
        WebView web;
        String title = "";
        String url = "";
        boolean home = true;
        Bitmap thumb;
    }

    static final class PanelState {
        LinearLayout view;
        LinearLayout body;
        Renderer renderer;
        String id = "";
    }

    private static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    private static final int REQ_FILE = 11;
    private static final int REQ_PHOTO = 12;
    private static final int PURPLE = 0xFF7C5CF0;

    private static final String[][] SITES = {
            {"gg", "Google", "https://www.google.com"},
            {"yt", "YouTube", "https://m.youtube.com"},
            {"fb", "Facebook", "https://m.facebook.com"},
            {"ig", "Instagram", "https://www.instagram.com"},
            {"wa", "WhatsApp", "https://web.whatsapp.com"},
            {"tg", "Telegram", "https://web.telegram.org"},
            {"wk", "Wikipedia", "https://www.wikipedia.org"},
            {"am", "Amazon", "https://www.amazon.in"},
            {"fk", "Flipkart", "https://www.flipkart.com"}
    };
    private static final int[] SITE_BG = {
            0xFFFFFFFF, 0xFFE62117, 0xFF1877F2, 0xFFC32AA3, 0xFF25B45A,
            0xFF2A9BD8, 0xFFF3F3F1, 0xFF232F3E, 0xFF2874F0
    };
    private static final String[][] ENGINES = {
            {"google", "Google", "G"}, {"bing", "Bing", "B"}, {"ddg", "DuckDuckGo", "D"}, {"yahoo", "Yahoo", "Y"}
    };
    private static final int[] ENGINE_COLOR = {0xFF4285F4, 0xFF008373, 0xFFDE5833, 0xFF6001D2};
    private static final String[] SIZE_NAMES = {"Small", "Medium", "Large"};
    private static final int[] SIZE_ZOOM = {90, 100, 115};
    private static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google",
            "adnxs.com", "taboola.com", "outbrain.com", "popads.net", "propellerads.com",
            "exoclick.com", "mgid.com", "adsterra.com", "pubmatic.com", "rubiconproject.com",
            "criteo.com", "moatads.com", "amazon-adsystem.com", "adcolony.com", "unityads.unity3d.com",
            "popcash.net", "adcash.com", "clickadu.com", "hilltopads.net", "juicyads.com",
            "trafficjunky.net", "onclickads.net", "a-ads.com", "adsco.re", "tsyndicate.com",
            "yllix.com", "revcontent.com", "adspyglass.com", "monetag.com", "richads.com",
            "galaksion.com", "bidvertiser.com", "infolinks.com", "ero-advertising.com",
            "ad-maven.com", "admaven.com", "adskeeper.com", "evadav.com", "pushwhy.com",
            "notix.io", "pushails.com", "profitablecpmrate.com", "highperformanceformat.com",
            "highcpmgate.com", "effectivegatecpm.com", "displayvertising.com", "ad.gt",
            "adform.net", "smartadserver.com", "openx.net", "casalemedia.com", "33across.com",
            "adsrvr.org", "ads.yahoo.com", "advertising.com", "zedo.com", "popmyads.com",
            "trafficfactory.biz", "clickaine.com", "mobtrks.com", "go.oclasrv.com", "oclaserver.com",
            "ylx-1.com", "ylx-2.com", "dolohen.com", "acscdn.com", "realsrv.com", "tapioni.com",
            "adtng.com", "adxpansion.com", "bebi.com", "cdn4ads.com", "directrev.com",
            "linkvertise.com", "shorte.st", "adf.ly", "ouo.io"
    };
    private static final String[] AD_URL_PARTS = {
            "/popunder", "/pop.js", "adserver.", "/adserve", "/banners/", "pagead/", "/ads/show",
            "clickunder", "/popad", "afu.php", "/aclk?"
    };
    private static final String ADBLOCK_JS = "(function(){try{"
            + "if(!window.__srab){window.__srab=1;"
            + "var st=document.createElement('style');"
            + "st.textContent='ins.adsbygoogle,.adsbygoogle,iframe[src*=\"doubleclick.net\"],iframe[src*=\"googlesyndication\"],"
            + "iframe[id^=\"google_ads_iframe\"],div[id^=\"google_ads_\"],div[id^=\"div-gpt-ad\"],[id^=\"taboola-\"],.taboola,"
            + ".OUTBRAIN,[data-ad-slot],[data-ad-client],iframe[src*=\"adsterra\"],iframe[src*=\"popads\"],"
            + "[class~=\"ad-container\"],[class~=\"ad-banner\"],[class~=\"advertisement\"],[id~=\"advertisement\"],"
            + ".popup-ad,.ad-slot,.ad-unit,.sticky-ad,.adthrive-ad,.mgid,[id^=\"mgid_\"]{display:none!important;visibility:hidden!important;height:0!important}';"
            + "(document.head||document.documentElement).appendChild(st);"
            + "var o=window.open;window.open=function(){if(navigator.userActivation&&!navigator.userActivation.isActive)return null;return o.apply(this,arguments)};}"
            + "}catch(e){}})();";
    private long lastTouch = 0;
    private int alertCount = 0;
    private static final String[] THEME_NAMES = {"SR", "Night Sky", "Ocean", "Aurora", "Sunset"};
    private static final int[][] THEME_COLORS = {
            {0xFFFFFFFF, 0xFFFFFFFF},
            {0xFF1B1730, 0xFF3A2A4A},
            {0xFF0B1E4A, 0xFF27A3D8},
            {0xFF0A2A6B, 0xFF18C2D0},
            {0xFFFF8A4C, 0xFFE5121B}
    };

    private final Handler ui = new Handler(Looper.getMainLooper());

    private Store store;
    private Pal pal;
    private String mobileUa;

    private FrameLayout screen;
    private LinearLayout root, topBar, bottomBar;
    private EditText urlEdit, homeEdit;
    private ImageView btnRefresh, tabsIcon;
    private ProgressBar progress;
    private FrameLayout webHolder;
    private ScrollView homeView;
    private LinearLayout homeBox;
    private TextView tabCount, videoFab;
    private View btnBack, btnFwd;

    private View scrim;
    private LinearLayout sheetBox;
    private View tabsView;
    private View welcome;
    private View splash;
    private static final String APP_VER = "V1.5.0";

    private final List<PanelState> panels = new ArrayList<>();
    private final List<Tab> tabs = new ArrayList<>();
    private final List<String> closedUrls = new ArrayList<>();
    private Tab cur;
    private int mode = 0;
    private int histTab = 0;
    private boolean fullscreen = false;
    private boolean loading = false;
    private String videoUrl = null;

    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private ValueCallback<Uri[]> fileCb;

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private String tr(String s) {
        return Strings.tr(store.lang(), s);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private GradientDrawable oval(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    /* ------------------------------------------------------------------ */
    /* Lifecycle                                                          */
    /* ------------------------------------------------------------------ */

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        store = new Store(this);
        mode = store.searchMode();
        pal = new Pal(store.night());
        mobileUa = WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace("Version/4.0 ", "");
        CookieManager.getInstance().setAcceptCookie(true);
        getWindow().setStatusBarColor(pal.bg);
        getWindow().setNavigationBarColor(pal.bar);

        buildUi();
        buildSheet();
        setContentView(screen);
        applySystemUi();

        ArrayList<String> saveTabs = saved == null ? null : saved.getStringArrayList("tabs");
        if (saveTabs != null && !saveTabs.isEmpty()) {
            for (String s : saveTabs) {
                Tab t = newTab();
                if (!s.isEmpty()) loadIn(t, s);
            }
            int ci = saved.getInt("cur", 0);
            if (ci >= 0 && ci < tabs.size()) switchTo(tabs.get(ci));
        } else {
            handleIntent(getIntent());
        }
        if (tabs.isEmpty()) newTab();

        registerDownloadDone();
        if (!store.welcomed()) showWelcome();
        else ensurePerms();
        if (saved == null && !store.splashDone()) {
            store.setSplashDone(true);
            showSplash();
        }
    }

    /** UC style launch screen: plain white, logo at the bottom. */
    private void showSplash() {
        final FrameLayout sp = new FrameLayout(this);
        sp.setBackgroundColor(Color.WHITE);
        sp.setClickable(true);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.intro_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(240), dp(240), Gravity.CENTER);
        lp.bottomMargin = dp(40);
        sp.addView(logo, lp);
        TextView tagl = Ui.text(this, "Fast. Simple. Made in India.", 14, 0xFF5B6070, false);
        tagl.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        tp.bottomMargin = dp(48);
        sp.addView(tagl, tp);
        splash = sp;
        logo.setAlpha(0f);
        logo.setScaleX(0.55f);
        logo.setScaleY(0.55f);
        logo.setRotation(-14f);
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).rotation(0f).setDuration(750)
                .setInterpolator(new android.view.animation.OvershootInterpolator(1.1f)).start();
        screen.addView(sp, new FrameLayout.LayoutParams(-1, -1));
        ui.postDelayed(() -> sp.animate().alpha(0f).setDuration(280).withEndAction(() -> {
            screen.removeView(sp);
            if (splash == sp) splash = null;
        }).start(), 1400);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) lastTouch = System.currentTimeMillis();
        return super.dispatchTouchEvent(ev);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        ArrayList<String> u = new ArrayList<>();
        for (Tab t : tabs) u.add(t.home ? "" : t.url);
        out.putStringArrayList("tabs", u);
        out.putInt("cur", tabs.indexOf(cur));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent i) {
        if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) {
            Tab t = newTab();
            loadIn(t, i.getData().toString());
        } else if (tabs.isEmpty()) {
            newTab();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (cur != null) cur.web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (cur != null) cur.web.onResume();
        refreshPanel();
    }

    @Override
    protected void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        if (dlDone != null) {
            try {
                unregisterReceiver(dlDone);
            } catch (Exception ignored) {
            }
            dlDone = null;
        }
        for (Tab t : tabs) {
            try {
                webHolder.removeView(t.web);
                t.web.destroy();
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        } else if (req == REQ_PHOTO) {
            if (res == RESULT_OK && data != null && data.getData() != null) saveWallpaper(data.getData());
        } else {
            super.onActivityResult(req, res, data);
        }
    }

    @Override
    public void onBackPressed() {
        if (splash != null) {
            return;
        }
        if (customView != null) {
            hideCustom();
        } else if (tabsView != null) {
            closeTabsView();
        } else if (!panels.isEmpty()) {
            closePanel();
        } else if (scrim.getVisibility() == View.VISIBLE) {
            closeMenu();
        } else if (welcome != null) {
            if (!(welcome instanceof Intro) || !((Intro) welcome).back()) finish();
        } else if (fullscreen) {
            fullscreen = false;
            applySystemUi();
        } else {
            goBack();
        }
    }

    private void ensurePerms() {
        try {
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 2);
            } else if (Build.VERSION.SDK_INT < 29
                    && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            }
        } catch (Exception ignored) {
        }
    }

    private void applySystemUi() {
        int f = 0;
        if (fullscreen || customView != null) {
            f = View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        } else if (!pal.night) {
            if (Build.VERSION.SDK_INT >= 23) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(f);
        applyBars();
    }

    private void applyBars() {
        boolean web = cur != null && !cur.home;
        topBar.setVisibility(!fullscreen && web ? View.VISIBLE : View.GONE);
        bottomBar.setVisibility(fullscreen ? View.GONE : View.VISIBLE);
    }

    /* ------------------------------------------------------------------ */
    /* Main UI                                                            */
    /* ------------------------------------------------------------------ */

    private void buildUi() {
        screen = new FrameLayout(this);
        screen.setBackgroundColor(pal.bg);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        screen.addView(root, new FrameLayout.LayoutParams(-1, -1));

        // Page top bar (shown on web pages): mark | Enter URL + Search | refresh
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(pal.bar);
        topBar.setPadding(dp(10), dp(8), dp(6), dp(8));

        ImageView mark = new ImageView(this);
        mark.setImageResource(R.drawable.logo);
        mark.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(dp(34), dp(30));
        ml.rightMargin = dp(8);
        topBar.addView(mark, ml);

        LinearLayout urlBox = new LinearLayout(this);
        urlBox.setOrientation(LinearLayout.HORIZONTAL);
        urlBox.setGravity(Gravity.CENTER_VERTICAL);
        urlBox.setBackground(Ui.round(this, pal.surface2, 19));
        topBar.addView(urlBox, new LinearLayout.LayoutParams(0, dp(38), 1));

        urlEdit = new EditText(this);
        urlEdit.setHint(tr("Enter URL"));
        urlEdit.setHintTextColor(pal.muted);
        urlEdit.setTextColor(pal.fg);
        urlEdit.setTextSize(14);
        urlEdit.setSingleLine(true);
        urlEdit.setBackground(null);
        urlEdit.setSelectAllOnFocus(true);
        urlEdit.setPadding(dp(14), 0, dp(8), 0);
        urlEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlEdit.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlEdit.setOnEditorActionListener((v, actionId, ev) -> {
            submitFrom(urlEdit);
            return true;
        });
        urlBox.addView(urlEdit, new LinearLayout.LayoutParams(0, -1, 1));

        View div = new View(this);
        div.setBackgroundColor(pal.line);
        urlBox.addView(div, new LinearLayout.LayoutParams(dp(1), dp(20)));

        LinearLayout searchBtn = new LinearLayout(this);
        searchBtn.setOrientation(LinearLayout.HORIZONTAL);
        searchBtn.setGravity(Gravity.CENTER_VERTICAL);
        searchBtn.setPadding(dp(10), 0, dp(14), 0);
        searchBtn.addView(Ui.icon(this, R.drawable.ic_search, 17, pal.accent));
        TextView st = Ui.text(this, tr("Search"), 13.5f, pal.fg, true);
        st.setPadding(dp(5), 0, 0, 0);
        searchBtn.addView(st);
        searchBtn.setOnClickListener(v -> submitFrom(urlEdit));
        urlBox.addView(searchBtn, new LinearLayout.LayoutParams(-2, -1));

        btnRefresh = Ui.icon(this, R.drawable.ic_refresh, 24, pal.icon);
        btnRefresh.setPadding(dp(5), dp(5), dp(5), dp(5));
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(dp(38), dp(38));
        rl.leftMargin = dp(4);
        btnRefresh.setLayoutParams(rl);
        btnRefresh.setOnClickListener(v -> {
            if (cur.home) return;
            if (loading) cur.web.stopLoading();
            else cur.web.reload();
        });
        topBar.addView(btnRefresh);
        root.addView(topBar, new LinearLayout.LayoutParams(-1, -2));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(pal.accent));
        progress.setVisibility(View.INVISIBLE);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(2)));

        // Content: home screen or web pages
        FrameLayout content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        homeView = new ScrollView(this);
        homeView.setFillViewport(true);
        homeView.setVerticalScrollBarEnabled(false);
        homeBox = new LinearLayout(this);
        homeBox.setOrientation(LinearLayout.VERTICAL);
        homeBox.setPadding(dp(16), dp(24), dp(16), dp(28));
        homeView.addView(homeBox, new ViewGroup.LayoutParams(-1, -2));
        content.addView(homeView, new FrameLayout.LayoutParams(-1, -1));

        webHolder = new FrameLayout(this);
        content.addView(webHolder, new FrameLayout.LayoutParams(-1, -1));

        // Floating "download video" button
        videoFab = Ui.text(this, "  Download video  ", 13.5f, Color.WHITE, true);
        videoFab.setGravity(Gravity.CENTER);
        videoFab.setBackground(Ui.round(this, pal.accent, 24));
        videoFab.setElevation(dp(6));
        videoFab.setPadding(dp(16), dp(11), dp(16), dp(11));
        videoFab.setVisibility(View.GONE);
        videoFab.setOnClickListener(v -> {
            if (videoUrl != null) startDownload(videoUrl, mobileUa, null, null, -1);
            videoFab.setVisibility(View.GONE);
        });
        FrameLayout.LayoutParams vf = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        vf.rightMargin = dp(14);
        vf.bottomMargin = dp(14);
        content.addView(videoFab, vf);

        // Bottom bar: back | forward | menu | tabs | home
        View line = new View(this);
        line.setBackgroundColor(pal.line);
        root.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));

        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setBackgroundColor(pal.bar);
        btnBack = barBtn(R.drawable.ic_back, this::goBack);
        btnFwd = barBtn(R.drawable.ic_forward, () -> {
            if (!cur.home && cur.web.canGoForward()) cur.web.goForward();
        });
        View btnMenu = barBtn(R.drawable.ic_menu, this::openMenu);
        FrameLayout tabsBtn = new FrameLayout(this);
        tabsIcon = Ui.icon(this, R.drawable.ic_tabs, 26, pal.icon);
        tabsBtn.addView(tabsIcon, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        tabCount = Ui.text(this, "1", 11, pal.icon, true);
        tabCount.setGravity(Gravity.CENTER);
        tabsBtn.addView(tabCount, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        tabsBtn.setOnClickListener(v -> openTabs());
        View btnHome = barBtn(R.drawable.ic_home, () -> {
            cur.home = true;
            showCurrent();
        });
        bottomBar.addView(btnBack, new LinearLayout.LayoutParams(0, dp(52), 1));
        bottomBar.addView(btnFwd, new LinearLayout.LayoutParams(0, dp(52), 1));
        bottomBar.addView(btnMenu, new LinearLayout.LayoutParams(0, dp(52), 1));
        bottomBar.addView(tabsBtn, new LinearLayout.LayoutParams(0, dp(52), 1));
        bottomBar.addView(btnHome, new LinearLayout.LayoutParams(0, dp(52), 1));
        root.addView(bottomBar, new LinearLayout.LayoutParams(-1, -2));

        refreshHome();
    }

    private View barBtn(int res, Runnable r) {
        FrameLayout f = new FrameLayout(this);
        f.addView(Ui.icon(this, res, 25, pal.icon), new FrameLayout.LayoutParams(dp(25), dp(25), Gravity.CENTER));
        f.setOnClickListener(v -> r.run());
        return f;
    }

    private void updateTabBtn() {
        boolean inc = store.incognito();
        tabsIcon.setImageResource(inc ? R.drawable.ic_ghost : R.drawable.ic_tabs);
        tabsIcon.setColorFilter(inc ? PURPLE : pal.icon, android.graphics.PorterDuff.Mode.SRC_IN);
        tabCount.setText(inc ? "" : String.valueOf(tabs.size()));
    }

    /* ------------------------------------------------------------------ */
    /* Welcome screen                                                     */
    /* ------------------------------------------------------------------ */

    private LinearLayout indiaLine(int textColor, float sp) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER);
        LinearLayout flag = new LinearLayout(this);
        flag.setOrientation(LinearLayout.VERTICAL);
        int[] cs = {0xFFFF9933, 0xFFFFFFFF, 0xFF138808};
        for (int c : cs) {
            View s = new View(this);
            s.setBackgroundColor(c);
            flag.addView(s, new LinearLayout.LayoutParams(dp(20), dp(4)));
        }
        flag.setBackground(Ui.round(this, 0xFFDDDDDD, 2));
        flag.setPadding(dp(1), dp(1), dp(1), dp(1));
        l.addView(flag, new LinearLayout.LayoutParams(-2, -2));
        TextView t = Ui.text(this, tr("Made in India"), sp, textColor, true);
        t.setPadding(dp(8), 0, 0, 0);
        l.addView(t);
        return l;
    }

    /** First-run intro, UC style: language, feature slides, Agree & Continue. */
    private void showWelcome() {
        final Intro in = new Intro(this, store.lang(), lang -> {
            store.setWelcomed(true);
            boolean changed = !lang.equals(store.lang());
            store.setLang(lang);
            if (changed) {
                recreate();
                return;
            }
            View w = welcome;
            welcome = null;
            if (w != null) screen.removeView(w);
            refreshHome();
            ensurePerms();
        });
        welcome = in;
        screen.addView(in, new FrameLayout.LayoutParams(-1, -1));
    }

    /* ------------------------------------------------------------------ */
    /* Home screen                                                        */
    /* ------------------------------------------------------------------ */

    private boolean homeDark() {
        return store.theme() == 0 ? pal.night : true;
    }

    private int homeFg() {
        return homeDark() ? 0xFFFFFFFF : pal.fg;
    }

    private int homeSub() {
        return homeDark() ? 0xCCFFFFFF : pal.muted;
    }

    private void applyHomeBackground() {
        int t = store.theme();
        if (t == 5) {
            File f = new File(getFilesDir(), "wall.jpg");
            Bitmap b = f.exists() ? BitmapFactory.decodeFile(f.getPath()) : null;
            if (b != null) {
                android.graphics.drawable.BitmapDrawable bd = new android.graphics.drawable.BitmapDrawable(getResources(), b);
                bd.setGravity(Gravity.FILL);
                homeView.setBackground(bd);
                return;
            }
            t = 0;
            store.setTheme(0);
        }
        int[] c;
        if (t == 0) c = pal.night ? new int[]{pal.bg, 0xFF2A1518} : new int[]{pal.bg, 0xFFFFE9DF};
        else c = THEME_COLORS[Math.max(0, Math.min(THEME_COLORS.length - 1, t))];
        homeView.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, c));
    }

    private Bitmap assetBitmap(String path) {
        try (InputStream in = getAssets().open(path)) {
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            return null;
        }
    }

    private String engineName() {
        for (String[] e : ENGINES) if (e[0].equals(store.engine())) return e[1];
        return "Google";
    }

    private View engineBadge(int sizeDp) {
        int idx = 0;
        for (int i = 0; i < ENGINES.length; i++) if (ENGINES[i][0].equals(store.engine())) idx = i;
        return engineBadgeAt(idx, sizeDp);
    }

    private View engineBadgeAt(int idx, int sizeDp) {
        FrameLayout f = new FrameLayout(this);
        Bitmap real = assetBitmap("engines/" + ENGINES[idx][0] + ".png");
        if (real != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(real);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        } else {
            f.setBackground(oval(0xFFFFFFFF));
            if (idx == 0) {
                ImageView g = new ImageView(this);
                g.setImageResource(R.drawable.t_gg);
                g.setScaleType(ImageView.ScaleType.FIT_CENTER);
                int pad = dp(sizeDp * 0.2f);
                g.setPadding(pad, pad, pad, pad);
                f.addView(g, new FrameLayout.LayoutParams(-1, -1));
            } else {
                TextView t = Ui.text(this, ENGINES[idx][2], sizeDp * 0.5f, ENGINE_COLOR[idx], true);
                t.setGravity(Gravity.CENTER);
                f.addView(t, new FrameLayout.LayoutParams(-1, -1));
            }
        }
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        return f;
    }

    private void refreshHome() {
        String keep = homeEdit == null ? "" : homeEdit.getText().toString();
        homeBox.removeAllViews();
        homeBox.setGravity(Gravity.CENTER_HORIZONTAL);
        applyHomeBackground();
        int fg = homeFg();

        // Logo, fixed size
        View logo;
        ImageView li = new ImageView(this);
        li.setImageResource(R.drawable.logo);
        li.setScaleType(ImageView.ScaleType.FIT_CENTER);
        if (homeDark()) {
            FrameLayout plate = new FrameLayout(this);
            plate.setBackground(Ui.round(this, 0xFFFFFFFF, 22));
            plate.setPadding(dp(14), dp(12), dp(14), dp(12));
            plate.addView(li, new FrameLayout.LayoutParams(-1, -1));
            logo = plate;
        } else {
            logo = li;
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(210), dp(178));
        lp.topMargin = dp(36);
        homeBox.addView(logo, lp);

        if (!store.homeNote().isEmpty()) {
            TextView n = Ui.text(this, store.homeNote(), 13.5f, homeSub(), false);
            n.setGravity(Gravity.CENTER);
            n.setPadding(0, dp(10), 0, 0);
            homeBox.addView(n);
        }

        // Search pill
        LinearLayout pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setBackground(Ui.round(this, pal.surface, 30));
        pill.setElevation(dp(5));
        pill.setPadding(dp(14), 0, dp(10), 0);
        LinearLayout eng = new LinearLayout(this);
        eng.setOrientation(LinearLayout.HORIZONTAL);
        eng.setGravity(Gravity.CENTER_VERTICAL);
        eng.addView(engineBadge(32));
        TextView tri = Ui.text(this, "▾", 12, pal.muted, false);
        tri.setPadding(dp(4), 0, dp(4), 0);
        eng.addView(tri);
        eng.setOnClickListener(v -> pickEngine());
        pill.addView(eng);

        homeEdit = new EditText(this);
        homeEdit.setHint(tr("Search or Enter URL"));
        homeEdit.setHintTextColor(pal.muted);
        homeEdit.setTextColor(pal.fg);
        homeEdit.setTextSize(16);
        homeEdit.setSingleLine(true);
        homeEdit.setBackground(null);
        homeEdit.setPadding(dp(8), 0, dp(8), 0);
        homeEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        homeEdit.setImeOptions(EditorInfo.IME_ACTION_GO);
        homeEdit.setText(keep);
        homeEdit.setOnEditorActionListener((v, actionId, ev) -> {
            submitFrom(homeEdit);
            return true;
        });
        pill.addView(homeEdit, new LinearLayout.LayoutParams(0, -1, 1));
        ImageView go = Ui.icon(this, R.drawable.ic_search, 22, pal.accent);
        go.setPadding(dp(4), dp(4), dp(4), dp(4));
        go.setLayoutParams(new LinearLayout.LayoutParams(dp(32), dp(32)));
        go.setOnClickListener(v -> submitFrom(homeEdit));
        pill.addView(go);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(56));
        pp.topMargin = dp(26);
        pp.leftMargin = dp(4);
        pp.rightMargin = dp(4);
        homeBox.addView(pill, pp);

        // Web / Videos / Images
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setGravity(Gravity.CENTER);
        String[] names = {"Web", "Videos", "Images"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView c = Ui.text(this, tr(names[i]), 13, i == mode ? Color.WHITE : homeSub(), true);
            c.setPadding(dp(16), dp(7), dp(16), dp(7));
            c.setBackground(Ui.round(this, i == mode ? pal.accent : (homeDark() ? 0x33FFFFFF : pal.surface), 20));
            c.setOnClickListener(v -> {
                mode = idx;
                store.setSearchMode(idx);
                refreshHome();
            });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
            cp.leftMargin = dp(4);
            cp.rightMargin = dp(4);
            chips.addView(c, cp);
        }
        LinearLayout.LayoutParams chp = new LinearLayout.LayoutParams(-2, -2);
        chp.topMargin = dp(16);
        homeBox.addView(chips, chp);

        // Quick row
        if (store.showQuick()) {
            LinearLayout q = new LinearLayout(this);
            q.setOrientation(LinearLayout.HORIZONTAL);
            q.addView(quick(R.drawable.ic_dl_hex, "Downloader", this::openDownloader), new LinearLayout.LayoutParams(0, -2, 1));
            q.addView(quick(R.drawable.ic_notes, "Notes", this::openNotes), new LinearLayout.LayoutParams(0, -2, 1));
            q.addView(quick(R.drawable.ic_clock, "History", this::openHistory), new LinearLayout.LayoutParams(0, -2, 1));
            q.addView(quick(R.drawable.ic_bookmark_o, "Bookmark", this::openBookmarks), new LinearLayout.LayoutParams(0, -2, 1));
            LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(-1, -2);
            qp.topMargin = dp(30);
            homeBox.addView(q, qp);
        }

        // Sites
        List<View> tiles = new ArrayList<>();
        for (int i = 0; i < SITES.length; i++) {
            final String url = SITES[i][2];
            GradientDrawable bg;
            if (SITES[i][0].equals("ig")) {
                bg = new GradientDrawable(GradientDrawable.Orientation.BL_TR,
                        new int[]{0xFFFDB53C, 0xFFF0443D, 0xFFC32AA3, 0xFF6A3DE8});
                bg.setShape(GradientDrawable.OVAL);
            } else {
                bg = oval(SITE_BG[i]);
            }
            int res = getResources().getIdentifier("t_" + SITES[i][0], "drawable", getPackageName());
            tiles.add(tile(SITES[i][1], bg, res, null, "icons/" + SITES[i][0] + ".png",
                    () -> loadIn(cur, url), null, fg));
        }
        List<Store.Item> bms = store.list("bm");
        for (int i = 0; i < bms.size(); i++) {
            final Store.Item b = bms.get(i);
            final int idx = i;
            String letter = b.title.isEmpty() ? "?" : b.title.substring(0, 1).toUpperCase();
            tiles.add(tile(b.title, oval(pal.surface), 0, letter, null,
                    () -> loadIn(cur, b.url),
                    () -> new AlertDialog.Builder(this).setTitle("Remove " + b.title + "?")
                            .setPositiveButton("Remove", (d, which) -> {
                                store.remove("bm", idx);
                                refreshHome();
                            }).setNegativeButton("Cancel", null).show(), fg));
        }
        GradientDrawable addBg = oval(homeDark() ? 0x22FFFFFF : pal.surface);
        addBg.setStroke(dp(1), pal.accent);
        tiles.add(tile("Add", addBg, R.drawable.ic_plus, null, null, this::promptAddSite, null, fg));

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < tiles.size(); i += 5) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int j = 0; j < 5; j++) {
                View v = i + j < tiles.size() ? tiles.get(i + j) : new View(this);
                row.addView(v, new LinearLayout.LayoutParams(0, -2, 1));
            }
            grid.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2);
        gp.topMargin = dp(26);
        homeBox.addView(grid, gp);

        if (store.showIndia()) {
            LinearLayout in = indiaLine(homeSub(), 13);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-2, -2);
            ip.topMargin = dp(34);
            homeBox.addView(in, ip);
        }
    }

    private View quick(int res, String label, final Runnable r) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER_HORIZONTAL);
        v.setPadding(0, dp(6), 0, dp(6));
        v.addView(Ui.icon(this, res, 30, homeFg()));
        TextView t = Ui.oneLine(Ui.text(this, tr(label), 13, homeFg(), false));
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(8), 0, 0);
        v.addView(t, new LinearLayout.LayoutParams(-1, -2));
        v.setOnClickListener(x -> r.run());
        return v;
    }

    private View tile(String name, GradientDrawable bg, int iconRes, String letter, String assetPath,
                      final Runnable click, final Runnable longClick, int labelColor) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setPadding(dp(2), dp(9), dp(2), dp(9));

        FrameLayout box = new FrameLayout(this);
        box.setBackground(bg);
        box.setElevation(dp(2));
        Bitmap real = assetPath == null ? null : assetBitmap(assetPath);
        if (real != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(real);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(bg);
            iv.setClipToOutline(true);
            box.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        } else if (letter != null) {
            TextView l = Ui.text(this, letter, 22, pal.accent, true);
            l.setGravity(Gravity.CENTER);
            box.addView(l, new FrameLayout.LayoutParams(-1, -1));
        } else if (iconRes != 0) {
            int tint = iconRes == R.drawable.ic_plus ? pal.accent : 0;
            ImageView ic = Ui.icon(this, iconRes, 28, tint);
            box.addView(ic, new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER));
        }
        t.addView(box, new LinearLayout.LayoutParams(dp(52), dp(52)));

        TextView n = Ui.oneLine(Ui.text(this, name, 12, labelColor, false));
        n.setGravity(Gravity.CENTER);
        n.setPadding(0, dp(6), 0, 0);
        t.addView(n, new LinearLayout.LayoutParams(-1, -2));

        t.setOnClickListener(v -> click.run());
        if (longClick != null) {
            t.setOnLongClickListener(v -> {
                longClick.run();
                return true;
            });
        }
        return t;
    }

    private EditText ucInput(String hint, int inputType) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(inputType);
        e.setTextColor(pal.fg);
        e.setHintTextColor(pal.muted);
        e.setTextSize(17);
        e.setBackground(Ui.round(this, pal.surface2, 16));
        e.setPadding(dp(18), 0, dp(18), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.topMargin = dp(10);
        e.setLayoutParams(lp);
        return e;
    }

    private void promptAddSite() {
        LinearLayout c = ucCard(false);
        c.addView(ucTitle("Add to home"));
        final EditText name = ucInput("Name (e.g. Hotstar)", InputType.TYPE_CLASS_TEXT);
        final EditText addr = ucInput("https://example.com", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        c.addView(name);
        c.addView(addr);
        final Dialog d = ucShow(c, false);
        c.addView(ucBtn("Add", true, v -> {
            String nm = name.getText().toString().trim();
            String ad = addr.getText().toString().trim();
            if (ad.isEmpty()) {
                toast("Enter an address");
                return;
            }
            String url = toUrl(ad);
            if (nm.isEmpty()) nm = host(url);
            store.add("bm", nm, url, 100, false);
            d.dismiss();
            refreshHome();
            refreshPanel();
            toast(nm + " added to home");
        }));
        c.addView(ucBtn("Cancel", false, v -> d.dismiss()));
        if (d.getWindow() != null) d.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE | android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }

    private void addBookmark() {
        if (cur.home) {
            promptAddSite();
        } else {
            String t = cur.title == null || cur.title.isEmpty() ? host(cur.url) : cur.title;
            store.add("bm", t, cur.url, 100, false);
            refreshHome();
            toast("Bookmark saved");
        }
    }

    /* ------------------------------------------------------------------ */
    /* Tabs and WebView                                                   */
    /* ------------------------------------------------------------------ */

    private Tab newTab() {
        Tab t = new Tab();
        t.web = makeWeb(t);
        webHolder.addView(t.web, new FrameLayout.LayoutParams(-1, -1));
        tabs.add(t);
        switchTo(t);
        return t;
    }

    private void switchTo(Tab t) {
        if (cur != null && cur != t) {
            captureThumb(cur);
            cur.web.onPause();
        }
        cur = t;
        t.web.onResume();
        showCurrent();
    }

    private void showCurrent() {
        for (Tab t : tabs) t.web.setVisibility(t == cur && !t.home ? View.VISIBLE : View.GONE);
        homeView.setVisibility(cur.home ? View.VISIBLE : View.GONE);
        webHolder.setVisibility(cur.home ? View.GONE : View.VISIBLE);
        urlEdit.setText(cur.home ? "" : cur.url);
        urlEdit.clearFocus();
        updateTabBtn();
        loading = false;
        progress.setVisibility(View.INVISIBLE);
        btnRefresh.setImageResource(R.drawable.ic_refresh);
        videoFab.setVisibility(View.GONE);
        videoUrl = null;
        applyBars();
        updateNav();
    }

    private void updateNav() {
        btnBack.setAlpha(cur.home && tabs.size() < 2 ? 0.35f : 1f);
        btnFwd.setAlpha(!cur.home && cur.web.canGoForward() ? 1f : 0.35f);
    }

    private void loadIn(Tab t, String url) {
        t.home = false;
        t.url = url;
        if (t == cur) showCurrent();
        t.web.loadUrl(url);
    }

    private void closeTab(Tab t) {
        int idx = tabs.indexOf(t);
        closedUrls.add(t.home ? "" : t.url);
        tabs.remove(t);
        webHolder.removeView(t.web);
        t.web.destroy();
        if (tabs.isEmpty()) {
            newTab();
        } else if (cur == t) {
            switchTo(tabs.get(Math.max(0, idx - 1)));
        } else {
            showCurrent();
        }
    }

    private void goBack() {
        if (!cur.home) {
            if (cur.web.canGoBack()) {
                cur.web.goBack();
            } else {
                cur.home = true;
                showCurrent();
            }
        } else if (tabs.size() > 1) {
            closeTab(cur);
        } else {
            confirmExit();
        }
    }

    private void confirmExit() {
        if (store.noAskExit()) {
            finishAffinity();
            return;
        }
        LinearLayout c = ucCard(false);
        c.addView(ucTitle("Sure to exit S.R Browser?"));
        final CheckBox cHist = ucCheck("Clear browsing history", false);
        final CheckBox cHome = ucCheck("Add SR to Home Screen", false);
        final CheckBox cAsk = ucCheck("Do not ask again", false);
        c.addView(cHist);
        c.addView(cHome);
        c.addView(cAsk);
        final Dialog d = ucShow(c, false);
        c.addView(ucBtn("Exit", true, v -> {
            if (cHist.isChecked()) {
                store.clear("hist");
                store.clear("vhist");
            }
            if (cHome.isChecked()) pinHomeShortcut();
            if (cAsk.isChecked()) store.setNoAskExit(true);
            d.dismiss();
            finishAffinity();
        }));
        c.addView(ucBtn("Cancel", false, v -> d.dismiss()));
    }

    private void pinHomeShortcut() {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                android.content.pm.ShortcutManager sm = getSystemService(android.content.pm.ShortcutManager.class);
                if (sm != null && sm.isRequestPinShortcutSupported()) {
                    Intent li = new Intent(this, MainActivity.class).setAction(Intent.ACTION_MAIN);
                    android.content.pm.ShortcutInfo si = new android.content.pm.ShortcutInfo.Builder(this, "sr_home")
                            .setShortLabel("S.R Browser")
                            .setIcon(android.graphics.drawable.Icon.createWithResource(this, R.mipmap.ic_launcher))
                            .setIntent(li).build();
                    sm.requestPinShortcut(si, null);
                }
            }
        } catch (Exception ignored) {
        }
    }

    /* ---- UC style dialog helpers ---- */

    private LinearLayout ucCard(boolean bottom) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(24), dp(24), dp(24), dp(bottom ? 20 : 24));
        c.setBackground(bottom ? Ui.roundTop(this, pal.bar, 28) : Ui.round(this, pal.bar, 28));
        return c;
    }

    private TextView ucTitle(String s) {
        TextView t = Ui.text(this, tr(s), 22, pal.fg, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(12), 0, dp(14));
        return t;
    }

    private CheckBox ucCheck(String label, boolean on) {
        CheckBox cb = new CheckBox(this);
        cb.setText(tr(label));
        cb.setTextSize(18);
        cb.setTextColor(pal.fg);
        cb.setChecked(on);
        cb.setPadding(dp(10), dp(14), dp(4), dp(14));
        cb.setButtonTintList(new ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{0xFF2F8CFF, 0xFF8A93A3}));
        return cb;
    }

    private View ucBtn(String label, boolean primary, View.OnClickListener l) {
        TextView b = Ui.text(this, tr(label), 17, primary ? Color.WHITE : pal.fg, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(Ui.round(this, primary ? 0xFF1C2024 : pal.surface2, 20));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.topMargin = dp(12);
        b.setLayoutParams(lp);
        return b;
    }

    private Dialog ucShow(View content, boolean bottom) {
        Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setContentView(content);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(bottom ? new ColorDrawable(Color.TRANSPARENT)
                    : new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), dp(28), 0, dp(28), 0));
            w.setLayout(-1, -2);
            w.setGravity(bottom ? Gravity.BOTTOM : Gravity.CENTER);
            w.setDimAmount(0.45f);
        }
        d.show();
        return d;
    }

    private void applyWebPrefs(WebView w) {
        WebSettings s = w.getSettings();
        s.setTextZoom(SIZE_ZOOM[Math.max(0, Math.min(2, store.textSize()))]);
        s.setUserAgentString(store.desktop() ? DESKTOP_UA : mobileUa);
        s.setJavaScriptEnabled(store.js());
        s.setBlockNetworkImage(store.dataSaver());
    }

    private void applyAllWebPrefs() {
        for (Tab t : tabs) applyWebPrefs(t.web);
    }

    private boolean isAdHost(String h) {
        if (h == null) return false;
        for (String a : AD_HOSTS) if (h.equals(a) || h.endsWith("." + a)) return true;
        return false;
    }

    private boolean isAdUrl(String url) {
        if (url == null) return false;
        try {
            String h = Uri.parse(url).getHost();
            if (isAdHost(h)) return true;
        } catch (Exception ignored) {
        }
        String u = url.toLowerCase();
        for (String p : AD_URL_PARTS) if (u.contains(p)) return true;
        return false;
    }

    private String baseDomain(String h) {
        if (h == null) return "";
        String[] p = h.split("\\.");
        if (p.length <= 2) return h;
        String last2 = p[p.length - 2] + "." + p[p.length - 1];
        if (p[p.length - 2].length() <= 3 && p[p.length - 1].length() == 2 && p.length >= 3)
            return p[p.length - 3] + "." + last2;
        return last2;
    }

    private boolean isVideoPage(String url) {
        if (url == null) return false;
        String u = url.toLowerCase();
        return u.contains("youtube.com/watch") || u.contains("youtu.be/") || u.contains("vimeo.com/")
                || u.contains("dailymotion.com/video") || u.contains(".mp4") || u.contains(".m3u8")
                || u.contains(".webm") || u.contains("/reel") || u.contains("/shorts/");
    }

    private WebView makeWeb(final Tab t) {
        final WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        applyWebPrefs(w);
        w.setBackgroundColor(Color.WHITE);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);

        w.setDownloadListener((url, ua, cd, mime, len) -> startDownload(url, ua, cd, mime, len));

        w.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (store.adblock() && !r.isForMainFrame() && isAdUrl(r.getUrl().toString())) {
                    return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String sc = r.getUrl().getScheme();
                if (sc == null) return false;
                if (store.adblock() && r.isForMainFrame() && (sc.equals("http") || sc.equals("https"))) {
                    if (isAdUrl(r.getUrl().toString())) {
                        toast("Ad redirect blocked");
                        return true;
                    }
                    boolean auto = !r.hasGesture() && !r.isRedirect()
                            && System.currentTimeMillis() - lastTouch > 1500
                            && !t.home && t.url != null && t.url.startsWith("http");
                    if (auto && !baseDomain(host(t.url)).equals(baseDomain(r.getUrl().getHost()))) {
                        toast("Ad redirect blocked");
                        return true;
                    }
                }
                if (sc.equals("http") || sc.equals("https") || sc.equals("about")
                        || sc.equals("data") || sc.equals("blob") || sc.equals("javascript")) {
                    return false;
                }
                if (sc.equals("file")) return true;
                if (store.adblock() && !r.hasGesture() && System.currentTimeMillis() - lastTouch > 1500) return true;
                try {
                    Intent in;
                    if (sc.equals("intent")) in = Intent.parseUri(r.getUrl().toString(), Intent.URI_INTENT_SCHEME);
                    else in = new Intent(Intent.ACTION_VIEW, r.getUrl());
                    in.addCategory(Intent.CATEGORY_BROWSABLE);
                    in.setComponent(null);
                    in.setSelector(null);
                    startActivity(in);
                } catch (Exception e) {
                    toast("No app found to open this link");
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap fav) {
                t.url = url;
                alertCount = 0;
                if (store.adblock()) v.evaluateJavascript(ADBLOCK_JS, null);
                if (t == cur) {
                    videoFab.setVisibility(View.GONE);
                    videoUrl = null;
                    if (!urlEdit.hasFocus()) urlEdit.setText(url);
                }
            }

            @Override
            public void onPageFinished(final WebView v, String url) {
                t.url = url;
                if (store.adblock()) {
                    v.evaluateJavascript(ADBLOCK_JS, null);
                    ui.postDelayed(() -> v.evaluateJavascript(ADBLOCK_JS, null), 1500);
                }
                String title = v.getTitle();
                t.title = title == null || title.isEmpty() ? host(url) : title;
                if (t == cur && !urlEdit.hasFocus()) urlEdit.setText(url);
                if (!store.incognito() && url != null && url.startsWith("http")) {
                    store.add("hist", t.title, url, 200, true);
                    if (isVideoPage(url)) store.add("vhist", t.title, url, 200, true);
                }
                if (t == cur) {
                    updateNav();
                    if (store.detectVideo()) {
                        detectVideo(t);
                        ui.postDelayed(() -> detectVideo(t), 2500);
                        ui.postDelayed(() -> detectVideo(t), 6000);
                    }
                }
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) {
                    String u = r.getUrl().toString();
                    String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                            + "<body style='font-family:sans-serif;text-align:center;padding:56px 18px;color:#555'>"
                            + "<h2>Couldn't load this page</h2><p>" + TextUtils.htmlEncode(String.valueOf(e.getDescription()))
                            + "</p><p><a href='" + TextUtils.htmlEncode(u) + "'>Try again</a></p></body></html>";
                    v.loadDataWithBaseURL(u, html, "text/html", "utf-8", u);
                }
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (t != cur) return;
                loading = p < 100;
                progress.setProgress(p);
                progress.setVisibility(loading ? View.VISIBLE : View.INVISIBLE);
                btnRefresh.setImageResource(loading ? R.drawable.ic_close : R.drawable.ic_refresh);
            }

            @Override
            public void onReceivedTitle(WebView v, String title) {
                if (title != null && !title.isEmpty()) t.title = title;
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean dialog, boolean gesture, Message msg) {
                if (store.popupBlock() && !gesture) return false;
                final WebView tmp = new WebView(MainActivity.this);
                tmp.setWebViewClient(new WebViewClient() {
                    boolean done;

                    boolean handle(final String url) {
                        if (url == null || url.equals("about:blank") || done) return true;
                        done = true;
                        ui.post(() -> {
                            tmp.destroy();
                            if (store.adblock() && isAdUrl(url)) {
                                toast("Popup ad blocked");
                            } else {
                                Tab nt = newTab();
                                loadIn(nt, url);
                            }
                        });
                        return true;
                    }

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView w2, WebResourceRequest r) {
                        return handle(r.getUrl().toString());
                    }

                    @Override
                    public void onPageStarted(WebView w2, String url, Bitmap f) {
                        handle(url);
                    }
                });
                WebView.WebViewTransport tr = (WebView.WebViewTransport) msg.obj;
                tr.setWebView(tmp);
                msg.sendToTarget();
                return true;
            }

            @Override
            public boolean onJsAlert(WebView v, String url, String message, JsResult result) {
                if (store.adblock() && ++alertCount > 2) {
                    result.cancel();
                    return true;
                }
                return false;
            }

            @Override
            public void onShowCustomView(View v, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = v;
                customCb = cb;
                v.setBackgroundColor(Color.BLACK);
                screen.addView(v, new FrameLayout.LayoutParams(-1, -1));
                root.setVisibility(View.GONE);
                applySystemUi();
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    toast("No app found to pick files");
                    return false;
                }
                return true;
            }
        });

        w.setOnLongClickListener(v -> {
            WebView.HitTestResult hr = w.getHitTestResult();
            String extra = hr.getExtra();
            int type = hr.getType();
            if (extra == null) return false;
            if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                linkMenu(extra, false);
                return true;
            }
            if (type == WebView.HitTestResult.IMAGE_TYPE) {
                linkMenu(extra, true);
                return true;
            }
            return false;
        });
        return w;
    }

    /** Looks for a direct video file on the page and shows the Download video button. */
    private void detectVideo(final Tab t) {
        if (t != cur || t.home) return;
        String js = "(function(){var v=document.querySelector('video');if(!v)return '';"
                + "var s=v.currentSrc||v.src||'';if(!s){var o=v.querySelector('source');if(o)s=o.src;}return s||'';})()";
        t.web.evaluateJavascript(js, value -> {
            if (t != cur || value == null) return;
            String s = value.replace("\"", "").replace("\\u0026", "&").replace("\\/", "/");
            if (s.startsWith("http")) {
                videoUrl = s;
                videoFab.setVisibility(View.VISIBLE);
            }
        });
    }

    private void hideCustom() {
        if (customView == null) return;
        screen.removeView(customView);
        customView = null;
        root.setVisibility(View.VISIBLE);
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        applySystemUi();
    }

    private void linkMenu(final String url, boolean image) {
        final String[] items = image
                ? new String[]{tr("Open image in new tab"), tr("Download image"), tr("Copy link")}
                : new String[]{tr("Open in new tab"), tr("Download link"), tr("Copy link")};
        new AlertDialog.Builder(this).setItems(items, (d, which) -> {
            if (which == 2) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("link", url));
                toast(tr("Link copied"));
            } else if (which == 1) {
                startDownload(url, mobileUa, null, null, -1);
            } else {
                Tab nt = newTab();
                loadIn(nt, url);
            }
        }).show();
    }

    private void startDownload(final String url, final String ua, final String cd, final String mime, final long len) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
            toast(tr("This file can't be downloaded directly. Try the site's own download button."));
            return;
        }
        String guess = URLUtil.guessFileName(url, cd, mime);
        if (guess == null || guess.trim().isEmpty()) guess = "download";
        final String name = guess;
        if (!store.askDownload()) {
            enqueue(url, ua, mime, name);
            return;
        }
        // UC style download sheet: file icon, editable name, size, location
        LinearLayout c = ucCard(true);
        c.addView(ucTitle("Download"));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        final FrameLayout badgeBox = new FrameLayout(this);
        badgeBox.addView(fileBadge(name, 52));
        LinearLayout.LayoutParams bbp = new LinearLayout.LayoutParams(dp(52), dp(52));
        bbp.rightMargin = dp(14);
        row.addView(badgeBox, bbp);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        final EditText e = new EditText(this);
        e.setText(name);
        e.setSingleLine(true);
        e.setTextSize(16);
        e.setTextColor(pal.fg);
        e.setBackground(null);
        e.setPadding(0, dp(4), 0, dp(4));
        e.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int st, int co, int af) {
            }

            @Override
            public void onTextChanged(CharSequence s, int st, int be, int co) {
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {
                badgeBox.removeAllViews();
                badgeBox.addView(fileBadge(s.toString(), 52));
            }
        });
        col.addView(e, new LinearLayout.LayoutParams(-1, -2));
        View ul = new View(this);
        ul.setBackgroundColor(pal.line);
        col.addView(ul, new LinearLayout.LayoutParams(-1, dp(1)));
        String meta = (len > 0 ? tr("Size") + ": " + fmtSize(len) + "   ·   " : "") + tr("Save to") + ": Download";
        TextView mt = Ui.text(this, meta, 12.5f, pal.muted, false);
        mt.setPadding(0, dp(6), 0, 0);
        col.addView(mt);
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        c.addView(row, new LinearLayout.LayoutParams(-1, -2));
        final CheckBox wifi = ucCheck("Download on Wi-Fi only", store.wifiOnly());
        c.addView(wifi);
        final Dialog d = ucShow(c, true);
        c.addView(ucBtn("Download", true, v -> {
            String n = e.getText().toString().trim();
            if (n.isEmpty()) n = name;
            store.setWifiOnly(wifi.isChecked());
            d.dismiss();
            enqueue(url, ua, mime, n);
        }));
        c.addView(ucBtn("Cancel", false, v -> d.dismiss()));
    }

    private void enqueue(String url, String ua, String mime, String name) {
        try {
            name = name.replaceAll("[\\\\/:*?\"<>|\\n\\r]", "_").trim();
            if (name.isEmpty()) name = "download";
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (mime != null && !mime.isEmpty()) r.setMimeType(mime);
            r.addRequestHeader("User-Agent", ua != null ? ua : mobileUa);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) r.addRequestHeader("Cookie", cookie);
            if (cur != null && cur.url != null && cur.url.startsWith("http")) r.addRequestHeader("Referer", cur.url);
            r.setTitle(name);
            r.setDescription("S.R Browser");
            r.setNotificationVisibility(store.dlNotify()
                    ? DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                    : DownloadManager.Request.VISIBILITY_VISIBLE);
            r.setAllowedOverMetered(!store.wifiOnly());
            r.setAllowedOverRoaming(!store.wifiOnly());
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            if (dlCatOf(name) == 2 || dlCatOf(name) == 1 || dlCatOf(name) == 3) {
                try {
                    r.allowScanningByMediaScanner();
                } catch (Exception ignored) {
                }
            }
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            long id = dm.enqueue(r);
            store.add("dl", name, id + "|" + url, 300, true);
            dlTab = 0;
            snack(tr("Download started") + ": " + name, tr("VIEW"), () -> {
                if (!dlPanelOnTop()) openDownloader();
            });
            if (dlPanelOnTop()) refreshPanel();
        } catch (Exception e) {
            toast(tr("Download failed"));
        }
    }

    /* ------------------------------------------------------------------ */
    /* Address bar                                                        */
    /* ------------------------------------------------------------------ */

    private void hideKb(View v) {
        InputMethodManager m = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (m != null) m.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    private void submitFrom(EditText e) {
        String q = e.getText().toString().trim();
        if (q.isEmpty()) return;
        hideKb(e);
        e.clearFocus();
        loadIn(cur, toUrl(q));
        if (e == homeEdit) e.setText("");
    }

    private String toUrl(String q) {
        if (q.startsWith("http://") || q.startsWith("https://")) return q;
        if (!q.contains(" ") && q.contains(".") && Patterns.WEB_URL.matcher(q).matches()) return "https://" + q;
        return searchUrl(q);
    }

    private String searchUrl(String q) {
        String e = store.engine();
        String en = Uri.encode(q);
        switch (e) {
            case "bing":
                if (mode == 1) return "https://www.bing.com/videos/search?q=" + en;
                if (mode == 2) return "https://www.bing.com/images/search?q=" + en;
                return "https://www.bing.com/search?q=" + en;
            case "ddg":
                if (mode == 1) return "https://duckduckgo.com/?q=" + en + "&iax=videos&ia=videos";
                if (mode == 2) return "https://duckduckgo.com/?q=" + en + "&iax=images&ia=images";
                return "https://duckduckgo.com/?q=" + en;
            case "yahoo":
                return "https://search.yahoo.com/search?p=" + en;
            default:
                if (mode == 1) return "https://www.google.com/search?q=" + en + "&tbm=vid";
                if (mode == 2) return "https://www.google.com/search?q=" + en + "&tbm=isch";
                return "https://www.google.com/search?q=" + en;
        }
    }

    private String host(String url) {
        try {
            String h = Uri.parse(url).getHost();
            return h == null ? url : h.replaceFirst("^www\\.", "");
        } catch (Exception e) {
            return url;
        }
    }

    private void pickEngine() {
        LinearLayout c = ucCard(false);
        c.addView(ucTitle("Search engine"));
        final Dialog d = ucShow(c, false);
        for (int i = 0; i < ENGINES.length; i++) {
            final int idx = i;
            boolean on = ENGINES[i][0].equals(store.engine());
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(8), dp(14), dp(8));
            row.setBackground(on ? Ui.round(this, pal.surface2, 16) : null);
            View badge = engineBadgeAt(i, 34);
            row.addView(badge);
            TextView n = Ui.text(this, ENGINES[i][1], 18, pal.fg, on);
            n.setPadding(dp(16), 0, 0, 0);
            row.addView(n, new LinearLayout.LayoutParams(0, -2, 1));
            if (on) row.addView(Ui.icon(this, R.drawable.ic_check, 22, 0xFF2F8CFF));
            row.setOnClickListener(v -> {
                store.setEngine(ENGINES[idx][0]);
                d.dismiss();
                refreshHome();
                refreshPanel();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(58));
            lp.bottomMargin = dp(4);
            c.addView(row, lp);
        }
        c.addView(ucBtn("Cancel", false, v -> d.dismiss()));
    }

    /* ------------------------------------------------------------------ */
    /* Menu sheet (UC style)                                              */
    /* ------------------------------------------------------------------ */

    private void buildSheet() {
        scrim = new View(this);
        scrim.setBackgroundColor(0x99000000);
        scrim.setVisibility(View.GONE);
        scrim.setOnClickListener(v -> closeMenu());
        screen.addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        sheetBox = new LinearLayout(this);
        sheetBox.setOrientation(LinearLayout.VERTICAL);
        sheetBox.setBackground(Ui.roundTop(this, pal.sheet, 26));
        sheetBox.setVisibility(View.GONE);
        sheetBox.setClickable(true);
        sheetBox.setPadding(dp(18), dp(20), dp(18), dp(4));
        screen.addView(sheetBox, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
    }

    private void openMenu() {
        if (sheetBox.getVisibility() == View.VISIBLE) {
            closeMenu();
            return;
        }
        fillMenu();
        scrim.setVisibility(View.VISIBLE);
        sheetBox.setVisibility(View.VISIBLE);
    }

    private void closeMenu() {
        scrim.setVisibility(View.GONE);
        sheetBox.setVisibility(View.GONE);
    }

    private void fillMenu() {
        sheetBox.removeAllViews();

        // Header: logo avatar, SR Center, Made in India, incognito pill
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout av = new FrameLayout(this);
        av.setBackground(Ui.round(this, 0xFFFFFFFF, 14));
        av.setPadding(dp(5), dp(5), dp(5), dp(5));
        ImageView ai = new ImageView(this);
        ai.setImageResource(R.drawable.logo);
        ai.setScaleType(ImageView.ScaleType.FIT_CENTER);
        av.addView(ai, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams avp = new LinearLayout.LayoutParams(dp(50), dp(50));
        avp.rightMargin = dp(12);
        head.addView(av, avp);
        LinearLayout hc = new LinearLayout(this);
        hc.setOrientation(LinearLayout.VERTICAL);
        hc.addView(Ui.text(this, tr("SR Center"), 18, pal.fg, true));
        LinearLayout in = indiaLine(pal.muted, 12.5f);
        in.setGravity(Gravity.START);
        in.setPadding(0, dp(3), 0, 0);
        hc.addView(in);
        head.addView(hc, new LinearLayout.LayoutParams(0, -2, 1));

        boolean inc = store.incognito();
        FrameLayout ghost = new FrameLayout(this);
        ghost.setBackground(Ui.round(this, inc ? PURPLE : pal.surface, 24));
        ghost.addView(Ui.icon(this, R.drawable.ic_ghost, 26, inc ? 0xFFFFFFFF : pal.fg),
                new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        ghost.setOnClickListener(v -> {
            store.setIncognito(!store.incognito());
            updateTabBtn();
            toast(store.incognito() ? "Incognito on" : "Incognito off");
            fillMenu();
        });
        head.addView(ghost, new LinearLayout.LayoutParams(dp(92), dp(46)));
        sheetBox.addView(head, new LinearLayout.LayoutParams(-1, -2));

        // Row 1: colour circles
        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.addView(menuItem(R.drawable.ic_bookmark_o, "Bookmarks", 0xFF19C9A6, false, false, this::openBookmarks), new LinearLayout.LayoutParams(0, -2, 1));
        r1.addView(menuItem(R.drawable.ic_clock, "History", 0xFFFFB400, false, false, this::openHistory), new LinearLayout.LayoutParams(0, -2, 1));
        r1.addView(menuItem(R.drawable.ic_download, "Downloads", 0xFF3B82F6, false, false, this::openDownloader), new LinearLayout.LayoutParams(0, -2, 1));
        r1.addView(menuItem(R.drawable.ic_tshirt, "Themes", 0xFFF0508A, false, false, this::openThemes), new LinearLayout.LayoutParams(0, -2, 1));
        r1.addView(menuItem(R.drawable.ic_wrench, "Tools", 0xFF8B5CF6, false, false, this::openToolsSheet), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams r1p = new LinearLayout.LayoutParams(-1, -2);
        r1p.topMargin = dp(24);
        sheetBox.addView(r1, r1p);

        // Row 2: plain icons
        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        r2.addView(menuItem(R.drawable.ic_star, "Add to Bookmarks", 0, false, cur.home, this::addBookmark), new LinearLayout.LayoutParams(0, -2, 1));
        r2.addView(menuItem(R.drawable.ic_moon, "Night", 0, pal.night, false, () -> {
            store.setNight(!store.night());
            recreate();
        }), new LinearLayout.LayoutParams(0, -2, 1));
        r2.addView(menuItem(R.drawable.ic_refresh, "Refresh", 0, false, cur.home, () -> cur.web.reload()), new LinearLayout.LayoutParams(0, -2, 1));
        r2.addView(menuItem(R.drawable.ic_feedback, "Feedback", 0, false, false, this::feedback), new LinearLayout.LayoutParams(0, -2, 1));
        r2.addView(menuItem(R.drawable.ic_sharebox, "Share", 0, false, false, this::share), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams r2p = new LinearLayout.LayoutParams(-1, -2);
        r2p.topMargin = dp(22);
        r2p.bottomMargin = dp(16);
        sheetBox.addView(r2, r2p);

        View line = new View(this);
        line.setBackgroundColor(pal.line);
        sheetBox.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        View b1 = barBtn(R.drawable.ic_hexgear, () -> {
            closeMenu();
            openSettings();
        });
        View b2 = barBtn(R.drawable.ic_chevron, this::closeMenu);
        View b3 = barBtn(R.drawable.ic_power, () -> {
            closeMenu();
            confirmExit();
        });
        bar.addView(b1, new LinearLayout.LayoutParams(0, dp(54), 1));
        bar.addView(b2, new LinearLayout.LayoutParams(0, dp(54), 1));
        bar.addView(b3, new LinearLayout.LayoutParams(0, dp(54), 1));
        sheetBox.addView(bar, new LinearLayout.LayoutParams(-1, -2));
    }

    private View menuItem(int icon, String label, int circle, boolean on, boolean off, final Runnable action) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout holder = new FrameLayout(this);
        if (circle != 0) {
            holder.setBackground(oval(circle));
            holder.addView(Ui.icon(this, icon, 26, Color.WHITE), new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        } else {
            holder.addView(Ui.icon(this, icon, 30, on ? pal.accent : pal.icon), new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER));
        }
        v.addView(holder, new LinearLayout.LayoutParams(dp(54), dp(54)));
        TextView t = Ui.text(this, tr(label), 12, on ? pal.accent : (circle != 0 ? pal.fg : pal.icon), false);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(2);
        t.setPadding(0, dp(7), 0, 0);
        v.addView(t, new LinearLayout.LayoutParams(-1, -2));
        v.setAlpha(off ? 0.35f : 1f);
        if (!off) {
            v.setOnClickListener(x -> {
                closeMenu();
                action.run();
            });
        }
        return v;
    }

    private void share() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, cur.home ? "S.R Browser - Made in India" : cur.url);
        startActivity(Intent.createChooser(i, "Share"));
    }

    private TextView chip(String label, boolean on) {
        TextView t = Ui.text(this, label, 14, on ? Color.WHITE : pal.fg, on);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(9), dp(16), dp(9));
        t.setBackground(Ui.round(this, on ? pal.accent : pal.surface2, 20));
        return t;
    }

    private TextView sectionTitle(String s) {
        TextView t = Ui.text(this, s, 15, pal.fg, true);
        t.setPadding(dp(20), dp(22), dp(20), dp(8));
        return t;
    }

    private void feedback() {
        openPanel(tr("Feedback"), null, null, body -> {
            TextView intro = Ui.text(this, "We love hearing from you. Tell us what you like, what is broken or what you want next. Every message helps make S.R Browser better.", 15, pal.muted, false);
            intro.setPadding(dp(20), dp(16), dp(20), dp(4));
            body.addView(intro);

            body.addView(sectionTitle("What is it about?"));
            final String[] topics = {"Suggestion", "Bug report", "Compliment", "Ads or pop-ups", "Other"};
            final int[] topic = {0};
            final List<TextView> chips = new ArrayList<>();
            LinearLayout wrap = new LinearLayout(this);
            wrap.setOrientation(LinearLayout.VERTICAL);
            wrap.setPadding(dp(16), 0, dp(16), 0);
            LinearLayout line = null;
            for (int i2 = 0; i2 < topics.length; i2++) {
                if (i2 % 3 == 0) {
                    line = new LinearLayout(this);
                    line.setOrientation(LinearLayout.HORIZONTAL);
                    wrap.addView(line, new LinearLayout.LayoutParams(-2, -2));
                }
                final int idx = i2;
                final TextView c = chip(topics[i2], i2 == 0);
                chips.add(c);
                c.setOnClickListener(v -> {
                    topic[0] = idx;
                    for (int k = 0; k < chips.size(); k++) {
                        TextView cc = chips.get(k);
                        boolean on = k == idx;
                        cc.setTextColor(on ? Color.WHITE : pal.fg);
                        cc.setTypeface(null, on ? Typeface.BOLD : Typeface.NORMAL);
                        cc.setBackground(Ui.round(this, on ? pal.accent : pal.surface2, 20));
                    }
                });
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
                cp.setMargins(dp(4), dp(4), dp(4), dp(4));
                line.addView(c, cp);
            }
            body.addView(wrap);

            body.addView(sectionTitle("How would you rate S.R Browser?"));
            final int[] rating = {0};
            final List<TextView> stars = new ArrayList<>();
            LinearLayout sr = new LinearLayout(this);
            sr.setOrientation(LinearLayout.HORIZONTAL);
            sr.setPadding(dp(16), 0, dp(16), 0);
            for (int i2 = 0; i2 < 5; i2++) {
                final int idx = i2;
                TextView s = Ui.text(this, "\u2605", 34, pal.line, false);
                s.setPadding(dp(4), 0, dp(4), 0);
                stars.add(s);
                s.setOnClickListener(v -> {
                    rating[0] = idx + 1;
                    for (int k = 0; k < stars.size(); k++)
                        stars.get(k).setTextColor(k <= idx ? 0xFFFFB400 : pal.line);
                });
                sr.addView(s);
            }
            body.addView(sr);

            body.addView(sectionTitle("Your message"));
            final EditText msg = new EditText(this);
            msg.setHint("Write here... what happened, or what should we add?");
            msg.setHintTextColor(pal.muted);
            msg.setTextColor(pal.fg);
            msg.setTextSize(16);
            msg.setMinLines(5);
            msg.setGravity(Gravity.TOP);
            msg.setPadding(dp(16), dp(14), dp(16), dp(14));
            msg.setBackground(Ui.round(this, pal.surface2, 16));
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
            mp.setMargins(dp(20), 0, dp(20), 0);
            body.addView(msg, mp);

            final EditText contact = new EditText(this);
            contact.setHint("Email or phone (optional)");
            contact.setHintTextColor(pal.muted);
            contact.setTextColor(pal.fg);
            contact.setTextSize(16);
            contact.setSingleLine(true);
            contact.setPadding(dp(16), 0, dp(16), 0);
            contact.setBackground(Ui.round(this, pal.surface2, 16));
            LinearLayout.LayoutParams cp2 = new LinearLayout.LayoutParams(-1, dp(52));
            cp2.setMargins(dp(20), dp(12), dp(20), 0);
            body.addView(contact, cp2);

            TextView send = Ui.text(this, "Send feedback", 17, Color.WHITE, true);
            send.setGravity(Gravity.CENTER);
            send.setBackground(Ui.round(this, pal.accent, 24));
            send.setOnClickListener(v -> {
                String text = msg.getText().toString().trim();
                if (text.isEmpty()) {
                    toast("Please write your message first");
                    return;
                }
                StringBuilder sb = new StringBuilder();
                sb.append("Topic: ").append(topics[topic[0]]).append('\n');
                if (rating[0] > 0) sb.append("Rating: ").append(rating[0]).append("/5\n");
                if (!contact.getText().toString().trim().isEmpty())
                    sb.append("Contact: ").append(contact.getText().toString().trim()).append('\n');
                sb.append("\n").append(text).append("\n\n");
                sb.append("App: S.R Browser ").append(APP_VER).append('\n');
                sb.append("Android ").append(Build.VERSION.RELEASE).append(" | ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL);
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, "S.R Browser feedback - " + topics[topic[0]]);
                i.putExtra(Intent.EXTRA_TEXT, sb.toString());
                startActivity(Intent.createChooser(i, "Send feedback with"));
            });
            LinearLayout.LayoutParams sp2 = new LinearLayout.LayoutParams(-1, dp(54));
            sp2.setMargins(dp(20), dp(18), dp(20), 0);
            body.addView(send, sp2);

            body.addView(sectionTitle("Quick help"));
            String[][] faq = {
                    {"Too many ads or pop-ups?", "Open Settings > Browsing Settings and make sure Block ads and Block pop-ups are on. Tell us the site name and we will block it."},
                    {"A site looks wrong?", "Turn on Desktop Site from the Tools menu, or turn off Data Saver, then reload the page."},
                    {"Video will not download?", "Downloads work when a page has a direct video file. YouTube, Instagram and Facebook protect their videos."},
                    {"Want a clean start?", "Settings > Clear Records lets you clear history, cookies, forms and cache in one tap."}
            };
            for (String[] f : faq) {
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(16), dp(14), dp(16), dp(14));
                card.setBackground(Ui.round(this, pal.surface2, 16));
                card.addView(Ui.text(this, f[0], 15, pal.fg, true));
                TextView a = Ui.text(this, f[1], 14, pal.muted, false);
                a.setPadding(0, dp(4), 0, 0);
                card.addView(a);
                LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
                fp.setMargins(dp(20), 0, dp(20), dp(10));
                body.addView(card, fp);
            }
            View pad = new View(this);
            body.addView(pad, new LinearLayout.LayoutParams(-1, dp(24)));
        });
    }

    private void toggleDesktop(boolean v) {
        store.setDesktop(v);
        applyAllWebPrefs();
        if (!cur.home) cur.web.reload();
    }

    private void about() {
        new AlertDialog.Builder(this).setTitle("S.R Browser")
                .setMessage("Version 1.4\n" + tr("Made in India") + "\nSearch, videos, social and shopping in one place.")
                .setPositiveButton("OK", null).show();
    }

    /* ------------------------------------------------------------------ */
    /* Tab switcher (UC style)                                            */
    /* ------------------------------------------------------------------ */

    private void captureThumb(Tab t) {
        try {
            View v = t.home ? homeView : t.web;
            int w = v.getWidth(), h = v.getHeight();
            if (w <= 0 || h <= 0 || v.getVisibility() != View.VISIBLE) return;
            Bitmap b = Bitmap.createBitmap(w / 2, h / 2, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            c.scale(0.5f, 0.5f);
            v.draw(c);
            t.thumb = b;
        } catch (Throwable ignored) {
        }
    }

    private void openTabs() {
        if (cur != null) captureThumb(cur);
        buildTabsView();
    }

    private void closeTabsView() {
        if (tabsView != null) {
            screen.removeView(tabsView);
            tabsView = null;
        }
        showCurrent();
    }

    private void buildTabsView() {
        if (tabsView != null) screen.removeView(tabsView);
        final boolean inc = store.incognito();
        int bg = inc ? 0xFF272240 : 0xFF3A3A3C;
        final int ac = inc ? PURPLE : Pal.RED;
        int sw = getResources().getDisplayMetrics().widthPixels;
        int sh = getResources().getDisplayMetrics().heightPixels;

        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(bg);
        f.setClickable(true);

        ImageView more = Ui.icon(this, R.drawable.ic_dots, 26, 0xFFFFFFFF);
        more.setPadding(dp(10), dp(10), dp(10), dp(10));
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP | Gravity.END);
        mp.topMargin = dp(36);
        mp.rightMargin = dp(8);
        more.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setItems(new String[]{"Close all tabs"}, (d, which) -> {
                    List<Tab> copy = new ArrayList<>(tabs);
                    for (Tab t : copy) closeTab(t);
                    buildTabsView();
                }).show());
        f.addView(more, mp);

        if (inc) {
            LinearLayout info = new LinearLayout(this);
            info.setOrientation(LinearLayout.VERTICAL);
            info.setGravity(Gravity.CENTER_HORIZONTAL);
            info.setPadding(dp(20), dp(80), dp(20), 0);
            info.addView(Ui.text(this, tr("Incognito mode on"), 19, 0xFFFFFFFF, false));
            TextView d = Ui.text(this, "Browsing and search history will not be saved. Downloaded files and bookmarks are kept.", 13.5f, 0xCCFFFFFF, false);
            d.setGravity(Gravity.CENTER);
            d.setPadding(0, dp(8), 0, 0);
            info.addView(d);
            f.addView(info, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        }

        int cardW = (int) (sw * 0.62f);
        int cardH = (int) Math.min(cardW * 1.9f, sh * 0.52f);
        int gap = dp(18);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout rowL = new LinearLayout(this);
        rowL.setOrientation(LinearLayout.HORIZONTAL);
        rowL.setPadding((sw - cardW) / 2, 0, (sw - cardW) / 2, 0);
        int curIdx = Math.max(0, tabs.indexOf(cur));
        for (final Tab t : new ArrayList<>(tabs)) {
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);

            LinearLayout tl = new LinearLayout(this);
            tl.setOrientation(LinearLayout.HORIZONTAL);
            tl.setGravity(Gravity.CENTER_VERTICAL);
            View bar = new View(this);
            bar.setBackgroundColor(ac);
            tl.addView(bar, new LinearLayout.LayoutParams(dp(2), dp(18)));
            String title = t.home ? "S.R Browser" : (t.title == null || t.title.isEmpty() ? host(t.url) : t.title);
            TextView tt = Ui.oneLine(Ui.text(this, title, 16, ac, true));
            tt.setPadding(dp(8), 0, 0, 0);
            tl.addView(tt, new LinearLayout.LayoutParams(0, -2, 1));
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(cardW, -2);
            tlp.bottomMargin = dp(10);
            col.addView(tl, tlp);

            FrameLayout card = new FrameLayout(this);
            card.setBackground(Ui.round(this, pal.bg, 18));
            card.setElevation(dp(6));
            card.setClipToOutline(true);
            if (t.thumb != null) {
                ImageView iv = new ImageView(this);
                iv.setImageBitmap(t.thumb);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                card.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            } else {
                String hn = t.home ? "S.R" : host(t.url);
                String letter = hn.isEmpty() ? "?" : hn.substring(0, 1).toUpperCase();
                TextView l = Ui.text(this, letter, 40, pal.accent, true);
                l.setGravity(Gravity.CENTER);
                card.addView(l, new FrameLayout.LayoutParams(-1, -1));
            }
            FrameLayout bottom = new FrameLayout(this);
            bottom.setBackgroundColor(0xAA000000);
            ImageView x = Ui.icon(this, R.drawable.ic_close, 26, 0xFFFFFFFF);
            bottom.addView(x, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
            bottom.setOnClickListener(v -> {
                closeTab(t);
                buildTabsView();
            });
            card.addView(bottom, new FrameLayout.LayoutParams(-1, dp(52), Gravity.BOTTOM));
            card.setOnClickListener(v -> {
                switchTo(t);
                closeTabsView();
            });
            final LinearLayout colRef = col;
            final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
            final View.OnTouchListener swipe = new View.OnTouchListener() {
                float dx0, dy0;
                boolean swiping;

                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            dx0 = e.getRawX();
                            dy0 = e.getRawY();
                            swiping = false;
                            return false;
                        case MotionEvent.ACTION_MOVE: {
                            float dy = e.getRawY() - dy0;
                            float dx = e.getRawX() - dx0;
                            if (!swiping && dy < -slop && Math.abs(dy) > Math.abs(dx) * 1.2f) {
                                swiping = true;
                                v.getParent().requestDisallowInterceptTouchEvent(true);
                            }
                            if (swiping) {
                                float ty = Math.min(0, dy);
                                colRef.setTranslationY(ty);
                                colRef.setAlpha(Math.max(0.25f, 1f + ty / (sh * 0.5f)));
                                return true;
                            }
                            return false;
                        }
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            if (swiping) {
                                swiping = false;
                                float ty = colRef.getTranslationY();
                                if (ty < -dp(110) && e.getActionMasked() == MotionEvent.ACTION_UP) {
                                    colRef.animate().translationY(-sh).alpha(0f).setDuration(200).withEndAction(() -> {
                                        closeTab(t);
                                        buildTabsView();
                                    }).start();
                                } else {
                                    colRef.animate().translationY(0).alpha(1f).setDuration(180).start();
                                }
                                return true;
                            }
                            return false;
                    }
                    return false;
                }
            };
            card.setOnTouchListener(swipe);
            tl.setOnTouchListener(swipe);
            col.addView(card, new LinearLayout.LayoutParams(cardW, cardH));

            LinearLayout.LayoutParams colp = new LinearLayout.LayoutParams(-2, -2);
            colp.rightMargin = gap;
            rowL.addView(col, colp);
        }
        hs.addView(rowL, new ViewGroup.LayoutParams(-2, -2));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER_VERTICAL);
        hp.topMargin = dp(inc ? 70 : 20);
        f.addView(hs, hp);
        final int scrollTo = curIdx * (cardW + gap);
        hs.post(() -> hs.scrollTo(scrollTo, 0));

        // Bottom: incognito, new tab, undo
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);

        FrameLayout g = new FrameLayout(this);
        g.addView(Ui.icon(this, R.drawable.ic_ghost, 32, inc ? PURPLE : 0xFFFFFFFF),
                new FrameLayout.LayoutParams(dp(32), dp(32), Gravity.CENTER));
        g.setOnClickListener(v -> {
            store.setIncognito(!store.incognito());
            updateTabBtn();
            buildTabsView();
        });
        bar.addView(g, new LinearLayout.LayoutParams(dp(64), dp(64)));

        FrameLayout plus = new FrameLayout(this);
        plus.setBackground(oval(ac));
        plus.addView(Ui.icon(this, R.drawable.ic_plus, 34, 0xFFFFFFFF), new FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER));
        plus.setElevation(dp(4));
        plus.setOnClickListener(v -> {
            closeTabsView();
            newTab();
        });
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(dp(66), dp(66));
        plp.leftMargin = dp(28);
        plp.rightMargin = dp(28);
        bar.addView(plus, plp);

        FrameLayout u = new FrameLayout(this);
        u.addView(Ui.icon(this, R.drawable.ic_undo, 30, 0xFFFFFFFF), new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER));
        u.setOnClickListener(v -> {
            if (closedUrls.isEmpty()) {
                toast("No closed tabs");
                return;
            }
            String last = closedUrls.remove(closedUrls.size() - 1);
            Tab nt = newTab();
            if (!last.isEmpty()) loadIn(nt, last);
            buildTabsView();
        });
        bar.addView(u, new LinearLayout.LayoutParams(dp(64), dp(64)));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        bp.bottomMargin = dp(36);
        f.addView(bar, bp);

        tabsView = f;
        screen.addView(f, new FrameLayout.LayoutParams(-1, -1));
    }

    /* ------------------------------------------------------------------ */
    /* Panels (stack)                                                     */
    /* ------------------------------------------------------------------ */

    private PanelState openPanel(String title, String rightLabel, Runnable rightAction,
                                 String bottomLabel, Runnable bottomAction, Renderer r) {
        final PanelState ps = new PanelState();
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackgroundColor(pal.bg);
        p.setClickable(true);

        FrameLayout head = new FrameLayout(this);
        head.setBackgroundColor(pal.bg);
        ImageView back = Ui.icon(this, R.drawable.ic_back, 26, pal.fg);
        back.setPadding(dp(10), dp(10), dp(10), dp(10));
        back.setOnClickListener(v -> closePanel());
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER_VERTICAL | Gravity.START);
        bl.leftMargin = dp(6);
        head.addView(back, bl);
        TextView tt = Ui.text(this, title, 19, pal.fg, true);
        head.addView(tt, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        if (rightLabel != null) {
            TextView a = Ui.text(this, rightLabel, 14.5f, pal.accent, true);
            a.setPadding(dp(10), dp(10), dp(10), dp(10));
            a.setOnClickListener(v -> rightAction.run());
            FrameLayout.LayoutParams al = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_VERTICAL | Gravity.END);
            al.rightMargin = dp(10);
            head.addView(a, al);
        }
        p.addView(head, new LinearLayout.LayoutParams(-1, dp(56)));

        ScrollView sv = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(6), dp(14), dp(24));
        sv.addView(body, new ViewGroup.LayoutParams(-1, -2));
        p.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        if (bottomLabel != null) {
            View line = new View(this);
            line.setBackgroundColor(pal.line);
            p.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
            TextView bt = Ui.text(this, bottomLabel, 17, pal.muted, false);
            bt.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            bt.setPadding(dp(24), 0, dp(24), 0);
            bt.setBackgroundColor(pal.bar);
            bt.setOnClickListener(v -> bottomAction.run());
            p.addView(bt, new LinearLayout.LayoutParams(-1, dp(58)));
        }

        ps.view = p;
        ps.body = body;
        ps.renderer = r;
        ps.id = title;
        panels.add(ps);
        screen.addView(p, new FrameLayout.LayoutParams(-1, -1));
        r.render(body);
        return ps;
    }

    private PanelState openPanel(String title, String rightLabel, Runnable rightAction, Renderer r) {
        return openPanel(title, rightLabel, rightAction, null, null, r);
    }

    private void refreshPanel() {
        if (panels.isEmpty()) return;
        PanelState ps = panels.get(panels.size() - 1);
        ps.body.removeAllViews();
        ps.renderer.render(ps.body);
    }

    private void closePanel() {
        if (panels.isEmpty()) return;
        PanelState ps = panels.remove(panels.size() - 1);
        screen.removeView(ps.view);
        refreshPanel();
    }

    private void closeAllPanels() {
        while (!panels.isEmpty()) {
            PanelState ps = panels.remove(panels.size() - 1);
            screen.removeView(ps.view);
        }
    }

    private LinearLayout card(LinearLayout body) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Ui.round(this, pal.surface, 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(14);
        body.addView(c, lp);
        return c;
    }

    private void emptyState(LinearLayout body, int icon, String msg) {
        LinearLayout e = new LinearLayout(this);
        e.setOrientation(LinearLayout.VERTICAL);
        e.setGravity(Gravity.CENTER);
        e.setPadding(dp(16), dp(90), dp(16), dp(40));
        if (icon != 0) {
            ImageView iv = Ui.icon(this, icon, 84, pal.line);
            e.addView(iv, new LinearLayout.LayoutParams(dp(84), dp(84)));
        }
        TextView t = Ui.text(this, msg, 17, pal.muted, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(18), 0, 0);
        e.addView(t);
        body.addView(e, new LinearLayout.LayoutParams(-1, -2));
    }

    private void renderRows(LinearLayout body, List<Row> rows, String empty, int emptyIcon) {
        if (rows.isEmpty()) {
            emptyState(body, emptyIcon, empty);
            return;
        }
        LinearLayout c = card(body);
        for (int i = 0; i < rows.size(); i++) {
            final Row r = rows.get(i);
            if (i > 0) {
                View d = new View(this);
                d.setBackgroundColor(pal.line);
                c.addView(d, new LinearLayout.LayoutParams(-1, dp(1)));
            }
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(11), dp(8), dp(11));

            FrameLayout ib = new FrameLayout(this);
            ib.setBackground(Ui.round(this, pal.surface2, 11));
            if (r.icon != 0) {
                ib.addView(Ui.icon(this, r.icon, 20, pal.accent), new FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER));
            } else {
                String l = r.title.isEmpty() ? "?" : r.title.substring(0, 1).toUpperCase();
                TextView lt = Ui.text(this, l, 16, pal.accent, true);
                lt.setGravity(Gravity.CENTER);
                ib.addView(lt, new FrameLayout.LayoutParams(-1, -1));
            }
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(38), dp(38));
            ip.rightMargin = dp(12);
            row.addView(ib, ip);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(Ui.oneLine(Ui.text(this, r.title, 15, pal.fg, true)));
            if (r.sub != null && !r.sub.isEmpty()) col.addView(Ui.oneLine(Ui.text(this, r.sub, 12, pal.muted, false)));
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));

            if (r.delete != null) {
                ImageView x = Ui.icon(this, R.drawable.ic_close, 20, pal.muted);
                x.setPadding(dp(10), dp(10), dp(10), dp(10));
                x.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
                x.setOnClickListener(v -> r.delete.run());
                row.addView(x);
            }
            row.setOnClickListener(v -> {
                if (r.click != null) r.click.run();
            });
            c.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    /* ---- Bookmarks ---- */

    private void openBookmarks() {
        openPanel(tr("Bookmarks"), "+ Add", this::promptAddSite, body -> {
            List<Row> rows = new ArrayList<>();
            List<Store.Item> l = store.list("bm");
            for (int i = 0; i < l.size(); i++) {
                final Store.Item it = l.get(i);
                final int idx = i;
                rows.add(new Row(it.title, host(it.url), 0, () -> {
                    closeAllPanels();
                    loadIn(cur, it.url);
                }, () -> {
                    store.remove("bm", idx);
                    refreshHome();
                    refreshPanel();
                }));
            }
            renderRows(body, rows, "No bookmarks yet. Tap the star in the menu to save a page.", R.drawable.ic_bookmark_o);
        });
    }

    /* ---- History (Video / Website) ---- */

    private void openHistory() {
        openPanel(tr("History"), null, null, tr("Edit"), this::editHistory, this::renderHistory);
    }

    private void editHistory() {
        final String key = histTab == 0 ? "vhist" : "hist";
        new AlertDialog.Builder(this).setTitle(histTab == 0 ? "Video history" : "Website history")
                .setItems(new String[]{"Clear all"}, (d, which) -> {
                    store.clear(key);
                    refreshPanel();
                }).show();
    }

    private void renderHistory(LinearLayout body) {
        LinearLayout tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {tr("Video"), tr("Website")};
        for (int i = 0; i < 2; i++) {
            final int idx = i;
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setGravity(Gravity.CENTER_HORIZONTAL);
            TextView t = Ui.text(this, names[i], 18, i == histTab ? pal.fg : pal.muted, i == histTab);
            t.setPadding(0, dp(8), 0, dp(6));
            c.addView(t);
            View u = new View(this);
            u.setBackgroundColor(i == histTab ? pal.fg : Color.TRANSPARENT);
            c.addView(u, new LinearLayout.LayoutParams(dp(48), dp(3)));
            c.setOnClickListener(v -> {
                histTab = idx;
                refreshPanel();
            });
            tabsRow.addView(c, new LinearLayout.LayoutParams(0, -2, 1));
        }
        body.addView(tabsRow, new LinearLayout.LayoutParams(-1, -2));

        List<Row> rows = new ArrayList<>();
        final String key = histTab == 0 ? "vhist" : "hist";
        List<Store.Item> l = store.list(key);
        for (int i = 0; i < l.size(); i++) {
            final Store.Item it = l.get(i);
            final int idx = i;
            rows.add(new Row(it.title, host(it.url), histTab == 0 ? R.drawable.ic_video : 0, () -> {
                closeAllPanels();
                loadIn(cur, it.url);
            }, () -> {
                store.remove(key, idx);
                refreshPanel();
            }));
        }
        LinearLayout holder = new LinearLayout(this);
        holder.setOrientation(LinearLayout.VERTICAL);
        holder.setPadding(0, dp(12), 0, 0);
        body.addView(holder, new LinearLayout.LayoutParams(-1, -2));
        renderRows(holder, rows, histTab == 0 ? "Your player history will show up here" : "No sites visited yet",
                R.drawable.ic_video);
    }

    /* ---- Downloads (UC style) ---- */

    static final class DlState {
        int status = -1;
        long got, total;
        String reason = "";
    }

    static final class DlHolder {
        ProgressBar bar;
        TextView info;
        int status;
    }

    private static final String[] DL_CATS = {"All", "Video", "Music", "Image", "Document", "APK", "Others"};
    private static final int[] DL_CAT_COLOR = {0xFF8A90A0, 0xFFE5121B, 0xFFF59E0B, 0xFF10B981, 0xFF3B82F6, 0xFF22A35A, 0xFF8B5CF6};
    private int dlTab = 0;
    private int dlCat = 0;
    private PanelState dlPanel;
    private final java.util.Map<Long, DlHolder> dlViews = new java.util.HashMap<>();
    private final java.util.Map<Long, long[]> dlSpeed = new java.util.HashMap<>();
    private android.content.BroadcastReceiver dlDone;
    private TextView snackView;

    private static long dlId(Store.Item it) {
        try {
            int b = it.url.indexOf('|');
            return Long.parseLong(b < 0 ? it.url : it.url.substring(0, b));
        } catch (Exception e) {
            return -1;
        }
    }

    private static String dlSrc(Store.Item it) {
        int b = it.url.indexOf('|');
        return b < 0 ? "" : it.url.substring(b + 1);
    }

    private static String ext(String name) {
        int d = name == null ? -1 : name.lastIndexOf('.');
        return d < 0 || d == name.length() - 1 ? "" : name.substring(d + 1).toLowerCase();
    }

    /** 1 video, 2 music, 3 image, 4 document, 5 apk, 6 others. */
    private static int dlCatOf(String name) {
        String e = ext(name);
        switch (e) {
            case "mp4": case "mkv": case "webm": case "3gp": case "avi": case "mov": case "m4v": case "flv": case "ts": case "m3u8":
                return 1;
            case "mp3": case "m4a": case "aac": case "wav": case "ogg": case "flac": case "opus": case "amr":
                return 2;
            case "jpg": case "jpeg": case "png": case "gif": case "webp": case "bmp": case "heic": case "svg":
                return 3;
            case "pdf": case "doc": case "docx": case "xls": case "xlsx": case "ppt": case "pptx": case "txt": case "csv": case "epub": case "rtf":
                return 4;
            case "apk": case "xapk": case "apks":
                return 5;
            default:
                return 6;
        }
    }

    private static String fmtSize(long b) {
        if (b < 0) return "?";
        if (b < 1024) return b + " B";
        if (b < 1024L * 1024) return String.format(java.util.Locale.US, "%.0f KB", b / 1024f);
        if (b < 1024L * 1024 * 1024) return String.format(java.util.Locale.US, "%.1f MB", b / 1048576f);
        return String.format(java.util.Locale.US, "%.2f GB", b / 1073741824f);
    }

    private View fileBadge(String name, int sizeDp) {
        int cat = dlCatOf(name);
        FrameLayout f = new FrameLayout(this);
        f.setBackground(Ui.round(this, DL_CAT_COLOR[cat], 12));
        String e = ext(name).toUpperCase();
        if (e.isEmpty() || e.length() > 4) e = "FILE";
        TextView t = Ui.text(this, e, sizeDp > 44 ? 12 : 10.5f, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        f.addView(t, new FrameLayout.LayoutParams(-1, -1));
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        return f;
    }

    /** One cursor for all ids: fast even with many downloads. */
    private java.util.Map<Long, DlState> dlStates(List<Store.Item> l) {
        java.util.Map<Long, DlState> out = new java.util.HashMap<>();
        if (l.isEmpty()) return out;
        long[] ids = new long[l.size()];
        for (int i = 0; i < l.size(); i++) ids[i] = dlId(l.get(i));
        try {
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            Cursor c = dm.query(new DownloadManager.Query().setFilterById(ids));
            if (c == null) return out;
            try {
                int iId = c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID);
                int iSt = c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS);
                int iGot = c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR);
                int iTot = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES);
                int iRe = c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON);
                while (c.moveToNext()) {
                    DlState s = new DlState();
                    s.status = c.getInt(iSt);
                    s.got = c.getLong(iGot);
                    s.total = c.getLong(iTot);
                    int re = c.getInt(iRe);
                    if (s.status == DownloadManager.STATUS_PAUSED) {
                        if (re == DownloadManager.PAUSED_QUEUED_FOR_WIFI) s.reason = "Waiting for Wi-Fi";
                        else if (re == DownloadManager.PAUSED_WAITING_FOR_NETWORK) s.reason = "Waiting for network";
                        else if (re == DownloadManager.PAUSED_WAITING_TO_RETRY) s.reason = "Retrying...";
                        else s.reason = "Paused";
                    } else if (s.status == DownloadManager.STATUS_FAILED) {
                        if (re == DownloadManager.ERROR_INSUFFICIENT_SPACE) s.reason = "Not enough storage";
                        else if (re == DownloadManager.ERROR_FILE_ALREADY_EXISTS) s.reason = "File already exists";
                        else if (re >= 400 && re < 600) s.reason = "Server error " + re;
                        else s.reason = "Failed";
                    }
                    out.put(c.getLong(iId), s);
                }
            } finally {
                c.close();
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private boolean dlActive(DlState s) {
        return s != null && (s.status == DownloadManager.STATUS_RUNNING || s.status == DownloadManager.STATUS_PENDING
                || s.status == DownloadManager.STATUS_PAUSED);
    }

    private String dlLine(long id, DlState s) {
        if (s == null) return tr("File removed");
        if (s.status == DownloadManager.STATUS_SUCCESSFUL) return fmtSize(s.total);
        if (s.status == DownloadManager.STATUS_FAILED) return s.reason;
        if (s.status == DownloadManager.STATUS_PENDING) return tr("Waiting...");
        String size = fmtSize(s.got) + (s.total > 0 ? " / " + fmtSize(s.total) : "");
        if (s.status == DownloadManager.STATUS_PAUSED) return size + "  ·  " + s.reason;
        long now = System.currentTimeMillis();
        long[] prev = dlSpeed.get(id);
        String speed = "";
        if (prev != null && now > prev[1]) {
            long bps = (s.got - prev[0]) * 1000 / Math.max(1, now - prev[1]);
            if (bps > 0) speed = "  ·  " + fmtSize(bps) + "/s";
            if (bps > 0 && s.total > 0) {
                long left = (s.total - s.got) / bps;
                speed += left < 60 ? "  ·  " + left + "s left" : "  ·  " + (left / 60) + "m left";
            }
            if (now - prev[1] < 600) return null; // keep previous text, too soon
        }
        dlSpeed.put(id, new long[]{s.got, now});
        return size + speed;
    }

    private void openDownloadedFile(long id) {
        try {
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            Uri u = dm.getUriForDownloadedFile(id);
            String m = dm.getMimeTypeForDownloadedFile(id);
            if (u == null) {
                toast(tr("File not found"));
                return;
            }
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, m == null ? "*/*" : m);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(Intent.createChooser(i, tr("Open with")));
        } catch (Exception e) {
            toast(tr("No app found to open this file"));
        }
    }

    private void shareDownloadedFile(long id) {
        try {
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            Uri u = dm.getUriForDownloadedFile(id);
            String m = dm.getMimeTypeForDownloadedFile(id);
            if (u == null) {
                toast(tr("File not found"));
                return;
            }
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(m == null ? "*/*" : m);
            i.putExtra(Intent.EXTRA_STREAM, u);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, tr("Share")));
        } catch (Exception e) {
            toast(tr("Could not share this file"));
        }
    }

    private void removeDownload(long id, boolean deleteFile) {
        if (deleteFile) {
            try {
                ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).remove(id);
            } catch (Exception ignored) {
            }
        }
        List<Store.Item> l = store.list("dl");
        for (int i = l.size() - 1; i >= 0; i--) {
            if (dlId(l.get(i)) == id) store.remove("dl", i);
        }
        dlViews.remove(id);
        dlSpeed.remove(id);
        refreshPanel();
    }

    private void downloadActions(final Store.Item it, final long id, final boolean done) {
        LinearLayout c = ucCard(true);
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(0, 0, 0, dp(10));
        View badge = fileBadge(it.title, 46);
        ((LinearLayout.LayoutParams) badge.getLayoutParams()).rightMargin = dp(12);
        head.addView(badge);
        TextView nm = Ui.text(this, it.title, 16, pal.fg, true);
        nm.setMaxLines(2);
        nm.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        head.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
        c.addView(head);
        final Dialog d = ucShow(c, true);
        if (done) {
            c.addView(sheetRow(R.drawable.ic_sharebox, "Open", () -> {
                d.dismiss();
                openDownloadedFile(id);
            }));
            c.addView(sheetRow(R.drawable.ic_share, "Share", () -> {
                d.dismiss();
                shareDownloadedFile(id);
            }));
        }
        final String src = dlSrc(it);
        if (!src.isEmpty()) {
            c.addView(sheetRow(R.drawable.ic_notes, "Copy download link", () -> {
                d.dismiss();
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("link", src));
                toast(tr("Link copied"));
            }));
            c.addView(sheetRow(R.drawable.ic_refresh, "Download again", () -> {
                d.dismiss();
                removeDownload(id, !done);
                enqueue(src, mobileUa, null, it.title);
            }));
        }
        c.addView(sheetRow(R.drawable.ic_close, "Remove from list", () -> {
            d.dismiss();
            removeDownload(id, false);
        }));
        c.addView(sheetRow(R.drawable.ic_trash, done ? "Delete file" : "Cancel download", () -> {
            d.dismiss();
            removeDownload(id, true);
            toast(tr(done ? "File deleted" : "Download cancelled"));
        }));
    }

    private View sheetRow(int icon, String label, final Runnable r) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(6), dp(14), dp(6), dp(14));
        ImageView iv = Ui.icon(this, icon, 22, pal.icon);
        ((LinearLayout.LayoutParams) iv.getLayoutParams()).rightMargin = dp(18);
        row.addView(iv);
        row.addView(Ui.text(this, tr(label), 16.5f, pal.fg, false));
        row.setOnClickListener(v -> r.run());
        return row;
    }

    private void openDownloader() {
        dlViews.clear();
        dlPanel = openPanel(tr("Downloads"), "+ " + tr("Link"), this::promptDownloadLink, this::renderDownloads);
        ui.removeCallbacks(dlTick);
        ui.postDelayed(dlTick, 1000);
    }

    private boolean dlPanelOnTop() {
        return dlPanel != null && !panels.isEmpty() && panels.get(panels.size() - 1) == dlPanel;
    }

    /** Updates progress in place once a second; rebuilds the list only when a download changes state. */
    private final Runnable dlTick = new Runnable() {
        @Override
        public void run() {
            if (dlPanel == null || !panels.contains(dlPanel)) {
                dlPanel = null;
                return;
            }
            if (dlPanelOnTop()) {
                List<Store.Item> l = store.list("dl");
                java.util.Map<Long, DlState> st = dlStates(l);
                boolean rebuild = false;
                for (java.util.Map.Entry<Long, DlHolder> e : dlViews.entrySet()) {
                    DlState s = st.get(e.getKey());
                    int now = s == null ? -1 : s.status;
                    if (now != e.getValue().status) {
                        rebuild = true;
                        break;
                    }
                    if (s != null && dlActive(s)) {
                        DlHolder h = e.getValue();
                        if (s.total > 0) {
                            h.bar.setIndeterminate(false);
                            h.bar.setProgress((int) (s.got * 1000 / s.total));
                        }
                        String line = dlLine(e.getKey(), s);
                        if (line != null) h.info.setText(line);
                    }
                }
                if (rebuild) refreshPanel();
            }
            ui.postDelayed(this, 1000);
        }
    };

    private void renderDownloads(LinearLayout body) {
        dlViews.clear();
        body.setPadding(0, 0, 0, dp(16));
        final List<Store.Item> all = store.list("dl");
        java.util.Map<Long, DlState> st = dlStates(all);
        List<Store.Item> running = new ArrayList<>(), finished = new ArrayList<>();
        for (Store.Item it : all) {
            DlState s = st.get(dlId(it));
            if (s != null && s.status == DownloadManager.STATUS_SUCCESSFUL) finished.add(it);
            else running.add(it);
        }

        // Tabs: Downloading / Downloaded
        LinearLayout tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {tr("Downloading") + " (" + running.size() + ")", tr("Downloaded") + " (" + finished.size() + ")"};
        for (int i = 0; i < 2; i++) {
            final int idx = i;
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setGravity(Gravity.CENTER_HORIZONTAL);
            TextView t = Ui.text(this, names[i], 16, i == dlTab ? pal.fg : pal.muted, i == dlTab);
            t.setPadding(0, dp(8), 0, dp(8));
            c.addView(t);
            View u = new View(this);
            u.setBackground(Ui.round(this, i == dlTab ? pal.accent : Color.TRANSPARENT, 2));
            c.addView(u, new LinearLayout.LayoutParams(dp(36), dp(3)));
            c.setOnClickListener(v -> {
                dlTab = idx;
                refreshPanel();
            });
            tabsRow.addView(c, new LinearLayout.LayoutParams(0, -2, 1));
        }
        body.addView(tabsRow, new LinearLayout.LayoutParams(-1, -2));
        View tl = new View(this);
        tl.setBackgroundColor(pal.line);
        body.addView(tl, new LinearLayout.LayoutParams(-1, dp(1)));

        List<Store.Item> show = new ArrayList<>();
        if (dlTab == 1) {
            // Category chips
            HorizontalScrollView hs = new HorizontalScrollView(this);
            hs.setHorizontalScrollBarEnabled(false);
            LinearLayout chips = new LinearLayout(this);
            chips.setOrientation(LinearLayout.HORIZONTAL);
            chips.setPadding(dp(12), dp(12), dp(12), dp(4));
            for (int i = 0; i < DL_CATS.length; i++) {
                final int ci = i;
                int n = 0;
                for (Store.Item it : finished) if (i == 0 || dlCatOf(it.title) == i) n++;
                if (i != 0 && n == 0 && i != dlCat) continue;
                TextView ch = chip(tr(DL_CATS[i]) + (n > 0 ? " " + n : ""), i == dlCat);
                ch.setOnClickListener(v -> {
                    dlCat = ci;
                    refreshPanel();
                });
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
                cp.rightMargin = dp(8);
                chips.addView(ch, cp);
            }
            hs.addView(chips);
            body.addView(hs, new LinearLayout.LayoutParams(-1, -2));
            for (Store.Item it : finished) if (dlCat == 0 || dlCatOf(it.title) == dlCat) show.add(it);
        } else {
            show = running;
        }

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(14), dp(10), dp(14), 0);
        body.addView(list, new LinearLayout.LayoutParams(-1, -2));

        if (show.isEmpty()) {
            emptyState(list, R.drawable.ic_dl_hex, dlTab == 0
                    ? tr("No active downloads.\nTap + Link or download from any page.")
                    : tr("No downloaded files yet"));
        } else {
            LinearLayout card = card(list);
            for (int i = 0; i < show.size(); i++) {
                if (i > 0) {
                    View d = new View(this);
                    d.setBackgroundColor(pal.line);
                    LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, dp(1));
                    dl.leftMargin = dp(70);
                    card.addView(d, dl);
                }
                card.addView(dlRow(show.get(i), st));
            }
        }

        if (dlTab == 1 && !finished.isEmpty()) {
            TextView clear = Ui.text(this, tr("Clear download list"), 14, pal.accent, true);
            clear.setGravity(Gravity.CENTER);
            clear.setPadding(0, dp(14), 0, dp(6));
            clear.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle(tr("Clear download list"))
                    .setMessage(tr("Files stay on your phone. Only the list is cleared."))
                    .setPositiveButton(tr("Clear"), (dd, w) -> {
                        List<Store.Item> l = store.list("dl");
                        java.util.Map<Long, DlState> s2 = dlStates(l);
                        for (int k = l.size() - 1; k >= 0; k--) {
                            DlState s = s2.get(dlId(l.get(k)));
                            if (s != null && s.status == DownloadManager.STATUS_SUCCESSFUL) store.remove("dl", k);
                        }
                        refreshPanel();
                    }).setNegativeButton(tr("Cancel"), null).show());
            body.addView(clear, new LinearLayout.LayoutParams(-1, -2));
        }

        body.addView(storageBar());
    }

    private View dlRow(final Store.Item it, java.util.Map<Long, DlState> st) {
        final long id = dlId(it);
        final DlState s = st.get(id);
        final boolean done = s != null && s.status == DownloadManager.STATUS_SUCCESSFUL;
        final boolean failed = s == null || s.status == DownloadManager.STATUS_FAILED;

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(12), dp(6), dp(12));
        View badge = fileBadge(it.title, 44);
        ((LinearLayout.LayoutParams) badge.getLayoutParams()).rightMargin = dp(14);
        row.addView(badge);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView nm = Ui.text(this, it.title, 15, pal.fg, true);
        nm.setSingleLine(true);
        nm.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        col.addView(nm);
        DlHolder h = new DlHolder();
        h.status = s == null ? -1 : s.status;
        if (!done && !failed) {
            ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            pb.setMax(1000);
            pb.setProgressTintList(ColorStateList.valueOf(pal.accent));
            pb.setProgressBackgroundTintList(ColorStateList.valueOf(pal.line));
            if (s.total > 0) pb.setProgress((int) (s.got * 1000 / s.total));
            else pb.setIndeterminate(true);
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(4));
            pp.topMargin = dp(8);
            pp.bottomMargin = dp(6);
            col.addView(pb, pp);
            h.bar = pb;
        }
        String line = done ? fmtSize(s.total) + "  ·  " + tr("Completed") : dlLine(id, s);
        if (line == null) line = "";
        TextView info = Ui.text(this, line, 12.5f, failed ? pal.accent : pal.muted, false);
        info.setSingleLine(true);
        if (done || failed) info.setPadding(0, dp(4), 0, 0);
        col.addView(info);
        h.info = info;
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));

        // Trailing action, like UC: cancel while downloading, retry when failed, more when done
        int icon = done ? R.drawable.ic_dots : failed ? R.drawable.ic_refresh : R.drawable.ic_cancel;
        ImageView act = Ui.icon(this, icon, 22, failed ? pal.accent : pal.muted);
        act.setPadding(dp(11), dp(11), dp(11), dp(11));
        act.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        act.setOnClickListener(v -> {
            if (done) downloadActions(it, id, true);
            else if (failed) {
                String src = dlSrc(it);
                if (src.isEmpty()) {
                    toast(tr("Link not saved for this file. Download it again from the page."));
                    return;
                }
                removeDownload(id, true);
                enqueue(src, mobileUa, null, it.title);
            } else {
                removeDownload(id, true);
                toast(tr("Download cancelled"));
            }
        });
        row.addView(act);
        row.setOnClickListener(v -> {
            if (done) openDownloadedFile(id);
            else downloadActions(it, id, false);
        });
        row.setOnLongClickListener(v -> {
            downloadActions(it, id, done);
            return true;
        });
        dlViews.put(id, h);
        return row;
    }

    private View storageBar() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        box.setBackground(Ui.round(this, pal.surface, 14));
        try {
            android.os.StatFs fs = new android.os.StatFs(Environment.getExternalStorageDirectory().getPath());
            long total = fs.getTotalBytes(), free = fs.getAvailableBytes();
            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.addView(Ui.text(this, tr("Phone storage"), 14, pal.fg, true), new LinearLayout.LayoutParams(0, -2, 1));
            top.addView(Ui.text(this, fmtSize(free) + " " + tr("free of") + " " + fmtSize(total), 12.5f, pal.muted, false));
            box.addView(top);
            ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            pb.setMax(1000);
            pb.setProgress(total > 0 ? (int) ((total - free) * 1000 / total) : 0);
            pb.setProgressTintList(ColorStateList.valueOf(free < total / 10 ? pal.accent : 0xFF3B82F6));
            pb.setProgressBackgroundTintList(ColorStateList.valueOf(pal.line));
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(5));
            pp.topMargin = dp(10);
            box.addView(pb, pp);
            TextView where = Ui.text(this, tr("Saved in: Internal storage / Download"), 12, pal.muted, false);
            where.setPadding(0, dp(8), 0, 0);
            box.addView(where);
        } catch (Exception e) {
            box.addView(Ui.text(this, tr("Saved in: Internal storage / Download"), 13, pal.muted, false));
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(16), dp(14), 0);
        box.setLayoutParams(lp);
        return box;
    }

    private void promptDownloadLink() {
        LinearLayout c = ucCard(true);
        c.addView(ucTitle("Download from link"));
        final EditText e = ucInput("https://site.com/file.mp4", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
                CharSequence cs = cm.getPrimaryClip().getItemAt(0).getText();
                if (cs != null && cs.toString().trim().startsWith("http")) e.setText(cs.toString().trim());
            }
        } catch (Exception ignored) {
        }
        c.addView(e);
        final Dialog d = ucShow(c, true);
        c.addView(ucBtn("Download", true, v -> {
            String u = e.getText().toString().trim();
            if (!u.startsWith("http://") && !u.startsWith("https://")) {
                toast(tr("Enter the full link, starting with https://"));
                return;
            }
            d.dismiss();
            startDownload(u, mobileUa, null, null, -1);
        }));
        c.addView(ucBtn("Cancel", false, v -> d.dismiss()));
    }

    /** Small UC style toast bar with an action, shown above the bottom bar. */
    private void snack(String msg, String action, final Runnable r) {
        if (snackView != null) screen.removeView(snackView);
        final TextView s = Ui.text(this, action == null ? msg : msg + "     " + action, 14, Color.WHITE, false);
        s.setSingleLine(true);
        s.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        s.setPadding(dp(18), dp(13), dp(18), dp(13));
        s.setBackground(Ui.round(this, 0xF01C2024, 24));
        s.setElevation(dp(6));
        if (action != null) {
            android.text.SpannableString ss = new android.text.SpannableString(s.getText());
            int st = ss.length() - action.length();
            ss.setSpan(new android.text.style.ForegroundColorSpan(0xFFFF6B6B), st, ss.length(), 0);
            ss.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), st, ss.length(), 0);
            s.setText(ss);
            s.setOnClickListener(v -> {
                screen.removeView(s);
                if (snackView == s) snackView = null;
                r.run();
            });
        }
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        lp.bottomMargin = dp(84);
        lp.leftMargin = dp(16);
        lp.rightMargin = dp(16);
        s.setAlpha(0f);
        s.setTranslationY(dp(20));
        screen.addView(s, lp);
        s.animate().alpha(1f).translationY(0).setDuration(220).start();
        snackView = s;
        ui.postDelayed(() -> {
            if (snackView == s) {
                s.animate().alpha(0f).setDuration(220).withEndAction(() -> {
                    screen.removeView(s);
                    if (snackView == s) snackView = null;
                }).start();
            }
        }, 3500);
    }

    private void registerDownloadDone() {
        dlDone = new android.content.BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                final long id = i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                String name = null;
                for (Store.Item it : store.list("dl")) if (dlId(it) == id) name = it.title;
                if (name == null) return;
                List<Store.Item> one = new ArrayList<>();
                one.add(new Store.Item(name, String.valueOf(id)));
                DlState s = dlStates(one).get(id);
                if (s != null && s.status == DownloadManager.STATUS_SUCCESSFUL) {
                    snack(tr("Download complete") + ": " + name, tr("OPEN"), () -> openDownloadedFile(id));
                } else if (s != null && s.status == DownloadManager.STATUS_FAILED) {
                    snack(tr("Download failed") + ": " + name, tr("VIEW"), MainActivity.this::openDownloader);
                }
                if (dlPanelOnTop()) refreshPanel();
            }
        };
        android.content.IntentFilter f = new android.content.IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        try {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(dlDone, f, Context.RECEIVER_EXPORTED);
            else registerReceiver(dlDone, f);
        } catch (Exception e) {
            dlDone = null;
        }
    }

    /* ---- Notes ---- */

    private void openNotes() {
        openPanel(tr("Notes"), "+ New", () -> editNote(-1), body -> {
            List<Row> rows = new ArrayList<>();
            List<Store.Item> l = store.list("notes");
            for (int i = 0; i < l.size(); i++) {
                final Store.Item it = l.get(i);
                final int idx = i;
                String first = it.title.split("\n")[0];
                rows.add(new Row(first, it.title.length() > first.length() ? it.title.substring(first.length()).trim() : "",
                        R.drawable.ic_notes, () -> editNote(idx), () -> {
                    store.remove("notes", idx);
                    refreshPanel();
                }));
            }
            renderRows(body, rows, "No notes yet. Tap + New.", R.drawable.ic_notes);
        });
    }

    private void editNote(final int idx) {
        final EditText e = new EditText(this);
        e.setHint("Write a note");
        e.setMinLines(4);
        e.setGravity(Gravity.TOP);
        if (idx >= 0) e.setText(store.list("notes").get(idx).title);
        LinearLayout l = new LinearLayout(this);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        l.addView(e, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this).setTitle("Note").setView(l)
                .setPositiveButton("Save", (d, w) -> {
                    String m = e.getText().toString().trim();
                    if (m.isEmpty()) return;
                    if (idx >= 0) store.replace("notes", idx, m, String.valueOf(System.currentTimeMillis()));
                    else store.add("notes", m, String.valueOf(System.currentTimeMillis()), 200, true);
                    refreshPanel();
                }).setNegativeButton("Cancel", null).show();
    }

    /* ---- More tools ---- */

    /* ---- UC style Tools sheet ---- */

    private View toolItem(final Dialog[] dd, int icon, String label, boolean on, boolean off, final Runnable action) {
        View v = menuItem(icon, label, 0, on, off, () -> {
            if (dd[0] != null) dd[0].dismiss();
            if (off) {
                toast("Open a website first");
                return;
            }
            action.run();
        });
        v.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        if (off) v.setAlpha(0.4f);
        return v;
    }

    private void openToolsSheet() {
        closeMenu();
        final Dialog[] dd = new Dialog[1];
        final boolean home = cur.home;
        LinearLayout c = ucCard(true);
        c.setPadding(dp(10), dp(18), dp(10), dp(8));
        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.addView(toolItem(dd, R.drawable.ic_cloud, "Speed Mode", store.dataSaver(), false, () -> {
            store.setDataSaver(!store.dataSaver());
            applyAllWebPrefs();
            if (!cur.home) cur.web.reload();
            toast(store.dataSaver() ? "Speed Mode on" : "Speed Mode off");
        }));
        r1.addView(toolItem(dd, R.drawable.ic_camera, "Screen Shot", false, false, this::takeShot));
        r1.addView(toolItem(dd, R.drawable.ic_notes, "Clipboard", false, false, this::showClipboard));
        r1.addView(toolItem(dd, R.drawable.ic_translate, "AI Translation", false, false, () -> {
            String u = cur.home ? "https://translate.google.com"
                    : "https://translate.google.com/translate?sl=auto&tl=hi&u=" + Uri.encode(cur.url);
            loadIn(cur, u);
        }));
        r1.addView(toolItem(dd, R.drawable.ic_desktop, "Desktop Site", store.desktop(), false, () -> toggleDesktop(!store.desktop())));
        c.addView(r1, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        r2.addView(toolItem(dd, R.drawable.ic_download, "Save Page", false, home, this::savePage));
        r2.addView(toolItem(dd, R.drawable.ic_full, "Full Screen Mode", false, false, () -> {
            fullscreen = true;
            applySystemUi();
        }));
        r2.addView(toolItem(dd, R.drawable.ic_search, "Find in Page", false, home, this::showFind));
        r2.addView(toolItem(dd, R.drawable.ic_wrench, "More", false, false, this::openMoreTools));
        View filler = new View(this);
        r2.addView(filler, new LinearLayout.LayoutParams(0, 1, 1));
        LinearLayout.LayoutParams r2p = new LinearLayout.LayoutParams(-1, -2);
        r2p.topMargin = dp(14);
        c.addView(r2, r2p);
        View line = new View(this);
        line.setBackgroundColor(pal.line);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.topMargin = dp(10);
        c.addView(line, lp);
        TextView cancel = Ui.text(this, tr("Cancel"), 19, pal.fg, true);
        cancel.setGravity(Gravity.CENTER);
        cancel.setPadding(0, dp(14), 0, dp(10));
        c.addView(cancel, new LinearLayout.LayoutParams(-1, -2));
        dd[0] = ucShow(c, true);
        cancel.setOnClickListener(v -> dd[0].dismiss());
    }

    private void takeShot() {
        ui.postDelayed(() -> {
            try {
                final View dv = getWindow().getDecorView();
                final Bitmap b = Bitmap.createBitmap(dv.getWidth(), dv.getHeight(), Bitmap.Config.ARGB_8888);
                if (Build.VERSION.SDK_INT >= 26) {
                    android.view.PixelCopy.request(getWindow(), b, r -> {
                        if (r == android.view.PixelCopy.SUCCESS) saveShot(b);
                        else toast("Could not take screenshot");
                    }, ui);
                } else {
                    dv.draw(new Canvas(b));
                    saveShot(b);
                }
            } catch (Exception e) {
                toast("Could not take screenshot");
            }
        }, 350);
    }

    private void saveShot(Bitmap b) {
        try {
            String name = "SR_" + System.currentTimeMillis() + ".jpg";
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SR Browser");
                Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                java.io.OutputStream os = getContentResolver().openOutputStream(u);
                b.compress(Bitmap.CompressFormat.JPEG, 92, os);
                os.close();
            } else {
                MediaStore.Images.Media.insertImage(getContentResolver(), b, name, null);
            }
            toast("Screenshot saved to gallery");
        } catch (Exception e) {
            toast("Could not save screenshot");
        }
    }

    private void showClipboard() {
        CharSequence tx = null;
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0)
                tx = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
        } catch (Exception ignored) {
        }
        final String text = tx == null ? "" : tx.toString().trim();
        LinearLayout c = ucCard(false);
        c.addView(ucTitle("Clipboard"));
        TextView t = Ui.text(this, text.isEmpty() ? tr("Clipboard is empty") : text, 16, text.isEmpty() ? pal.muted : pal.fg, false);
        t.setMaxLines(6);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setGravity(Gravity.CENTER);
        c.addView(t);
        final Dialog d = ucShow(c, false);
        if (!text.isEmpty()) {
            c.addView(ucBtn("Open / Search", true, v -> {
                d.dismiss();
                loadIn(cur, toUrl(text));
            }));
        }
        c.addView(ucBtn("Close", false, v -> d.dismiss()));
    }

    private void savePage() {
        try {
            File dir = new File(getExternalFilesDir(null), "pages");
            dir.mkdirs();
            File f = new File(dir, host(cur.url).replace('.', '_') + "_" + System.currentTimeMillis() + ".mht");
            cur.web.saveWebArchive(f.getAbsolutePath());
            toast("Page saved");
        } catch (Exception e) {
            toast("Could not save page");
        }
    }

    private void showFind() {
        final WebView w = cur.web;
        LinearLayout c = ucCard(true);
        final EditText q = ucInput("Find in page", InputType.TYPE_CLASS_TEXT);
        c.addView(q);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        final Dialog d = ucShow(c, true);
        View prev = ucBtn("Prev", false, v -> w.findNext(false));
        View next = ucBtn("Next", true, v -> w.findNext(true));
        View close = ucBtn("Close", false, v -> d.dismiss());
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, dp(50), 1);
        a.rightMargin = dp(8);
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(0, dp(50), 1);
        b.rightMargin = dp(8);
        row.addView(prev, a);
        row.addView(next, b);
        row.addView(close, new LinearLayout.LayoutParams(0, dp(50), 1));
        c.addView(row);
        q.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int st, int co, int af) {
            }

            @Override
            public void onTextChanged(CharSequence s, int st, int be, int co) {
                w.findAllAsync(s.toString());
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {
            }
        });
        d.setOnDismissListener(x -> w.clearMatches());
        if (d.getWindow() != null) {
            d.getWindow().setDimAmount(0f);
            d.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
                    | android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        q.requestFocus();
    }

    private void openMoreTools() {
        openPanel(tr("More Tools"), null, null, body -> {
            body.setPadding(0, 0, 0, dp(24));
            flatRow(body, "Desktop Site", "Show the desktop version of sites", null, sw(store.desktop(), this::toggleDesktop), null);
            flatRow(body, "Full Screen", null, null, null, () -> {
                closeAllPanels();
                fullscreen = true;
                applySystemUi();
            });
            flatRow(body, "Add-ons", null, null, chev(), this::openAddons);
            flatRow(body, "My Videos", null, null, chev(), this::openVideos);
            flatRow(body, "Text Size", null, SIZE_NAMES[store.textSize()], null, () -> {
                cycleSize();
                refreshPanel();
            });
            flatRow(body, "Clear Cache", null, null, null, () -> {
                for (Tab t : tabs) t.web.clearCache(true);
                toast("Cache cleared");
            });
        });
    }

    private void openVideos() {
        openPanel("My Videos", "+ This page", () -> {
            if (cur.home) {
                toast("Open a video page first");
                return;
            }
            String t = cur.title == null || cur.title.isEmpty() ? host(cur.url) : cur.title;
            store.add("vid", t, cur.url, 200, true);
            refreshPanel();
            toast("Video saved");
        }, body -> {
            List<Row> rows = new ArrayList<>();
            List<Store.Item> l = store.list("vid");
            for (int i = 0; i < l.size(); i++) {
                final Store.Item it = l.get(i);
                final int idx = i;
                rows.add(new Row(it.title, host(it.url), R.drawable.ic_video, () -> {
                    closeAllPanels();
                    loadIn(cur, it.url);
                }, () -> {
                    store.remove("vid", idx);
                    refreshPanel();
                }));
            }
            renderRows(body, rows, "Open a video page, then tap \"+ This page\" here.", R.drawable.ic_video);
        });
    }

    private void openAddons() {
        openPanel("Add-ons", null, null, body -> {
            String[][] a = {
                    {"Google Translate", "Translate any language", "https://translate.google.com", "ic_translate"},
                    {"Maps", "Find places and directions", "https://maps.google.com", "ic_map"},
                    {"News", "Latest news", "https://news.google.com", "ic_news"},
                    {"Weather", "Today's weather", "https://www.google.com/search?q=weather", "ic_sun"},
                    {"Cricket score", "Live score", "https://www.google.com/search?q=cricket+score", "ic_ball"}
            };
            List<Row> rows = new ArrayList<>();
            for (final String[] x : a) {
                int res = getResources().getIdentifier(x[3], "drawable", getPackageName());
                rows.add(new Row(x[0], x[1], res, () -> {
                    closeAllPanels();
                    loadIn(cur, x[2]);
                }, null));
            }
            renderRows(body, rows, "", 0);
        });
    }

    /* ---- Theme zone ---- */

    private boolean hasWallpaper() {
        return new File(getFilesDir(), "wall.jpg").exists();
    }

    private void openThemes() {
        openPanel(tr("Theme Zone"), null, null, body -> {
            int sw = getResources().getDisplayMetrics().widthPixels;
            int cw = (sw - dp(28) - dp(16)) / 3;
            int ch = (int) (cw * 1.45f);
            List<View> cards = new ArrayList<>();
            for (int i = 0; i < THEME_COLORS.length; i++) {
                final int idx = i;
                FrameLayout c = new FrameLayout(this);
                if (i == 0) {
                    GradientDrawable g = Ui.round(this, 0xFFFFFFFF, 8);
                    g.setStroke(dp(1), pal.line);
                    c.setBackground(g);
                    ImageView li = new ImageView(this);
                    li.setImageResource(R.drawable.logo);
                    li.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    li.setPadding(dp(10), dp(10), dp(10), dp(10));
                    c.addView(li, new FrameLayout.LayoutParams(-1, -1));
                } else {
                    GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, THEME_COLORS[i]);
                    g.setCornerRadius(dp(8));
                    c.setBackground(g);
                    TextView nm = Ui.text(this, THEME_NAMES[i], 12, 0xFFFFFFFF, true);
                    nm.setGravity(Gravity.CENTER);
                    c.addView(nm, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
                    nm.setPadding(0, 0, 0, dp(10));
                }
                if (store.theme() == i) addCheck(c);
                c.setOnClickListener(v -> {
                    store.setTheme(idx);
                    refreshHome();
                    refreshPanel();
                });
                cards.add(c);
            }
            if (hasWallpaper()) {
                FrameLayout c = new FrameLayout(this);
                File f = new File(getFilesDir(), "wall.jpg");
                Bitmap b = BitmapFactory.decodeFile(f.getPath());
                ImageView iv = new ImageView(this);
                if (b != null) iv.setImageBitmap(b);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setBackground(Ui.round(this, pal.surface2, 8));
                iv.setClipToOutline(true);
                c.addView(iv, new FrameLayout.LayoutParams(-1, -1));
                if (store.theme() == 5) addCheck(c);
                c.setOnClickListener(v -> {
                    store.setTheme(5);
                    refreshHome();
                    refreshPanel();
                });
                cards.add(c);
            }
            FrameLayout add = new FrameLayout(this);
            add.setBackground(Ui.round(this, pal.surface2, 8));
            add.addView(Ui.icon(this, R.drawable.ic_plus, 34, pal.muted), new FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER));
            add.setOnClickListener(v -> {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("image/*");
                try {
                    startActivityForResult(i, REQ_PHOTO);
                } catch (Exception e) {
                    toast("No gallery app found");
                }
            });
            cards.add(add);

            for (int i = 0; i < cards.size(); i += 3) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                for (int j = 0; j < 3; j++) {
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(cw, ch);
                    lp.rightMargin = dp(8);
                    lp.bottomMargin = dp(8);
                    if (i + j < cards.size()) row.addView(cards.get(i + j), lp);
                    else row.addView(new View(this), lp);
                }
                body.addView(row, new LinearLayout.LayoutParams(-1, -2));
            }
            TextView lp = Ui.text(this, tr("Local Photos"), 16, pal.fg, false);
            lp.setPadding(dp(4), dp(18), 0, 0);
            body.addView(lp);
        });
    }

    private void addCheck(FrameLayout c) {
        FrameLayout badge = new FrameLayout(this);
        badge.setBackground(oval(pal.accent));
        badge.addView(Ui.icon(this, R.drawable.ic_check, 16, 0xFFFFFFFF), new FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.BOTTOM | Gravity.END);
        bp.rightMargin = dp(6);
        bp.bottomMargin = dp(6);
        c.addView(badge, bp);
    }

    private void saveWallpaper(Uri uri) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, o);
            }
            int sw = getResources().getDisplayMetrics().widthPixels;
            int sh = getResources().getDisplayMetrics().heightPixels;
            int sample = 1;
            while (o.outWidth / (sample * 2) >= sw && o.outHeight / (sample * 2) >= sh) sample *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            Bitmap b;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                b = BitmapFactory.decodeStream(in, null, o);
            }
            if (b == null) {
                toast("Could not open the photo");
                return;
            }
            // Crop to the screen shape so it fills the home screen without stretching
            float target = sw / (float) sh;
            int cw = b.getWidth(), chh = b.getHeight();
            int nw = cw, nh = chh;
            if (cw / (float) chh > target) nw = Math.round(chh * target);
            else nh = Math.round(cw / target);
            Bitmap out = Bitmap.createBitmap(b, (cw - nw) / 2, (chh - nh) / 2, nw, nh);
            try (FileOutputStream fo = new FileOutputStream(new File(getFilesDir(), "wall.jpg"))) {
                out.compress(Bitmap.CompressFormat.JPEG, 88, fo);
            }
            store.setTheme(5);
            refreshHome();
            refreshPanel();
            toast("Wallpaper applied");
        } catch (Exception e) {
            toast("Could not set the photo");
        }
    }

    /* ------------------------------------------------------------------ */
    /* Settings (UC style list)                                           */
    /* ------------------------------------------------------------------ */

    private View chev() {
        return Ui.icon(this, R.drawable.ic_chev_right, 22, pal.muted);
    }

    private Switch sw(boolean on, final BoolCb cb) {
        Switch s = new Switch(this);
        s.setChecked(on);
        s.setOnCheckedChangeListener((b, v) -> cb.on(v));
        return s;
    }

    private void flatRow(LinearLayout body, String title, String sub, String right, View trailing, final Runnable click) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(22), dp(18), dp(20), dp(18));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(Ui.text(this, tr(title), 17, pal.fg, false));
        if (sub != null) {
            TextView s = Ui.text(this, sub, 12.5f, pal.muted, false);
            s.setPadding(0, dp(3), 0, 0);
            col.addView(s);
        }
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        if (right != null) {
            TextView r = Ui.text(this, right, 14.5f, pal.muted, false);
            r.setPadding(dp(8), 0, dp(6), 0);
            row.addView(r);
        }
        if (trailing != null) row.addView(trailing);
        if (click != null) row.setOnClickListener(v -> click.run());
        body.addView(row, new LinearLayout.LayoutParams(-1, -2));
        View d = new View(this);
        d.setBackgroundColor(pal.line);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, dp(1));
        dl.leftMargin = dp(22);
        dl.rightMargin = dp(22);
        body.addView(d, dl);
    }

    private boolean isDefaultBrowser() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
                return rm != null && rm.isRoleHeld(RoleManager.ROLE_BROWSER);
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private void openDefaultSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));
        } catch (Exception e) {
            toast("Go to phone Settings > Apps > Default apps");
        }
    }

    private void openSettings() {
        openPanel(tr("Settings"), null, null, this::renderSettings);
    }

    private void setHead(LinearLayout b, String title) {
        TextView t = Ui.text(this, tr(title), 13, pal.muted, true);
        t.setPadding(dp(22), dp(20), dp(22), dp(6));
        t.setAllCaps(!"hi".equals(store.lang()));
        b.addView(t);
    }

    private void renderSettings(LinearLayout b) {
        b.setPadding(0, 0, 0, dp(24));
        setHead(b, "General");
        final boolean def = isDefaultBrowser();
        flatRow(b, "Set as Default Browser", def ? tr("S.R Browser is your default browser") : tr("Open all links with S.R Browser"),
                null, sw(def, v -> openDefaultSettings()), null);
        flatRow(b, "Language", null, "hi".equals(store.lang()) ? "हिन्दी" : "English", chev(), () ->
                new AlertDialog.Builder(this).setTitle(tr("Language"))
                        .setSingleChoiceItems(new String[]{"English", "हिन्दी"}, "hi".equals(store.lang()) ? 1 : 0, (d, which) -> {
                            store.setLang(which == 1 ? "hi" : "en");
                            d.dismiss();
                            recreate();
                        }).show());
        flatRow(b, "Search Settings", null, engineName(), chev(), this::openSearchSettings);
        flatRow(b, "Notification Settings", null, null, chev(), () -> {
            try {
                Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                startActivity(i);
            } catch (Exception e) {
                toast(tr("Could not open notification settings"));
            }
        });

        setHead(b, "Browsing");
        flatRow(b, "Browsing Settings", tr("Text size, night mode, full screen, desktop site"), null, chev(), this::openBrowsingSettings);
        flatRow(b, "AD Setting", null, store.adblock() ? tr("ON") : tr("OFF"), chev(), this::openAdSettings);
        flatRow(b, "Data Saver", tr("Hide images to save data and load faster"), null, sw(store.dataSaver(), v -> {
            store.setDataSaver(v);
            applyAllWebPrefs();
            toast(tr(v ? "Data Saver on" : "Data Saver off"));
        }), null);
        flatRow(b, "Themes", null, null, chev(), this::openThemes);
        flatRow(b, "Customized Banner", null, null, chev(), this::openBannerSettings);

        setHead(b, "Downloads");
        flatRow(b, "Download Settings", tr("Location, Wi-Fi only, notifications"), null, chev(), this::openDownloadSettings);
        flatRow(b, "Social Media Downloader Settings", null, null, chev(), this::openSocialSettings);
        flatRow(b, "Downloads", null, null, chev(), this::openDownloader);

        setHead(b, "Privacy");
        flatRow(b, "Clear Records", tr("History, cache, cookies, forms"), null, chev(), this::clearRecords);
        flatRow(b, "Account", null, null, chev(), this::showSignIn);

        setHead(b, "About");
        flatRow(b, "Check for Updates", null, APP_VER, chev(), () -> toast(tr("You're using the latest version")));
        flatRow(b, "About SR", null, null, chev(), this::openAbout);

        TextView rs = Ui.text(this, tr("Reset to Default"), 17, pal.accent, true);
        rs.setGravity(Gravity.CENTER);
        rs.setPadding(0, dp(26), 0, dp(26));
        rs.setOnClickListener(v -> confirmReset());
        b.addView(rs, new LinearLayout.LayoutParams(-1, -2));
    }

    private void openAdSettings() {
        openPanel(tr("AD Setting"), null, null, b -> {
            setHead(b, "Ad Block");
            flatRow(b, "Block ads", tr("Blocks known ads and trackers"), null, sw(store.adblock(), store::setAdblock), null);
            flatRow(b, "Block pop-ups", tr("Blocks pop-up windows and redirects"), null, sw(store.popupBlock(), store::setPopupBlock), null);
            TextView n = Ui.text(this, tr("Changes apply to new pages. Refresh an open page to see the result."), 13, pal.muted, false);
            n.setPadding(dp(22), dp(16), dp(22), 0);
            b.addView(n);
        });
    }

    private void openBannerSettings() {
        openPanel(tr("Customized Banner"), null, null, b -> {
            flatRow(b, "Quick buttons on home", "Downloader, Notes, History, Bookmark", null,
                    sw(store.showQuick(), v -> {
                        store.setShowQuick(v);
                        refreshHome();
                    }), null);
            flatRow(b, "Show 'Made in India' line", null, null, sw(store.showIndia(), v -> {
                store.setShowIndia(v);
                refreshHome();
            }), null);
            flatRow(b, "Home message", store.homeNote().isEmpty() ? "Add your own text under the logo" : store.homeNote(), null, chev(), () -> {
                final EditText e = new EditText(this);
                e.setText(store.homeNote());
                e.setSingleLine(true);
                LinearLayout l = new LinearLayout(this);
                l.setPadding(dp(20), dp(8), dp(20), 0);
                l.addView(e, new LinearLayout.LayoutParams(-1, -2));
                new AlertDialog.Builder(this).setTitle("Home message").setView(l)
                        .setPositiveButton("Save", (d, w) -> {
                            store.setHomeNote(e.getText().toString().trim());
                            refreshHome();
                            refreshPanel();
                        }).setNegativeButton("Cancel", null).show();
            });
        });
    }

    private void openBrowsingSettings() {
        openPanel(tr("Browsing Settings"), null, null, b -> {
            setHead(b, "Display");
            flatRow(b, "Text Size", null, tr(SIZE_NAMES[store.textSize()]), chev(), () ->
                    new AlertDialog.Builder(this).setTitle(tr("Text Size"))
                            .setSingleChoiceItems(SIZE_NAMES, store.textSize(), (d, which) -> {
                                store.setTextSize(which);
                                applyAllWebPrefs();
                                d.dismiss();
                                refreshPanel();
                            }).show());
            flatRow(b, "Night Mode", tr("Dark colours, easy on the eyes"), null, sw(store.night(), v -> {
                store.setNight(v);
                recreate();
            }), null);
            flatRow(b, "Full Screen", tr("Hide the status bar while browsing"), null, sw(fullscreen, v -> {
                fullscreen = v;
                applySystemUi();
            }), null);
            flatRow(b, "Desktop Site", tr("Show the desktop version of sites"), null, sw(store.desktop(), this::toggleDesktop), null);

            setHead(b, "Pages");
            flatRow(b, "JavaScript", tr("Some sites may not work if turned off"), null, sw(store.js(), v -> {
                store.setJs(v);
                applyAllWebPrefs();
            }), null);
            flatRow(b, "Incognito mode", tr("History is not saved"), null, sw(store.incognito(), v -> {
                store.setIncognito(v);
                updateTabBtn();
            }), null);
            flatRow(b, "Ask before exit", null, null, sw(!store.noAskExit(), v -> store.setNoAskExit(!v)), null);
        });
    }

    private void openDownloadSettings() {
        openPanel(tr("Download Settings"), null, null, b -> {
            setHead(b, "Location");
            flatRow(b, "Download location", tr("Internal storage / Download"), null, null, null);
            setHead(b, "Downloading");
            flatRow(b, "Ask before downloading", tr("Show file name and size before download starts"), null,
                    sw(store.askDownload(), store::setAskDownload), null);
            flatRow(b, "Download on Wi-Fi only", tr("Save mobile data; downloads wait for Wi-Fi"), null,
                    sw(store.wifiOnly(), store::setWifiOnly), null);
            flatRow(b, "Download complete notification", null, null, sw(store.dlNotify(), store::setDlNotify), null);
            flatRow(b, "Detect videos on pages", tr("Show a Download video button on pages with a video file"), null,
                    sw(store.detectVideo(), store::setDetectVideo), null);
            setHead(b, "Files");
            flatRow(b, "Open Downloads", null, null, chev(), this::openDownloader);
        });
    }

    private void openSearchSettings() {
        openPanel(tr("Search Settings"), null, null, b -> {
            flatRow(b, "Search engine", null, engineName(), chev(), this::pickEngine);
            flatRow(b, "Default search type", null, new String[]{"Web", "Videos", "Images"}[mode], chev(), () ->
                    new AlertDialog.Builder(this).setTitle("Search type")
                            .setSingleChoiceItems(new String[]{"Web", "Videos", "Images"}, mode, (d, which) -> {
                                mode = which;
                                store.setSearchMode(which);
                                d.dismiss();
                                refreshHome();
                                refreshPanel();
                            }).show());
        });
    }

    private void openSocialSettings() {
        openPanel(tr("Social Media Downloader Settings"), null, null, b -> {
            flatRow(b, "Detect videos on pages", "A Download video button appears when a direct video file is found",
                    null, sw(store.detectVideo(), store::setDetectVideo), null);
            TextView n = Ui.text(this, "Note: YouTube, Instagram and Facebook protect their videos, so the button does not appear there. It works wherever the page has a direct video file (mp4).", 13, pal.muted, false);
            n.setPadding(dp(22), dp(16), dp(22), 0);
            b.addView(n);
        });
    }

    private void clearRecords() {
        LinearLayout c = ucCard(false);
        FrameLayout head = new FrameLayout(this);
        TextView t = ucTitle("Clear Records");
        head.addView(t, new FrameLayout.LayoutParams(-1, -2));
        final CheckBox cCookies = ucCheck("Cookies", false);
        final CheckBox cForms = ucCheck("Forms", false);
        final CheckBox cHist = ucCheck("History", true);
        final CheckBox cCache = ucCheck("Cache", true);
        c.addView(head);
        c.addView(cCookies);
        c.addView(cForms);
        c.addView(cHist);
        c.addView(cCache);
        final Dialog d = ucShow(c, false);
        ImageView x = Ui.icon(this, R.drawable.ic_close, 22, pal.muted);
        x.setPadding(dp(2), dp(2), dp(2), dp(2));
        x.setOnClickListener(v -> d.dismiss());
        FrameLayout.LayoutParams xp = new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.TOP | Gravity.END);
        head.addView(x, xp);
        c.addView(ucBtn("Clear", true, v -> {
            if (cCookies.isChecked()) CookieManager.getInstance().removeAllCookies(null);
            if (cForms.isChecked()) WebViewDatabase.getInstance(this).clearFormData();
            if (cHist.isChecked()) {
                store.clear("hist");
                store.clear("vhist");
            }
            if (cCache.isChecked()) for (Tab tb : tabs) tb.web.clearCache(true);
            d.dismiss();
            toast("Cleared");
            refreshPanel();
        }));
        c.addView(ucBtn("Cancel", false, v -> d.dismiss()));
    }

    private void showSignIn() {
        LinearLayout c = ucCard(true);
        c.addView(ucTitle("Sign in"));
        View fb = ucBtn("Sign in with Facebook", true, v -> toast("Facebook sign-in is coming soon"));
        View gg = ucBtn("Sign in with Google", true, v -> toast("Google sign-in is coming soon"));
        View sr = ucBtn("Sign in with SR Account", false, v -> toast("SR Account is coming soon"));
        c.addView(fb);
        c.addView(gg);
        c.addView(sr);
        TextView note = Ui.text(this, "By signing in, you agree with our Privacy Policy and Terms of Use", 12.5f, pal.muted, false);
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, dp(18), 0, dp(6));
        c.addView(note);
        ucShow(c, true);
    }

    private void openAbout() {
        openPanel(tr("About SR"), null, null, b -> {
            LinearLayout head = new LinearLayout(this);
            head.setOrientation(LinearLayout.VERTICAL);
            head.setGravity(Gravity.CENTER_HORIZONTAL);
            head.setPadding(dp(24), dp(28), dp(24), dp(8));
            ImageView lg = new ImageView(this);
            lg.setImageResource(R.drawable.intro_logo);
            lg.setScaleType(ImageView.ScaleType.FIT_CENTER);
            head.addView(lg, new LinearLayout.LayoutParams(dp(130), dp(130)));
            TextView nm = Ui.text(this, "S.R Browser", 24, pal.fg, true);
            nm.setPadding(0, dp(10), 0, 0);
            head.addView(nm);
            TextView ver = Ui.text(this, "Version " + APP_VER.substring(1), 14, pal.muted, false);
            ver.setPadding(0, dp(2), 0, dp(10));
            head.addView(ver);
            TextView tg = Ui.text(this, "Fast. Simple. Made in India.", 15, pal.accent, true);
            tg.setGravity(Gravity.CENTER);
            head.addView(tg);
            TextView ds = Ui.text(this, "A fast, light and private browser for everyday use. Search, watch, download and shop without ads getting in your way.", 15, pal.muted, false);
            ds.setGravity(Gravity.CENTER);
            ds.setPadding(0, dp(14), 0, 0);
            head.addView(ds);
            b.addView(head);

            b.addView(sectionTitle("What you get"));
            String[] feats = {
                    "Ad and pop-up blocker",
                    "Video detector and downloader",
                    "Multiple tabs and incognito mode",
                    "Night mode, themes and wallpapers",
                    "Bookmarks, history and notes",
                    "Speed Mode, screenshot and find in page",
                    "Desktop site and full screen mode"
            };
            LinearLayout fc = new LinearLayout(this);
            fc.setOrientation(LinearLayout.VERTICAL);
            fc.setPadding(dp(16), dp(10), dp(16), dp(10));
            fc.setBackground(Ui.round(this, pal.surface2, 16));
            for (String f : feats) {
                TextView t = Ui.text(this, "\u2713  " + f, 15, pal.fg, false);
                t.setPadding(0, dp(5), 0, dp(5));
                fc.addView(t);
            }
            LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
            fp.setMargins(dp(20), 0, dp(20), dp(10));
            b.addView(fc, fp);

            flatRow(b, "Feedback", null, null, chev(), this::feedback);
            flatRow(b, "Check Update", null, APP_VER, null, () -> toast("You're using the latest version"));
            flatRow(b, "Join UX Improvement Program", null, null, sw(store.ux(), store::setUx), null);

            TextView ft = Ui.text(this, "Made with \u2665 in India\n\u00a9 2026 S.R Browser", 13, pal.muted, false);
            ft.setGravity(Gravity.CENTER);
            ft.setPadding(0, dp(24), 0, dp(32));
            b.addView(ft, new LinearLayout.LayoutParams(-1, -2));
        });
    }

    private void confirmReset() {
        LinearLayout c = ucCard(false);
        c.addView(ucTitle("Reset to Default"));
        TextView n = Ui.text(this, "All settings will go back to default. Bookmarks, history and notes are kept.", 15, pal.muted, false);
        n.setGravity(Gravity.CENTER);
        c.addView(n);
        final Dialog d = ucShow(c, false);
        c.addView(ucBtn("Reset", true, v -> {
            d.dismiss();
            store.resetSettings();
            recreate();
        }));
        c.addView(ucBtn("Cancel", false, v -> d.dismiss()));
    }
}
