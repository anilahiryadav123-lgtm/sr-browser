package com.sr.browser;

import java.util.HashMap;
import java.util.Map;

/** English to Hindi labels for the main screens. Anything not listed stays in English. */
final class Strings {
    private static final Map<String, String> HI = new HashMap<>();

    static {
        HI.put("Bookmarks", "बुकमार्क");
        HI.put("Bookmark", "बुकमार्क");
        HI.put("History", "इतिहास");
        HI.put("Downloads", "डाउनलोड");
        HI.put("Downloader", "डाउनलोडर");
        HI.put("Themes", "थीम");
        HI.put("More Tools", "और टूल्स");
        HI.put("Add to Bookmarks", "बुकमार्क जोड़ें");
        HI.put("Night", "रात मोड");
        HI.put("Refresh", "रिफ्रेश");
        HI.put("Feedback", "फीडबैक");
        HI.put("Share", "शेयर");
        HI.put("Settings", "सेटिंग्स");
        HI.put("Notes", "नोट्स");
        HI.put("Search or Enter URL", "खोजें या URL डालें");
        HI.put("Enter URL", "URL डालें");
        HI.put("Search", "खोजें");
        HI.put("Made in India", "भारत में निर्मित");
        HI.put("Agree and Enter", "सहमत हैं, आगे बढ़ें");
        HI.put("SR Center", "SR सेंटर");
        HI.put("AD Setting", "विज्ञापन सेटिंग");
        HI.put("Customized Banner", "कस्टम बैनर");
        HI.put("Set as Default Browser", "डिफ़ॉल्ट ब्राउज़र बनाएं");
        HI.put("Browsing Settings", "ब्राउज़िंग सेटिंग्स");
        HI.put("Download Settings", "डाउनलोड सेटिंग्स");
        HI.put("Notification Settings", "नोटिफिकेशन सेटिंग्स");
        HI.put("Search Settings", "सर्च सेटिंग्स");
        HI.put("Social Media Downloader Settings", "सोशल मीडिया डाउनलोडर");
        HI.put("Data Saver", "डेटा सेवर");
        HI.put("Language", "भाषा");
        HI.put("Clear Records", "रिकॉर्ड साफ़ करें");
        HI.put("Video", "वीडियो");
        HI.put("Website", "वेबसाइट");
        HI.put("Edit", "एडिट");
        HI.put("Exit", "बाहर निकलें");
        HI.put("Tabs", "टैब");
        HI.put("Theme Zone", "थीम ज़ोन");
        HI.put("Local Photos", "फ़ोन की फ़ोटो");
        HI.put("Web", "वेब");
        HI.put("Videos", "वीडियो");
        HI.put("Images", "फ़ोटो");
        HI.put("Incognito mode on", "इन्कॉग्निटो मोड चालू");
        HI.put("Fast. Simple. Made in India.", "तेज़। आसान। भारत में बना।");
        HI.put("Downloading", "डाउनलोड हो रहे");
        HI.put("Downloaded", "डाउनलोड हो चुके");
        HI.put("All", "सभी");
        HI.put("Music", "म्यूज़िक");
        HI.put("Image", "फ़ोटो");
        HI.put("Document", "डॉक्यूमेंट");
        HI.put("Others", "अन्य");
        HI.put("Completed", "पूरा हुआ");
        HI.put("Waiting...", "इंतज़ार...");
        HI.put("File removed", "फ़ाइल हटा दी गई");
        HI.put("Phone storage", "फ़ोन स्टोरेज");
        HI.put("free of", "खाली, कुल");
        HI.put("Saved in: Internal storage / Download", "सेव होगा: इंटरनल स्टोरेज / Download");
        HI.put("Download started", "डाउनलोड शुरू");
        HI.put("Download complete", "डाउनलोड पूरा");
        HI.put("Download failed", "डाउनलोड फ़ेल");
        HI.put("OPEN", "खोलें");
        HI.put("VIEW", "देखें");
        HI.put("Open", "खोलें");
        HI.put("Copy download link", "डाउनलोड लिंक कॉपी करें");
        HI.put("Download again", "फिर से डाउनलोड करें");
        HI.put("Remove from list", "लिस्ट से हटाएं");
        HI.put("Delete file", "फ़ाइल डिलीट करें");
        HI.put("Cancel download", "डाउनलोड रद्द करें");
        HI.put("Download cancelled", "डाउनलोड रद्द");
        HI.put("File deleted", "फ़ाइल डिलीट हुई");
        HI.put("Clear download list", "डाउनलोड लिस्ट साफ़ करें");
        HI.put("Clear", "साफ़ करें");
        HI.put("Cancel", "रद्द करें");
        HI.put("Download", "डाउनलोड");
        HI.put("Download from link", "लिंक से डाउनलोड");
        HI.put("Link", "लिंक");
        HI.put("Size", "साइज़");
        HI.put("Save to", "सेव करें");
        HI.put("Download on Wi-Fi only", "सिर्फ़ Wi-Fi पर डाउनलोड");
        HI.put("Link copied", "लिंक कॉपी हुआ");
        HI.put("Copy link", "लिंक कॉपी करें");
        HI.put("Open in new tab", "नए टैब में खोलें");
        HI.put("Open image in new tab", "फ़ोटो नए टैब में खोलें");
        HI.put("Download image", "फ़ोटो डाउनलोड करें");
        HI.put("Download link", "लिंक डाउनलोड करें");
        HI.put("General", "सामान्य");
        HI.put("Browsing", "ब्राउज़िंग");
        HI.put("Privacy", "प्राइवेसी");
        HI.put("About", "जानकारी");
        HI.put("Display", "डिस्प्ले");
        HI.put("Pages", "पेज");
        HI.put("Location", "लोकेशन");
        HI.put("Files", "फ़ाइलें");
        HI.put("Ad Block", "एड ब्लॉक");
        HI.put("Text Size", "टेक्स्ट साइज़");
        HI.put("Night Mode", "नाइट मोड");
        HI.put("Full Screen", "फ़ुल स्क्रीन");
        HI.put("Desktop Site", "डेस्कटॉप साइट");
        HI.put("Incognito mode", "इन्कॉग्निटो मोड");
        HI.put("Ask before exit", "बाहर निकलने से पहले पूछें");
        HI.put("Download location", "डाउनलोड लोकेशन");
        HI.put("Ask before downloading", "डाउनलोड से पहले पूछें");
        HI.put("Download complete notification", "डाउनलोड पूरा होने की सूचना");
        HI.put("Detect videos on pages", "पेज पर वीडियो पहचानें");
        HI.put("Open Downloads", "डाउनलोड खोलें");
        HI.put("Check for Updates", "अपडेट चेक करें");
        HI.put("About SR", "SR के बारे में");
        HI.put("Reset to Default", "डिफ़ॉल्ट पर रीसेट");
        HI.put("Account", "अकाउंट");
        HI.put("Block ads", "विज्ञापन ब्लॉक करें");
        HI.put("Block pop-ups", "पॉप-अप ब्लॉक करें");
        HI.put("ON", "चालू");
        HI.put("OFF", "बंद");
        HI.put("Small", "छोटा");
        HI.put("Medium", "मध्यम");
        HI.put("Large", "बड़ा");
        HI.put("Open with", "इससे खोलें");
        HI.put("Data Saver on", "डेटा सेवर चालू");
        HI.put("Data Saver off", "डेटा सेवर बंद");
    }

    private Strings() {
    }

    static String tr(String lang, String s) {
        if ("hi".equals(lang)) {
            String v = HI.get(s);
            if (v != null) return v;
        }
        return s;
    }
}
