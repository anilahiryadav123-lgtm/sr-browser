# S.R Browser 1.5 (Android) - Made in India
WebView browser with UC style screens: welcome, home, 5-icon menu, tab switcher, history (Video/Website),
downloader, notes, settings list, theme zone, ad block, Hindi/English.
Official logos (optional): app/src/main/assets/engines/google.png and app/src/main/assets/icons/yt.png etc.

New in 1.5: UC style first-run intro (language, animated feature slides, Skip, Agree & Continue),
UC style downloads (Downloading/Downloaded tabs, categories, live progress + speed, storage bar,
rename before download, Wi-Fi only), grouped UC style settings, and download-complete pop-up.
