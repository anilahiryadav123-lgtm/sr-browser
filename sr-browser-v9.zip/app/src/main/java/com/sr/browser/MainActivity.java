package com.sr.browser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.app.DownloadManager;
import android.app.Dialog;
import android.app.role.RoleManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.InsetDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.content.ContentValues;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.Gravity;
import android.view.View;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.JsResult;
import android.webkit.WebViewClient;
import android.webkit.WebViewDatabase;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/** S.R Browser: a UC style browser built on Android WebView. Made in India. */
public class MainActivity extends Activity {

    interface Renderer {
        void render(LinearLayout body);
    }

    interface BoolCb {
        void on(boolean v);
    }

    static final class Row {
        final String title, sub;
        final int icon;
        final Runnable click, delete;

        Row(String title, String sub, int icon, Runnable click, Runnable delete) {
            this.title = title;
            this.sub = sub;
            this.icon = icon;
            this.click = click;
            this.delete = delete;
        }
    }

    static final class Tab {
        WebView web;
        String title = "";
        String url = "";
        boolean home = true;
        Bitmap thumb;
        final java.util.Set<String> media = java.util.Collections.synchronizedSet(new java.util.LinkedHashSet<String>());
    }

    static final class PanelState {
        LinearLayout view;
        LinearLayout body;
        Renderer renderer;
        String id = "";
    }

    private static final String IPHONE_UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1";
    private static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    private static final int REQ_FILE = 11;
    private static final int REQ_PHOTO = 12;
    private static final int PURPLE = 0xFF7C5CF0;

    private static final String[][] SITES = {
            {"gg", "Google", "https://www.google.com"},
            {"yt", "YouTube", "https://m.youtube.com"},
            {"fb", "Facebook", "https://m.facebook.com"},
            {"ig", "Instagram", "https://www.instagram.com"},
            {"wa", "WhatsApp", "https://web.whatsapp.com"},
            {"tg", "Telegram", "https://web.telegram.org"},
            {"wk", "Wikipedia", "https://www.wikipedia.org"},
            {"am", "Amazon", "https://www.amazon.in"},
            {"fk", "Flipkart", "https://www.flipkart.com"}
    };
    private static final int[] SITE_BG = {
            0xFFFFFFFF, 0xFFE62117, 0xFF1877F2, 0xFFC32AA3, 0xFF25B45A,
            0xFF2A9BD8, 0xFFF3F3F1, 0xFF232F3E, 0xFF2874F0
    };
    private static final String[][] ENGINES = {
            {"google", "Google", "G"}, {"bing", "Bing", "B"}, {"ddg", "DuckDuckGo", "D"}, {"yahoo", "Yahoo", "Y"}
    };
    private static final int[] ENGINE_COLOR = {0xFF4285F4, 0xFF008373, 0xFFDE5833, 0xFF6001D2};
    private static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google",
            "adnxs.com", "taboola.com", "outbrain.com", "popads.net", "propellerads.com",
            "exoclick.com", "mgid.com", "adsterra.com", "pubmatic.com", "rubiconproject.com",
            "criteo.com", "moatads.com", "amazon-adsystem.com", "adcolony.com", "unityads.unity3d.com",
            "popcash.net", "adcash.com", "clickadu.com", "hilltopads.net", "juicyads.com",
            "trafficjunky.net", "onclickads.net", "a-ads.com", "adsco.re", "tsyndicate.com",
            "yllix.com", "revcontent.com", "adspyglass.com", "monetag.com", "richads.com",
            "galaksion.com", "bidvertiser.com", "infolinks.com", "ero-advertising.com",
            "ad-maven.com", "admaven.com", "adskeeper.com", "evadav.com", "pushwhy.com",
            "notix.io", "pushails.com", "profitablecpmrate.com", "highperformanceformat.com",
            "highcpmgate.com", "effectivegatecpm.com", "displayvertising.com", "ad.gt",
            "adform.net", "smartadserver.com", "openx.net", "casalemedia.com", "33across.com",
            "adsrvr.org", "ads.yahoo.com", "advertising.com", "zedo.com", "popmyads.com",
            "trafficfactory.biz", "clickaine.com", "mobtrks.com", "go.oclasrv.com", "oclaserver.com",
            "ylx-1.com", "ylx-2.com", "dolohen.com", "acscdn.com", "realsrv.com", "tapioni.com",
            "adtng.com", "adxpansion.com", "bebi.com", "cdn4ads.com", "directrev.com",
            "linkvertise.com", "shorte.st", "adf.ly", "ouo.io"
    };
    private static final String[] AD_URL_PARTS = {
            "/popunder", "/pop.js", "adserver.", "/adserve", "/banners/", "pagead/", "/ads/show",
            "clickunder", "/popad", "afu.php", "/aclk?"
    };
    private static final String ADBLOCK_JS = "(function(){try{"
            + "if(!window.__srab){window.__srab=1;"
            + "var st=document.createElement('style');"
            + "st.textContent='ins.adsbygoogle,.adsbygoogle,iframe[src*=\"doubleclick.net\"],iframe[src*=\"googlesyndication\"],"
            + "iframe[id^=\"google_ads_iframe\"],div[id^=\"google_ads_\"],div[id^=\"div-gpt-ad\"],[id^=\"taboola-\"],.taboola,"
            + ".OUTBRAIN,[data-ad-slot],[data-ad-client],iframe[src*=\"adsterra\"],iframe[src*=\"popads\"],"
            + "[class~=\"ad-container\"],[class~=\"ad-banner\"],[class~=\"advertisement\"],[id~=\"advertisement\"],"
            + ".popup-ad,.ad-slot,.ad-unit,.sticky-ad,.adthrive-ad,.mgid,[id^=\"mgid_\"]{display:none!important;visibility:hidden!important;height:0!important}';"
            + "(document.head||document.documentElement).appendChild(st);"
            + "var o=window.open;window.open=function(){if(navigator.userActivation&&!navigator.userActivation.isActive)return null;return o.apply(this,arguments)};}"
            + "}catch(e){}})();";
    private long lastTouch = 0;
    private int alertCount = 0;
    private static final String[] THEME_NAMES = {"SR", "Night Sky", "Ocean", "Aurora", "Sunset"};
    private static final int[][] THEME_COLORS = {
            {0xFFFFFFFF, 0xFFFFFFFF},
            {0xFF1B1730, 0xFF3A2A4A},
            {0xFF0B1E4A, 0xFF27A3D8},
            {0xFF0A2A6B, 0xFF18C2D0},
            {0xFFFF8A4C, 0xFFE5121B}
    };

    private final Handler ui = new Handler(Looper.getMainLooper());

    private Store store;
    private Pal pal;
    private String mobileUa;

    private FrameLayout screen;
    private LinearLayout root, topBar, bottomBar;
    private EditText urlEdit, homeEdit;
    private ImageView btnRefresh, tabsIcon, secIcon;
    private View typingBar, btnMenuV;
    private ProgressBar progress;
    private FrameLayout webHolder;
    private ScrollView homeView;
    private LinearLayout homeBox;
    private TextView tabCount;
    private View videoFab;
    private volatile int adBlocked = 0;
    private final java.util.concurrent.ExecutorService bg = java.util.concurrent.Executors.newFixedThreadPool(3);
    private View btnBack, btnFwd;

    private View scrim;
    private LinearLayout sheetBox;
    private View tabsView;
    private View welcome;
    private View splash;
    private static final String APP_VER = "V1.9.0";

    private final List<PanelState> panels = new ArrayList<>();
    private final List<Tab> tabs = new ArrayList<>();
    private final List<String> closedUrls = new ArrayList<>();
    private Tab cur;
    private int mode = 0;
    private int histTab = 0;
    private boolean fullscreen = false;
    private boolean loading = false;

    private View customView;
    private FrameLayout customHolder;
    private WebChromeClient.CustomViewCallback customCb;
    private ValueCallback<Uri[]> fileCb;

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private String tr(String s) {
        return Strings.tr(store.lang(), s);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private GradientDrawable oval(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    /* ------------------------------------------------------------------ */
    /* Lifecycle                                                          */
    /* ------------------------------------------------------------------ */

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        store = new Store(this);
        mode = store.searchMode();
        fullscreen = store.flag("full", false);
        pal = new Pal(store.night());
        mobileUa = WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace("Version/4.0 ", "");
        CookieManager.getInstance().setAcceptCookie(true);
        getWindow().setStatusBarColor(pal.bg);
        getWindow().setNavigationBarColor(pal.bar);

        buildUi();
        buildSheet();
        setContentView(screen);
        applySystemUi();

        ArrayList<String> saveTabs = saved == null ? null : saved.getStringArrayList("tabs");
        if (saveTabs != null && !saveTabs.isEmpty()) {
            for (String s : saveTabs) {
                Tab t = newTab();
                if (!s.isEmpty()) loadIn(t, s);
            }
            int ci = saved.getInt("cur", 0);
            if (ci >= 0 && ci < tabs.size()) switchTo(tabs.get(ci));
        } else {
            if (store.welcomed() && store.flag("restore_tabs", true)) {
                try {
                    org.json.JSONArray a = new org.json.JSONArray(store.str("savedtabs", "[]"));
                    for (int i = 0; i < a.length() && i < 15; i++) {
                        Tab t = newTab();
                        loadIn(t, a.getString(i));
                    }
                } catch (Exception ignored) {
                }
            }
            handleIntent(getIntent());
        }
        if (tabs.isEmpty()) newTab();

        registerDownloadDone();
        applyWindowPrefs();
        applyDownloadPrefs();
        if (store.num("bright", -1) >= 0) setBrightness(store.num("bright", -1));
        if (store.flag("quick_access", false)) quickAccess(true);
        finishNightSwitch();
        if (!store.welcomed()) showWelcome();
        else afterWelcome();
        if (saved == null && store.welcomed()) showSplash();
    }

    /** UC style launch screen: clean white page with the logo and name at the bottom. */
    private void showSplash() {
        store.setSplashDone(true);
        final FrameLayout sp = new FrameLayout(this);
        sp.setBackgroundColor(pal.night ? 0xFF0F1115 : Color.WHITE);
        sp.setClickable(true);

        LinearLayout mark = new LinearLayout(this);
        mark.setOrientation(LinearLayout.HORIZONTAL);
        mark.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams lgp = new LinearLayout.LayoutParams(dp(66), dp(54));
        lgp.rightMargin = dp(10);
        mark.addView(logo, lgp);
        android.text.SpannableString word = new android.text.SpannableString("S.R Browser");
        word.setSpan(new android.text.style.ForegroundColorSpan(Pal.RED), 0, 3, 0);
        word.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), 0, 3, 0);
        TextView name = Ui.text(this, "", 34, pal.night ? Color.WHITE : 0xFF1A1D23, false);
        name.setText(word);
        mark.addView(name);
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        fp.bottomMargin = dp(54);
        sp.addView(mark, fp);

        TextView india = Ui.text(this, "Made in India", 12.5f, pal.muted, false);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        ip.bottomMargin = dp(30);
        sp.addView(india, ip);
        splash = sp;

        mark.setAlpha(0f);
        mark.setTranslationY(dp(12));
        mark.animate().alpha(1f).translationY(0).setDuration(380).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
        india.setAlpha(0f);
        india.animate().alpha(1f).setStartDelay(200).setDuration(380).start();
        screen.addView(sp, new FrameLayout.LayoutParams(-1, -1));
        ui.postDelayed(() -> sp.animate().alpha(0f).setDuration(240).withEndAction(() -> {
            screen.removeView(sp);
            if (splash == sp) splash = null;
        }).start(), 1000);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) lastTouch = System.currentTimeMillis();
        try {
            handleSwipe(ev);
        } catch (Exception ignored) {
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        ArrayList<String> u = new ArrayList<>();
        for (Tab t : tabs) u.add(t.home ? "" : t.url);
        out.putStringArrayList("tabs", u);
        out.putInt("cur", tabs.indexOf(cur));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent i) {
        if (i != null && "sr.SEARCH".equals(i.getAction())) {
            if (tabs.isEmpty()) newTab();
            ui.postDelayed(() -> {
                closeAllPanels();
                if (!cur.home) {
                    Tab nt = newTab();
                    switchTo(nt);
                }
                if (homeEdit != null) {
                    homeEdit.requestFocus();
                    InputMethodManager m = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (m != null) m.showSoftInput(homeEdit, 0);
                }
            }, 300);
            return;
        }
        if (i != null && "sr.OPEN_DOWNLOADS".equals(i.getAction())) {
            if (tabs.isEmpty()) newTab();
            if (!dlPanelOnTop()) ui.post(this::openDownloader);
            return;
        }
        if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) {
            Tab t = newTab();
            loadIn(t, i.getData().toString());
        } else if (tabs.isEmpty()) {
            newTab();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        boolean pip = Build.VERSION.SDK_INT >= 24 && isInPictureInPictureMode();
        boolean keep = pip || (store.flag("bg_play", false) && cur != null && !cur.home);
        if (cur != null && !keep) cur.web.onPause();
        if (adBlocked > 0) {
            store.setLng("adcount", store.lng("adcount", 0) + adBlocked);
            adBlocked = 0;
        }
        saveTabsForRestore();
    }

    private void saveTabsForRestore() {
        org.json.JSONArray a = new org.json.JSONArray();
        if (!store.incognito()) for (Tab t : tabs) if (!t.home && t.url != null && t.url.startsWith("http")) a.put(t.url);
        store.setStr("savedtabs", a.toString());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (cur != null) cur.web.onResume();
        if (store.num("imgmode", 0) == 2) applyAllWebPrefs();
        refreshPanel();
        checkClipboard();
    }

    @Override
    protected void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        Grabber.listener = null;
        if (dlDone != null) {
            try {
                unregisterReceiver(dlDone);
            } catch (Exception ignored) {
            }
            dlDone = null;
        }
        for (Tab t : tabs) {
            try {
                webHolder.removeView(t.web);
                t.web.destroy();
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        } else if (req == REQ_PHOTO) {
            if (res == RESULT_OK && data != null && data.getData() != null) saveWallpaper(data.getData());
        } else {
            super.onActivityResult(req, res, data);
        }
    }

    @Override
    public void onBackPressed() {
        if (splash != null) {
            return;
        }
        if (customView != null) {
            hideCustom();
        } else if (tabsView != null) {
            closeTabsView();
        } else if (!panels.isEmpty()) {
            closePanel();
        } else if (scrim.getVisibility() == View.VISIBLE) {
            closeMenu();
        } else if (welcome != null) {
            if (!(welcome instanceof Intro) || !((Intro) welcome).back()) finish();
        } else if (fullscreen) {
            fullscreen = false;
            applySystemUi();
        } else {
            goBack();
        }
    }

    private BoolCb permCb;

    /** UC style site permission prompt. */
    private void askSite(String origin, String what, final BoolCb cb) {
        LinearLayout c = ucCard(false);
        c.addView(ucTitle("Site permission"));
        String h = origin == null ? "" : origin.replaceFirst("^https?://", "");
        TextView m = Ui.text(this, h + " " + what, 16, pal.fg, false);
        m.setGravity(Gravity.CENTER);
        c.addView(m);
        final Dialog d = ucShow(c, false);
        final boolean[] done = {false};
        c.addView(ucBtn("Allow", true, v -> {
            done[0] = true;
            d.dismiss();
            cb.on(true);
        }));
        c.addView(ucBtn("Block", false, v -> {
            done[0] = true;
            d.dismiss();
            cb.on(false);
        }));
        d.setOnDismissListener(x -> {
            if (!done[0]) cb.on(false);
        });
    }

    private void withPerms(String[] perms, BoolCb cb) {
        boolean all = true;
        for (String p : perms) if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) all = false;
        if (all) {
            cb.on(true);
            return;
        }
        permCb = cb;
        requestPermissions(perms, 9);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == 9 && permCb != null) {
            boolean ok = res.length > 0;
            for (int r : res) if (r != PackageManager.PERMISSION_GRANTED) ok = false;
            BoolCb cb = permCb;
            permCb = null;
            cb.on(ok);
        }
    }

    private void ensurePerms() {
        try {
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 2);
            } else if (Build.VERSION.SDK_INT < 29
                    && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            }
        } catch (Exception ignored) {
        }
    }

    private void applySystemUi() {
        int f = 0;
        if (fullscreen || customView != null) {
            f = View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        } else if (!pal.night) {
            if (Build.VERSION.SDK_INT >= 23) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(f);
        applyBars();
    }

    private void applyBars() {
        boolean web = cur != null && !cur.home;
        boolean hide = barsHidden && web;
        topBar.setVisibility(!fullscreen && web && !hide ? View.VISIBLE : View.GONE);
        bottomBar.setVisibility(fullscreen || hide ? View.GONE : View.VISIBLE);
    }

    /* ------------------------------------------------------------------ */
    /* Main UI                                                            */
    /* ------------------------------------------------------------------ */

    private void buildUi() {
        screen = new FrameLayout(this);
        screen.setBackgroundColor(pal.bg);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        screen.addView(root, new FrameLayout.LayoutParams(-1, -1));

        // Page top bar (shown on web pages): mark | Enter URL + Search | refresh
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(pal.bar);
        topBar.setPadding(dp(10), dp(8), dp(6), dp(8));

        LinearLayout urlBox = new LinearLayout(this);
        urlBox.setOrientation(LinearLayout.HORIZONTAL);
        urlBox.setGravity(Gravity.CENTER_VERTICAL);
        urlBox.setBackground(Ui.round(this, pal.surface2, 22));
        urlBox.setPadding(dp(12), 0, 0, 0);
        topBar.addView(urlBox, new LinearLayout.LayoutParams(0, dp(44), 1));
        secIcon = Ui.icon(this, R.drawable.ic_secure, 22, 0xFF22C55E);
        urlBox.addView(secIcon);

        urlEdit = new EditText(this);
        urlEdit.setHint(tr("Enter URL"));
        urlEdit.setHintTextColor(pal.muted);
        urlEdit.setTextColor(pal.fg);
        urlEdit.setTextSize(15.5f);
        urlEdit.setSingleLine(true);
        urlEdit.setBackground(null);
        urlEdit.setSelectAllOnFocus(true);
        urlEdit.setPadding(dp(10), 0, dp(8), 0);
        urlEdit.setOnFocusChangeListener((v, has) -> {
            if (has) {
                if (cur != null && !cur.home) urlEdit.setText(cur.url);
                urlEdit.selectAll();
                showTypingBar(true);
            } else {
                showTypingBar(false);
                updateUrlBar();
            }
        });
        urlEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlEdit.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlEdit.setOnEditorActionListener((v, actionId, ev) -> {
            submitFrom(urlEdit);
            return true;
        });
        urlBox.addView(urlEdit, new LinearLayout.LayoutParams(0, -1, 1));

        btnRefresh = Ui.icon(this, R.drawable.ic_refresh, 24, pal.icon);
        btnRefresh.setPadding(dp(5), dp(5), dp(5), dp(5));
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(dp(38), dp(38));
        rl.leftMargin = dp(4);
        btnRefresh.setLayoutParams(rl);
        btnRefresh.setOnClickListener(v -> {
            if (cur.home) return;
            if (loading) cur.web.stopLoading();
            else cur.web.reload();
        });
        topBar.addView(btnRefresh);
        ImageView star = Ui.icon(this, R.drawable.ic_star_add, 24, pal.icon);
        star.setPadding(dp(5), dp(5), dp(5), dp(5));
        star.setLayoutParams(new LinearLayout.LayoutParams(dp(38), dp(38)));
        star.setOnClickListener(v -> addBookmark());
        topBar.addView(star);
        root.addView(topBar, new LinearLayout.LayoutParams(-1, -2));
        typingBar = buildTypingBar();
        typingBar.setVisibility(View.GONE);
        root.addView(typingBar, new LinearLayout.LayoutParams(-1, dp(44)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(pal.accent));
        progress.setVisibility(View.INVISIBLE);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(2)));

        // Content: home screen or web pages
        FrameLayout content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        homeView = new ScrollView(this);
        homeView.setFillViewport(true);
        homeView.setVerticalScrollBarEnabled(false);
        homeBox = new LinearLayout(this);
        homeBox.setOrientation(LinearLayout.VERTICAL);
        homeBox.setPadding(dp(16), dp(24), dp(16), dp(28));
        homeView.addView(homeBox, new ViewGroup.LayoutParams(-1, -2));
        content.addView(homeView, new FrameLayout.LayoutParams(-1, -1));

        webHolder = new FrameLayout(this);
        content.addView(webHolder, new FrameLayout.LayoutParams(-1, -1));

        // Floating "download video" button (shows when a video is found on the page)
        FrameLayout fab = new FrameLayout(this);
        fab.setBackground(oval(pal.accent));
        fab.setElevation(dp(6));
        fab.addView(Ui.icon(this, R.drawable.ic_download, 24, Color.WHITE), new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
        fab.setVisibility(View.GONE);
        fab.setOnClickListener(v -> askVideo(cur));
        FrameLayout.LayoutParams vf = new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.BOTTOM | Gravity.END);
        vf.rightMargin = dp(16);
        vf.bottomMargin = dp(18);
        content.addView(fab, vf);
        videoFab = fab;

        // Bottom bar: back | forward | menu | tabs | home
        View line = new View(this);
        line.setBackgroundColor(pal.line);
        root.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));

        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setBackgroundColor(pal.bar);
        btnBack = barBtn(R.drawable.ic_back, this::goBack);
        btnFwd = barBtn(R.drawable.ic_forward, () -> {
            if (!cur.home && cur.web.canGoForward()) cur.web.goForward();
        });
        View btnMenu = barBtn(R.drawable.ic_menu, this::openMenu);
        btnMenuV = btnMenu;
        FrameLayout tabsBtn = new FrameLayout(this);
        tabsIcon = Ui.icon(this, R.drawable.ic_tabs, 26, pal.icon);
        tabsBtn.addView(tabsIcon, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        tabCount = Ui.text(this, "1", 11, pal.icon, true);
        tabCount.setGravity(Gravity.CENTER);
        tabsBtn.addView(tabCount, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        tabsBtn.setOnClickListener(v -> openTabs());
        View btnHome = barBtn(R.drawable.ic_home, () -> {
            cur.home = true;
            showCurrent();
        });
        bottomBar.addView(btnBack, new LinearLayout.LayoutParams(0, dp(52), 1));
        bottomBar.addView(btnFwd, new LinearLayout.LayoutParams(0, dp(52), 1));
        bottomBar.addView(btnMenu, new LinearLayout.LayoutParams(0, dp(52), 1));
        bottomBar.addView(tabsBtn, new LinearLayout.LayoutParams(0, dp(52), 1));
        bottomBar.addView(btnHome, new LinearLayout.LayoutParams(0, dp(52), 1));
        root.addView(bottomBar, new LinearLayout.LayoutParams(-1, -2));

        refreshHome();
    }

    private View barBtn(int res, Runnable r) {
        FrameLayout f = new FrameLayout(this);
        f.addView(Ui.icon(this, res, 25, pal.icon), new FrameLayout.LayoutParams(dp(25), dp(25), Gravity.CENTER));
        f.setOnClickListener(v -> r.run());
        return f;
    }

    private void updateTabBtn() {
        boolean inc = store.incognito();
        tabsIcon.setImageResource(inc ? R.drawable.ic_ghost : R.drawable.ic_tabs);
        tabsIcon.setColorFilter(inc ? PURPLE : pal.icon, android.graphics.PorterDuff.Mode.SRC_IN);
        tabCount.setText(inc ? "" : String.valueOf(tabs.size()));
    }

    /* ------------------------------------------------------------------ */
    /* Welcome screen                                                     */
    /* ------------------------------------------------------------------ */

    private LinearLayout indiaLine(int textColor, float sp) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER);
        LinearLayout flag = new LinearLayout(this);
        flag.setOrientation(LinearLayout.VERTICAL);
        int[] cs = {0xFFFF9933, 0xFFFFFFFF, 0xFF138808};
        for (int c : cs) {
            View s = new View(this);
            s.setBackgroundColor(c);
            flag.addView(s, new LinearLayout.LayoutParams(dp(20), dp(4)));
        }
        flag.setBackground(Ui.round(this, 0xFFDDDDDD, 2));
        flag.setPadding(dp(1), dp(1), dp(1), dp(1));
        l.addView(flag, new LinearLayout.LayoutParams(-2, -2));
        TextView t = Ui.text(this, tr("Made in India"), sp, textColor, true);
        t.setPadding(dp(8), 0, 0, 0);
        l.addView(t);
        return l;
    }

    /** First run, UC style: welcome + agreement, then default browser offer, then quick tips. */
    private void showWelcome() {
        final Intro in = new Intro(this, store.lang(), lang -> {
            store.setWelcomed(true);
            boolean changed = !lang.equals(store.lang());
            store.setLang(lang);
            store.setFlag("show_tips", true);
            if (changed) {
                recreate();
                return;
            }
            View w = welcome;
            welcome = null;
            if (w != null) screen.removeView(w);
            refreshHome();
            afterWelcome();
        });
        welcome = in;
        screen.addView(in, new FrameLayout.LayoutParams(-1, -1));
    }

    /** Runs once after the welcome page (also after a language change restarts the screen). */
    private void afterWelcome() {
        if (!store.flag("show_tips", false)) {
            ensurePerms();
            return;
        }
        store.setFlag("show_tips", false);
        if (isDefaultBrowser()) {
            showTips(0);
            return;
        }
        LinearLayout c = ucCard(true);
        ImageView lg = new ImageView(this);
        lg.setImageResource(R.drawable.intro_logo);
        lg.setScaleType(ImageView.ScaleType.FIT_CENTER);
        c.addView(lg, new LinearLayout.LayoutParams(-1, dp(90)));
        c.addView(ucTitle("Set S.R Browser as default browser?"));
        TextView n = Ui.text(this, tr("Open every link with S.R Browser: faster pages, no ads and one-tap downloads."), 15, pal.muted, false);
        n.setGravity(Gravity.CENTER);
        c.addView(n);
        final Dialog d = ucShow(c, true);
        d.setCancelable(false);
        c.addView(ucBtn("Set as Default", true, v -> {
            d.dismiss();
            requestDefault();
            ui.postDelayed(() -> showTips(0), 600);
        }));
        c.addView(ucBtn("Not now", false, v -> {
            d.dismiss();
            showTips(0);
        }));
    }

    private void requestDefault() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_BROWSER) && !rm.isRoleHeld(RoleManager.ROLE_BROWSER)) {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_BROWSER), 31);
                    return;
                }
            }
        } catch (Exception ignored) {
        }
        openDefaultSettings();
    }

    /** UC style tips that point at the bottom bar buttons. Tap anywhere for the next one. */
    private void showTips(final int step) {
        final String[][] tips = {
                {tr("Tap here for Downloads, History, Settings and more"), "2"},
                {tr("All your open tabs are here. Swipe a tab away to close it"), "3"},
                {tr("Play a video on any site, then tap the red download button on it"), "-1"},
        };
        if (step >= tips.length) {
            ensurePerms();
            return;
        }
        final FrameLayout o = new FrameLayout(this);
        o.setBackgroundColor(0xB3000000);
        o.setClickable(true);
        int slot = Integer.parseInt(tips[step][1]);
        LinearLayout bubble = new LinearLayout(this);
        bubble.setOrientation(LinearLayout.VERTICAL);
        bubble.setPadding(dp(18), dp(14), dp(18), dp(14));
        bubble.setBackground(Ui.round(this, Color.WHITE, 16));
        bubble.addView(Ui.text(this, tips[step][0], 15.5f, 0xFF1A1D23, true));
        TextView nx = Ui.text(this, (step + 1) + "/" + tips.length + "   " + tr(step == tips.length - 1 ? "Got it" : "Next") + " ›", 13.5f, Pal.RED, true);
        nx.setPadding(0, dp(8), 0, 0);
        nx.setGravity(Gravity.END);
        bubble.addView(nx, new LinearLayout.LayoutParams(-1, -2));
        if (slot >= 0) {
            int w = screen.getWidth() > 0 ? screen.getWidth() : getResources().getDisplayMetrics().widthPixels;
            int cx = w * (2 * slot + 1) / 10;
            View ring = new View(this);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setStroke(dp(3), Color.WHITE);
            ring.setBackground(g);
            FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM | Gravity.START);
            rp.leftMargin = cx - dp(29);
            rp.bottomMargin = dp(-3);
            o.addView(ring, rp);
            ring.animate().scaleX(1.15f).scaleY(1.15f).setDuration(700).setInterpolator(new android.view.animation.CycleInterpolator(2)).start();
            TextView arrow = Ui.text(this, "▼", 18, Color.WHITE, true);
            FrameLayout.LayoutParams ap = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START);
            ap.leftMargin = cx - dp(8);
            ap.bottomMargin = dp(62);
            o.addView(arrow, ap);
            FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
            bp.setMargins(dp(24), 0, dp(24), dp(92));
            o.addView(bubble, bp);
        } else {
            FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
            bp.setMargins(dp(32), 0, dp(32), 0);
            o.addView(bubble, bp);
        }
        o.setAlpha(0f);
        screen.addView(o, new FrameLayout.LayoutParams(-1, -1));
        o.animate().alpha(1f).setDuration(200).start();
        o.setOnClickListener(v -> o.animate().alpha(0f).setDuration(160).withEndAction(() -> {
            screen.removeView(o);
            showTips(step + 1);
        }).start());
    }

    /* ------------------------------------------------------------------ */
    /* Home screen                                                        */
    /* ------------------------------------------------------------------ */

    private static int lum(int c) {
        return (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10;
    }

    private boolean homeDark() {
        int tx = store.num("home_text", 0);
        if (tx == 1) return true;
        if (tx == 2) return false;
        int t = store.theme();
        if (t == 6) return (lum(store.num("home_c1", 0xFFFFFFFF)) + lum(store.num("home_c2", 0xFFFFFFFF))) / 2 < 150;
        return t == 0 ? pal.night : true;
    }

    private int homeFg() {
        return homeDark() ? 0xFFFFFFFF : 0xFF1A1D23;
    }

    private int homeSub() {
        return homeDark() ? 0xCCFFFFFF : 0xFF6B7180;
    }

    private Drawable homeBgDrawable() {
        int t = store.theme();
        int[] c;
        if (t == 6) c = new int[]{store.num("home_c1", 0xFFFFFFFF), store.num("home_c2", 0xFFFFE9DF)};
        else if (t == 0) c = pal.night ? new int[]{pal.bg, 0xFF2A1518} : new int[]{pal.bg, 0xFFFFE9DF};
        else c = THEME_COLORS[Math.max(0, Math.min(THEME_COLORS.length - 1, t))];
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, c);
        if (!store.flag("home_wave", false)) return g;
        return new android.graphics.drawable.LayerDrawable(new Drawable[]{g, new WaveDrawable(homeDark())});
    }

    /** UC style glowing waves at the bottom of the homepage. */
    static final class WaveDrawable extends Drawable {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final android.graphics.Path path = new android.graphics.Path();
        private final boolean dark;

        WaveDrawable(boolean dark) {
            this.dark = dark;
        }

        @Override
        public void draw(Canvas c) {
            Rect b = getBounds();
            float w = b.width(), h = b.height();
            int[][] bands = dark ? new int[][]{{0x55FF7A1A, 0x00FF7A1A}, {0x66C2410C, 0x00C2410C}, {0x40FFB86B, 0x00FFB86B}}
                    : new int[][]{{0x40FF8A4C, 0x00FF8A4C}, {0x35E5121B, 0x00E5121B}, {0x30FFC27A, 0x00FFC27A}};
            float[] start = {0.72f, 0.80f, 0.86f};
            for (int i = 0; i < 3; i++) {
                float y0 = h * start[i];
                path.reset();
                path.moveTo(0, y0 + h * 0.06f);
                path.cubicTo(w * 0.3f, y0 - h * 0.08f, w * 0.6f, y0 + h * 0.12f, w, y0 - h * 0.04f * (i + 1));
                path.lineTo(w, h);
                path.lineTo(0, h);
                path.close();
                p.setShader(new android.graphics.LinearGradient(0, y0 - h * 0.1f, 0, h, bands[i][0], bands[i][1], android.graphics.Shader.TileMode.CLAMP));
                c.drawPath(path, p);
            }
            p.setShader(null);
        }

        @Override
        public void setAlpha(int a) {
        }

        @Override
        public void setColorFilter(android.graphics.ColorFilter cf) {
        }

        @Override
        public int getOpacity() {
            return android.graphics.PixelFormat.TRANSLUCENT;
        }
    }

    private void applyHomeBackground() {
        int t = store.theme();
        if (t == 6 || store.flag("home_wave", false) && t != 5) {
            homeView.setBackground(homeBgDrawable());
            return;
        }
        if (t == 5) {
            File f = new File(getFilesDir(), "wall.jpg");
            Bitmap b = f.exists() ? BitmapFactory.decodeFile(f.getPath()) : null;
            if (b != null) {
                android.graphics.drawable.BitmapDrawable bd = new android.graphics.drawable.BitmapDrawable(getResources(), b);
                bd.setGravity(Gravity.FILL);
                homeView.setBackground(bd);
                return;
            }
            t = 0;
            store.setTheme(0);
        }
        int[] c;
        if (t == 0) c = pal.night ? new int[]{pal.bg, 0xFF2A1518} : new int[]{pal.bg, 0xFFFFE9DF};
        else c = THEME_COLORS[Math.max(0, Math.min(THEME_COLORS.length - 1, t))];
        homeView.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, c));
    }

    private Bitmap assetBitmap(String path) {
        try (InputStream in = getAssets().open(path)) {
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            return null;
        }
    }

    private String engineName() {
        for (String[] e : ENGINES) if (e[0].equals(store.engine())) return e[1];
        return "Google";
    }

    private View engineBadge(int sizeDp) {
        int idx = 0;
        for (int i = 0; i < ENGINES.length; i++) if (ENGINES[i][0].equals(store.engine())) idx = i;
        return engineBadgeAt(idx, sizeDp);
    }

    private View engineBadgeAt(int idx, int sizeDp) {
        FrameLayout f = new FrameLayout(this);
        Bitmap real = assetBitmap("engines/" + ENGINES[idx][0] + ".png");
        if (real != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(real);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        } else {
            f.setBackground(oval(0xFFFFFFFF));
            if (idx == 0) {
                ImageView g = new ImageView(this);
                g.setImageResource(R.drawable.t_gg);
                g.setScaleType(ImageView.ScaleType.FIT_CENTER);
                int pad = dp(sizeDp * 0.2f);
                g.setPadding(pad, pad, pad, pad);
                f.addView(g, new FrameLayout.LayoutParams(-1, -1));
            } else {
                TextView t = Ui.text(this, ENGINES[idx][2], sizeDp * 0.5f, ENGINE_COLOR[idx], true);
                t.setGravity(Gravity.CENTER);
                f.addView(t, new FrameLayout.LayoutParams(-1, -1));
            }
        }
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        return f;
    }

    private void refreshHome() {
        String keep = homeEdit == null ? "" : homeEdit.getText().toString();
        homeBox.removeAllViews();
        homeBox.setGravity(Gravity.CENTER_HORIZONTAL);
        applyHomeBackground();
        int fg = homeFg();

        // Logo, fixed size
        View logo;
        ImageView li = new ImageView(this);
        li.setImageResource(R.drawable.logo);
        li.setScaleType(ImageView.ScaleType.FIT_CENTER);
        if (homeDark()) {
            FrameLayout plate = new FrameLayout(this);
            plate.setBackground(Ui.round(this, 0xFFFFFFFF, 22));
            plate.setPadding(dp(14), dp(12), dp(14), dp(12));
            plate.addView(li, new FrameLayout.LayoutParams(-1, -1));
            logo = plate;
        } else {
            logo = li;
        }
        int ht = store.num("home_title", 0);
        if (ht != 1) {
            LinearLayout.LayoutParams lp = ht == 2 ? new LinearLayout.LayoutParams(dp(120), dp(100)) : new LinearLayout.LayoutParams(dp(210), dp(178));
            lp.topMargin = dp(36);
            homeBox.addView(logo, lp);
        }
        if (ht != 0) {
            TextView name = Ui.text(this, "S.R Browser", 42, fg, false);
            name.setTypeface(Typeface.create("sans-serif-thin", Typeface.NORMAL));
            name.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-2, -2);
            np.topMargin = dp(ht == 1 ? 90 : 8);
            homeBox.addView(name, np);
        }

        if (!store.homeNote().isEmpty()) {
            TextView n = Ui.text(this, store.homeNote(), 13.5f, homeSub(), false);
            n.setGravity(Gravity.CENTER);
            n.setPadding(0, dp(10), 0, 0);
            homeBox.addView(n);
        }

        // Search pill
        LinearLayout pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        int box = store.num("home_box", 0);
        int boxBg = box == 1 ? (homeDark() ? 0x33FFFFFF : 0x22000000) : box == 2 ? 0xFF24272E : pal.surface;
        final int boxFg = box == 2 || (box == 1 && homeDark()) ? 0xFFFFFFFF : pal.fg;
        final int boxHint = box == 2 || (box == 1 && homeDark()) ? 0xAAFFFFFF : pal.muted;
        pill.setBackground(Ui.round(this, boxBg, 30));
        pill.setElevation(dp(5));
        pill.setPadding(dp(14), 0, dp(10), 0);
        LinearLayout eng = new LinearLayout(this);
        eng.setOrientation(LinearLayout.HORIZONTAL);
        eng.setGravity(Gravity.CENTER_VERTICAL);
        eng.addView(engineBadge(32));
        TextView tri = Ui.text(this, "▾", 12, pal.muted, false);
        tri.setPadding(dp(4), 0, dp(4), 0);
        eng.addView(tri);
        eng.setOnClickListener(v -> pickEngine());
        pill.addView(eng);

        homeEdit = new EditText(this);
        homeEdit.setHint(tr("Search or Enter URL"));
        homeEdit.setHintTextColor(boxHint);
        homeEdit.setTextColor(boxFg);
        homeEdit.setTextSize(16);
        homeEdit.setSingleLine(true);
        homeEdit.setBackground(null);
        homeEdit.setPadding(dp(8), 0, dp(8), 0);
        homeEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        homeEdit.setImeOptions(EditorInfo.IME_ACTION_GO);
        homeEdit.setText(keep);
        homeEdit.setOnEditorActionListener((v, actionId, ev) -> {
            submitFrom(homeEdit);
            return true;
        });
        pill.addView(homeEdit, new LinearLayout.LayoutParams(0, -1, 1));
        ImageView go = Ui.icon(this, R.drawable.ic_search, 22, pal.accent);
        go.setPadding(dp(4), dp(4), dp(4), dp(4));
        go.setLayoutParams(new LinearLayout.LayoutParams(dp(32), dp(32)));
        go.setOnClickListener(v -> submitFrom(homeEdit));
        pill.addView(go);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(56));
        pp.topMargin = dp(26);
        pp.leftMargin = dp(4);
        pp.rightMargin = dp(4);
        homeBox.addView(pill, pp);

        // Web / Videos / Images
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setGravity(Gravity.CENTER);
        String[] names = {"Web", "Videos", "Images"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView c = Ui.text(this, tr(names[i]), 13, i == mode ? Color.WHITE : homeSub(), true);
            c.setPadding(dp(16), dp(7), dp(16), dp(7));
            c.setBackground(Ui.round(this, i == mode ? pal.accent : (homeDark() ? 0x33FFFFFF : pal.surface), 20));
            c.setOnClickListener(v -> {
                mode = idx;
                store.setSearchMode(idx);
                refreshHome();
            });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
            cp.leftMargin = dp(4);
            cp.rightMargin = dp(4);
            chips.addView(c, cp);
        }
        LinearLayout.LayoutParams chp = new LinearLayout.LayoutParams(-2, -2);
        chp.topMargin = dp(16);
        if (store.flag("home_chips", true)) homeBox.addView(chips, chp);

        // Quick row
        if (store.showQuick()) {
            LinearLayout q = new LinearLayout(this);
            q.setOrientation(LinearLayout.HORIZONTAL);
            q.addView(quick(R.drawable.ic_dl_hex, "Downloader", this::openDownloader), new LinearLayout.LayoutParams(0, -2, 1));
            q.addView(quick(R.drawable.ic_notes, "Notes", this::openNotes), new LinearLayout.LayoutParams(0, -2, 1));
            q.addView(quick(R.drawable.ic_clock, "History", this::openHistory), new LinearLayout.LayoutParams(0, -2, 1));
            q.addView(quick(R.drawable.ic_bookmark_o, "Bookmark", this::openBookmarks), new LinearLayout.LayoutParams(0, -2, 1));
            LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(-1, -2);
            qp.topMargin = dp(30);
            homeBox.addView(q, qp);
        }

        // Sites
        List<View> tiles = new ArrayList<>();
        for (int i = 0; i < SITES.length; i++) {
            final String url = SITES[i][2];
            GradientDrawable bg;
            if (SITES[i][0].equals("ig")) {
                bg = new GradientDrawable(GradientDrawable.Orientation.BL_TR,
                        new int[]{0xFFFDB53C, 0xFFF0443D, 0xFFC32AA3, 0xFF6A3DE8});
                bg.setShape(GradientDrawable.OVAL);
            } else {
                bg = oval(SITE_BG[i]);
            }
            int res = getResources().getIdentifier("t_" + SITES[i][0], "drawable", getPackageName());
            tiles.add(tile(SITES[i][1], bg, res, null, "icons/" + SITES[i][0] + ".png",
                    () -> loadIn(cur, url), null, fg));
        }
        List<Store.Item> bms = store.list("bm");
        for (int i = 0; i < bms.size(); i++) {
            final Store.Item b = bms.get(i);
            final int idx = i;
            String letter = b.title.isEmpty() ? "?" : b.title.substring(0, 1).toUpperCase();
            tiles.add(tile(b.title, oval(pal.surface), 0, letter, null,
                    () -> loadIn(cur, b.url),
                    () -> new AlertDialog.Builder(this).setTitle("Remove " + b.title + "?")
                            .setPositiveButton("Remove", (d, which) -> {
                                store.remove("bm", idx);
                                refreshHome();
                            }).setNegativeButton("Cancel", null).show(), fg));
        }
        GradientDrawable addBg = oval(homeDark() ? 0x22FFFFFF : pal.surface);
        addBg.setStroke(dp(1), pal.accent);
        tiles.add(tile("Add", addBg, R.drawable.ic_plus, null, null, this::promptAddSite, null, fg));

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < tiles.size(); i += 5) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int j = 0; j < 5; j++) {
                View v = i + j < tiles.size() ? tiles.get(i + j) : new View(this);
                row.addView(v, new LinearLayout.LayoutParams(0, -2, 1));
            }
            grid.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2);
        gp.topMargin = dp(26);
        homeBox.addView(grid, gp);

        if (store.showIndia()) {
            LinearLayout in = indiaLine(homeSub(), 13);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-2, -2);
            ip.topMargin = dp(34);
            homeBox.addView(in, ip);
        }
    }

    private View quick(int res, String label, final Runnable r) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER_HORIZONTAL);
        v.setPadding(0, dp(6), 0, dp(6));
        v.addView(Ui.icon(this, res, 30, homeFg()));
        TextView t = Ui.oneLine(Ui.text(this, tr(label), 13, homeFg(), false));
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(8), 0, 0);
        v.addView(t, new LinearLayout.LayoutParams(-1, -2));
        v.setOnClickListener(x -> r.run());
        return v;
    }

    private View tile(String name, GradientDrawable bg, int iconRes, String letter, String assetPath,
                      final Runnable click, final Runnable longClick, int labelColor) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setPadding(dp(2), dp(9), dp(2), dp(9));

        FrameLayout box = new FrameLayout(this);
        box.setBackground(bg);
        box.setElevation(dp(2));
        Bitmap real = assetPath == null ? null : assetBitmap(assetPath);
        if (real != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(real);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(bg);
            iv.setClipToOutline(true);
            box.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        } else if (letter != null) {
            TextView l = Ui.text(this, letter, 22, pal.accent, true);
            l.setGravity(Gravity.CENTER);
            box.addView(l, new FrameLayout.LayoutParams(-1, -1));
        } else if (iconRes != 0) {
            int tint = iconRes == R.drawable.ic_plus ? pal.accent : 0;
            ImageView ic = Ui.icon(this, iconRes, 28, tint);
            box.addView(ic, new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER));
        }
        t.addView(box, new LinearLayout.LayoutParams(dp(52), dp(52)));

        TextView n = Ui.oneLine(Ui.text(this, name, 12, labelColor, false));
        n.setGravity(Gravity.CENTER);
        n.setPadding(0, dp(6), 0, 0);
        t.addView(n, new LinearLayout.LayoutParams(-1, -2));

        t.setOnClickListener(v -> click.run());
        if (longClick != null) {
            t.setOnLongClickListener(v -> {
                longClick.run();
                return true;
            });
        }
        return t;
    }

    private EditText ucInput(String hint, int inputType) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(inputType);
        e.setTextColor(pal.fg);
        e.setHintTextColor(pal.muted);
        e.setTextSize(17);
        e.setBackground(Ui.round(this, pal.surface2, 16));
        e.setPadding(dp(18), 0, dp(18), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.topMargin = dp(10);
        e.setLayoutParams(lp);
        return e;
    }

    private void promptAddSite() {
        LinearLayout c = ucCard(false);
        c.addView(ucTitle("Add to home"));
        final EditText name = ucInput("Name (e.g. Hotstar)", InputType.TYPE_CLASS_TEXT);
        final EditText addr = ucInput("https://example.com", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        c.addView(name);
        c.addView(addr);
        final Dialog d = ucShow(c, false);
        c.addView(ucBtn("Add", true, v -> {
            String nm = name.getText().toString().trim();
            String ad = addr.getText().toString().trim();
            if (ad.isEmpty()) {
                toast("Enter an address");
                return;
            }
            String url = toUrl(ad);
            if (nm.isEmpty()) nm = host(url);
            store.add("bm", nm, url, 100, false);
            d.dismiss();
            refreshHome();
            refreshPanel();
            toast(nm + " added to home");
        }));
        c.addView(ucBtn("Cancel", false, v -> d.dismiss()));
        if (d.getWindow() != null) d.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE | android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }

    /** UC style: show the page title with a security mark; the full link appears when you tap it. */
    private void updateUrlBar() {
        if (urlEdit == null || cur == null || urlEdit.hasFocus()) return;
        if (cur.home) {
            urlEdit.setText("");
            secIcon.setImageResource(R.drawable.ic_search);
            secIcon.setColorFilter(pal.muted);
            return;
        }
        boolean https = cur.url != null && cur.url.startsWith("https://");
        secIcon.setImageResource(https ? R.drawable.ic_secure : R.drawable.ic_globe);
        secIcon.setColorFilter(https ? 0xFF22C55E : pal.muted);
        String title = cur.title;
        boolean showTitle = store.num("bar_text", 0) == 0 && title != null && !title.isEmpty()
                && !title.startsWith("http") && !title.equals(cur.url);
        urlEdit.setText(showTitle ? title : cur.url);
    }

    /** Typing Assistant: quick keys above the address bar while typing. */
    private View buildTypingBar() {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setBackgroundColor(pal.bar);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8), 0, dp(8), 0);
        String[] keys = {"www.", ".com", ".in", "/", ".", "https://", ".org", ".net", "m."};
        for (final String k : keys) {
            TextView b = Ui.text(this, k, 14, pal.fg, true);
            b.setPadding(dp(14), dp(7), dp(14), dp(7));
            b.setBackground(Ui.round(this, pal.surface2, 16));
            b.setOnClickListener(v -> {
                int st = Math.max(0, urlEdit.getSelectionStart()), en = Math.max(0, urlEdit.getSelectionEnd());
                urlEdit.getText().replace(Math.min(st, en), Math.max(st, en), k);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.rightMargin = dp(8);
            row.addView(b, lp);
        }
        hs.addView(row, new ViewGroup.LayoutParams(-2, -1));
        return hs;
    }

    private void showTypingBar(boolean show) {
        if (typingBar == null) return;
        typingBar.setVisibility(show && store.flag("typing_assist", true) ? View.VISIBLE : View.GONE);
    }

    private void addBookmark() {
        if (cur.home) {
            promptAddSite();
        } else {
            String t = cur.title == null || cur.title.isEmpty() ? host(cur.url) : cur.title;
            store.add("bm", t, cur.url, 100, false);
            refreshHome();
            toast(tr("Added to bookmarks"));
        }
    }

    /* ------------------------------------------------------------------ */
    /* Tabs and WebView                                                   */
    /* ------------------------------------------------------------------ */

    private Tab newTab() {
        Tab t = new Tab();
        t.web = makeWeb(t);
        webHolder.addView(t.web, new FrameLayout.LayoutParams(-1, -1));
        tabs.add(t);
        switchTo(t);
        return t;
    }

    private void switchTo(Tab t) {
        if (cur != null && cur != t) {
            captureThumb(cur);
            cur.web.onPause();
        }
        cur = t;
        t.web.onResume();
        showCurrent();
    }

    private void showCurrent() {
        for (Tab t : tabs) t.web.setVisibility(t == cur && !t.home ? View.VISIBLE : View.GONE);
        homeView.setVisibility(cur.home ? View.VISIBLE : View.GONE);
        webHolder.setVisibility(cur.home ? View.GONE : View.VISIBLE);
        updateUrlBar();
        urlEdit.clearFocus();
        updateTabBtn();
        loading = false;
        progress.setVisibility(View.INVISIBLE);
        btnRefresh.setImageResource(R.drawable.ic_refresh);
        updateVideoFab();
        barsHidden = false;
        applyBars();
        updateNav();
    }

    private void updateNav() {
        btnBack.setAlpha(cur.home && tabs.size() < 2 ? 0.35f : 1f);
        btnFwd.setAlpha(!cur.home && cur.web.canGoForward() ? 1f : 0.35f);
    }

    private void loadIn(Tab t, String url) {
        t.home = false;
        t.url = url;
        if (t == cur) showCurrent();
        if (store.flag("dnt", false)) {
            java.util.Map<String, String> h = new java.util.HashMap<>();
            h.put("DNT", "1");
            t.web.loadUrl(url, h);
        } else t.web.loadUrl(url);
    }

    private void closeTab(Tab t) {
        int idx = tabs.indexOf(t);
        closedUrls.add(t.home ? "" : t.url);
        tabs.remove(t);
        webHolder.removeView(t.web);
        t.web.destroy();
        if (tabs.isEmpty()) {
            newTab();
        } else if (cur == t) {
            switchTo(tabs.get(Math.max(0, idx - 1)));
        } else {
            showCurrent();
        }
    }

    private void goBack() {
        if (!cur.home) {
            if (cur.web.canGoBack()) {
                cur.web.goBack();
            } else {
                cur.home = true;
                showCurrent();
            }
        } else if (tabs.size() > 1) {
            closeTab(cur);
        } else {
            confirmExit();
        }
    }

    private void confirmExit() {
        if (store.noAskExit()) {
            exitApp();
            return;
        }
        LinearLayout c = ucCard(false);
        c.addView(ucTitle("Sure to exit S.R Browser?"));
        final CheckBox cHist = ucCheck("Clear browsing history", false);
        final CheckBox cHome = ucCheck("Add SR to Home Screen", false);
        final CheckBox cAsk = ucCheck("Do not ask again", false);
        c.addView(cHist);
        c.addView(cHome);
        c.addView(cAsk);
        final Dialog d = ucShow(c, false);
        c.addView(ucBtn("Exit", true, v -> {
            if (cHist.isChecked()) {
                store.clear("hist");
                store.clear("vhist");
            }
            if (cHome.isChecked()) pinHomeShortcut();
            if (cAsk.isChecked()) store.setNoAskExit(true);
            d.dismiss();
            exitApp();
        }));
        c.addView(ucBtn("Cancel", false, v -> d.dismiss()));
    }

    private void exitApp() {
        if (store.flag("clear_exit", false)) {
            store.clear("hist");
            store.clear("vhist");
            store.setStr("savedtabs", "[]");
            for (Tab t : tabs) t.web.clearCache(true);
        } else saveTabsForRestore();
        finishAffinity();
    }

    private void pinHomeShortcut() {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                android.content.pm.ShortcutManager sm = getSystemService(android.content.pm.ShortcutManager.class);
                if (sm != null && sm.isRequestPinShortcutSupported()) {
                    Intent li = new Intent(this, MainActivity.class).setAction(Intent.ACTION_MAIN);
                    android.content.pm.ShortcutInfo si = new android.content.pm.ShortcutInfo.Builder(this, "sr_home")
                            .setShortLabel("S.R Browser")
                            .setIcon(android.graphics.drawable.Icon.createWithResource(this, R.mipmap.ic_launcher))
                            .setIntent(li).build();
                    sm.requestPinShortcut(si, null);
                }
            }
        } catch (Exception ignored) {
        }
    }

    /* ---- UC style dialog helpers ---- */

    private LinearLayout ucCard(boolean bottom) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(24), dp(24), dp(24), dp(bottom ? 20 : 24));
        c.setBackground(bottom ? Ui.roundTop(this, pal.bar, 28) : Ui.round(this, pal.bar, 28));
        return c;
    }

    private TextView ucTitle(String s) {
        TextView t = Ui.text(this, tr(s), 22, pal.fg, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(12), 0, dp(14));
        return t;
    }

    private CheckBox ucCheck(String label, boolean on) {
        CheckBox cb = new CheckBox(this);
        cb.setText(tr(label));
        cb.setTextSize(18);
        cb.setTextColor(pal.fg);
        cb.setChecked(on);
        cb.setPadding(dp(10), dp(14), dp(4), dp(14));
        cb.setButtonTintList(new ColorStateList(
                new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{0xFF2F8CFF, 0xFF8A93A3}));
        return cb;
    }

    private View ucBtn(String label, boolean primary, View.OnClickListener l) {
        TextView b = Ui.text(this, tr(label), 17, primary ? Color.WHITE : pal.fg, true);
        b.setGravity(Gravity.CENTER);
        b.setBackground(Ui.round(this, primary ? 0xFF1C2024 : pal.surface2, 20));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.topMargin = dp(12);
        b.setLayoutParams(lp);
        return b;
    }

    private Dialog ucShow(View content, boolean bottom) {
        Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        d.setContentView(content);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(bottom ? new ColorDrawable(Color.TRANSPARENT)
                    : new InsetDrawable(new ColorDrawable(Color.TRANSPARENT), dp(28), 0, dp(28), 0));
            w.setLayout(-1, -2);
            w.setGravity(bottom ? Gravity.BOTTOM : Gravity.CENTER);
            w.setDimAmount(0.45f);
        }
        d.show();
        return d;
    }

    private void applyWebPrefs(WebView w) {
        WebSettings s = w.getSettings();
        s.setTextZoom(Math.max(50, Math.min(200, store.num("zoom", 100))));
        s.setUserAgentString(store.desktop() ? DESKTOP_UA : store.num("ua", 0) == 2 ? IPHONE_UA : mobileUa);
        s.setJavaScriptEnabled(store.js());
        s.setLoadWithOverviewMode(store.flag("autofit", true));
        w.getSettings().setOffscreenPreRaster(store.num("cloudboost", 0) == 0);
        int img = store.num("imgmode", store.dataSaver() ? 1 : 0);
        s.setBlockNetworkImage(img == 1 || (img == 2 && isMetered()));
        s.setMediaPlaybackRequiresUserGesture(!store.flag("autoplay", true));
        s.setGeolocationEnabled(store.num("perm_loc", 0) == 0);
        s.setSaveFormData(store.flag("forms", true));
        s.setCacheMode(store.flag("speed", false) ? WebSettings.LOAD_CACHE_ELSE_NETWORK : WebSettings.LOAD_DEFAULT);
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(store.flag("safe", true));
        CookieManager.getInstance().setAcceptCookie(store.flag("cookies", true));
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, store.flag("cookies3", true));
    }

    /* ---- Window, gestures and page helpers ---- */

    private static final String ZOOM_JS = "(function(){try{var m=document.querySelector('meta[name=viewport]');"
            + "if(m)m.setAttribute('content','width=device-width,initial-scale=1,user-scalable=yes,maximum-scale=10');}catch(e){}})();";

    private static final String VISITED_JS = "(function(){try{if(document.getElementById('__srvis'))return;var s=document.createElement('style');s.id='__srvis';"
            + "s.textContent='a:visited,a:visited *{color:#8E44AD!important}';(document.head||document.documentElement).appendChild(s);}catch(e){}})();";

    /** Powerful Ad Blocker: removes sticky ad bars and floating ad boxes. */
    private static final String STICKY_JS = "(function(){try{var rx=/(^|[-_ ])(ad|ads|advert|sponsor|banner|promo|sticky-ad|adsbygoogle)([-_ ]|$)/i;"
            + "function clean(){var all=document.querySelectorAll('body *');for(var i=0;i<all.length&&i<4000;i++){var e=all[i];var cs=getComputedStyle(e);"
            + "if(cs.position!='fixed'&&cs.position!='sticky')continue;var r=e.getBoundingClientRect();var id=(e.id||'')+' '+(typeof e.className=='string'?e.className:'');"
            + "var ifr=e.tagName=='IFRAME'||e.querySelector('iframe');if((rx.test(id)||ifr)&&r.height<innerHeight*0.45&&!e.querySelector('video,input')){e.style.setProperty('display','none','important');}}}"
            + "clean();setTimeout(clean,1500);setTimeout(clean,4000);}catch(e){}})();";

    /** Preload Page: lets the browser fetch the next page early. */
    private static final String PRELOAD_JS = "(function(){try{if(window.__srpre)return;window.__srpre=1;var n=document.querySelector('link[rel=next],a[rel=next]');"
            + "if(!n){var as=document.querySelectorAll('a[href]');for(var i=0;i<as.length&&i<600;i++){var t=(as[i].textContent||'').trim();"
            + "if(/^(next|next page|older|\u203a|\u00bb|\u0906\u0917\u0947)$/i.test(t)){n=as[i];break;}}}"
            + "if(n&&n.href&&n.href.indexOf('http')==0){var l=document.createElement('link');l.rel='prefetch';l.href=n.href;document.head.appendChild(l);}}catch(e){}})();";

    private static final String NIGHT_JS = "(function(){try{if(document.getElementById('__srnight'))return;var s=document.createElement('style');s.id='__srnight';"
            + "s.textContent='html{filter:invert(.9) hue-rotate(180deg)!important;background:#111!important}"
            + "img,video,picture,canvas,iframe,svg image,[style*=\"background-image\"]{filter:invert(1) hue-rotate(180deg)!important}';"
            + "(document.head||document.documentElement).appendChild(s);}catch(e){}})();";

    private void applyNightPage(WebView v) {
        if (pal.night && store.flag("night_pages", true)) v.evaluateJavascript(NIGHT_JS, null);
    }

    private static boolean sameDoc(String a, String b) {
        int i = a.indexOf('#'), j = b.indexOf('#');
        return (i < 0 ? a : a.substring(0, i)).equals(j < 0 ? b : b.substring(0, j));
    }

    private void applyWindowPrefs() {
        if (store.flag("keep_on", false)) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        int r = store.num("rotate", 0);
        setRequestedOrientation(r == 1 ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                : r == 2 ? android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                : android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
    }

    private boolean barsHidden = false;

    /** UC style: bars slide away while scrolling down a page and come back when scrolling up. */
    private void showBars(boolean show) {
        if (show == !barsHidden) return;
        barsHidden = !show;
        applyBars();
    }

    private float swipeX, swipeY;
    private boolean swipeEdge;

    private void handleSwipe(MotionEvent ev) {
        if (!store.flag("swipe_nav", true) || cur == null || cur.home || !panels.isEmpty() || customView != null) return;
        int w = screen.getWidth();
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                swipeX = ev.getX();
                swipeY = ev.getY();
                swipeEdge = swipeX < dp(22) || swipeX > w - dp(22);
                break;
            case MotionEvent.ACTION_UP:
                if (!swipeEdge) break;
                swipeEdge = false;
                float dx = ev.getX() - swipeX, dy = Math.abs(ev.getY() - swipeY);
                if (Math.abs(dx) > dp(90) && dy < dp(70)) {
                    if (dx > 0 && swipeX < dp(22)) goBack();
                    else if (dx < 0 && swipeX > w - dp(22) && cur.web.canGoForward()) cur.web.goForward();
                }
                break;
            default:
                break;
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (store.flag("vol_page", false) && cur != null && !cur.home && panels.isEmpty() && customView == null) {
            if (keyCode == android.view.KeyEvent.KEYCODE_VOLUME_DOWN) {
                cur.web.pageDown(false);
                return true;
            }
            if (keyCode == android.view.KeyEvent.KEYCODE_VOLUME_UP) {
                cur.web.pageUp(false);
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (Build.VERSION.SDK_INT >= 26 && store.flag("pip", true) && customView != null) {
            try {
                enterPictureInPictureMode(new android.app.PictureInPictureParams.Builder()
                        .setAspectRatio(new android.util.Rational(16, 9)).build());
            } catch (Exception ignored) {
            }
        }
    }

    /** UC style: offer to open a link that was just copied. */
    private String lastClip = "";

    private void checkClipboard() {
        if (!store.flag("clip_suggest", true) || welcome != null) return;
        ui.postDelayed(() -> {
            try {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm == null || !cm.hasPrimaryClip() || cm.getPrimaryClip().getItemCount() == 0) return;
                CharSequence cs = cm.getPrimaryClip().getItemAt(0).getText();
                if (cs == null) return;
                final String u = cs.toString().trim();
                if (u.equals(lastClip) || u.equals(store.str("lastclip", ""))) return;
                lastClip = u;
                store.setStr("lastclip", u);
                if (!u.matches("https?://\\S+") || (cur != null && u.equals(cur.url))) return;
                snack(tr("Copied link") + ": " + host(u), tr("OPEN"), () -> {
                    Tab nt = newTab();
                    loadIn(nt, u);
                });
            } catch (Exception ignored) {
            }
        }, 600);
    }

    private void applyAllWebPrefs() {
        for (Tab t : tabs) applyWebPrefs(t.web);
    }

    private boolean isAdHost(String h) {
        if (h == null) return false;
        for (String a : AD_HOSTS) if (h.equals(a) || h.endsWith("." + a)) return true;
        return false;
    }

    private boolean isAdUrl(String url) {
        if (url == null) return false;
        String lu = url.toLowerCase();
        if (store.flag("ad_accept", true) && (lu.contains("carbonads") || lu.contains("ethicalads") || lu.contains("buysellads"))) return false;
        try {
            String h = Uri.parse(url).getHost();
            if (isAdHost(h)) return true;
        } catch (Exception ignored) {
        }
        String u = url.toLowerCase();
        for (String p : AD_URL_PARTS) if (u.contains(p)) return true;
        return false;
    }

    private String baseDomain(String h) {
        if (h == null) return "";
        String[] p = h.split("\\.");
        if (p.length <= 2) return h;
        String last2 = p[p.length - 2] + "." + p[p.length - 1];
        if (p[p.length - 2].length() <= 3 && p[p.length - 1].length() == 2 && p.length >= 3)
            return p[p.length - 3] + "." + last2;
        return last2;
    }

    private boolean isVideoPage(String url) {
        if (url == null) return false;
        String u = url.toLowerCase();
        return u.contains("youtube.com/watch") || u.contains("youtu.be/") || u.contains("vimeo.com/")
                || u.contains("dailymotion.com/video") || u.contains(".mp4") || u.contains(".m3u8")
                || u.contains(".webm") || u.contains("/reel") || u.contains("/shorts/");
    }

    private WebView makeWeb(final Tab t) {
        final WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        applyWebPrefs(w);
        w.setBackgroundColor(Color.WHITE);

        w.setDownloadListener((url, ua, cd, mime, len) -> startDownload(url, ua, cd, mime, len));
        w.addJavascriptInterface(new Bridge(t), "SRBridge");
        w.setOnScrollChangeListener((v, x, y, ox, oy) -> {
            if (t != cur || !store.flag("autohide", false) || fullscreen) return;
            int dy = y - oy;
            if (dy > dp(10) && y > dp(120)) showBars(false);
            else if (dy < -dp(10) || y < dp(40)) showBars(true);
        });

        w.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (store.adblock() && !r.isForMainFrame() && isAdUrl(u)) {
                    adBlocked++;
                    return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
                }
                if (!r.isForMainFrame() && isMediaUrl(u) && t.media.size() < 60) {
                    boolean added = t.media.add(u);
                    if (added && t.media.size() == 1) ui.post(() -> {
                        if (t == cur) updateVideoFab();
                    });
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String sc = r.getUrl().getScheme();
                if (sc == null) return false;
                if (store.adblock() && r.isForMainFrame() && (sc.equals("http") || sc.equals("https"))) {
                    if (isAdUrl(r.getUrl().toString())) {
                        if (store.flag("ad_toast", true)) toast(tr("Ad redirect blocked"));
                        return true;
                    }
                    boolean auto = !r.hasGesture() && !r.isRedirect()
                            && System.currentTimeMillis() - lastTouch > 1500
                            && !t.home && t.url != null && t.url.startsWith("http");
                    if (auto && !baseDomain(host(t.url)).equals(baseDomain(r.getUrl().getHost()))) {
                        if (store.flag("ad_toast", true)) toast(tr("Ad redirect blocked"));
                        return true;
                    }
                }
                if (sc.equals("http") || sc.equals("https") || sc.equals("about")
                        || sc.equals("data") || sc.equals("blob") || sc.equals("javascript")) {
                    return false;
                }
                if (sc.equals("file")) return true;
                if (store.adblock() && !r.hasGesture() && System.currentTimeMillis() - lastTouch > 1500) return true;
                try {
                    Intent in;
                    if (sc.equals("intent")) in = Intent.parseUri(r.getUrl().toString(), Intent.URI_INTENT_SCHEME);
                    else in = new Intent(Intent.ACTION_VIEW, r.getUrl());
                    in.addCategory(Intent.CATEGORY_BROWSABLE);
                    in.setComponent(null);
                    in.setSelector(null);
                    startActivity(in);
                } catch (Exception e) {
                    toast("No app found to open this link");
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap fav) {
                if (t.url == null || !sameDoc(t.url, url)) t.media.clear();
                t.url = url;
                applyNightPage(v);
                alertCount = 0;
                if (store.adblock()) v.evaluateJavascript(ADBLOCK_JS, null);
                if (t == cur) {
                    updateVideoFab();
                    updateUrlBar();
                }
            }

            @Override
            public void onPageFinished(final WebView v, String url) {
                t.url = url;
                if (store.adblock()) {
                    v.evaluateJavascript(ADBLOCK_JS, null);
                    ui.postDelayed(() -> v.evaluateJavascript(ADBLOCK_JS, null), 1500);
                }
                String title = v.getTitle();
                t.title = title == null || title.isEmpty() ? host(url) : title;
                if (t == cur) updateUrlBar();
                if (!store.incognito() && url != null && url.startsWith("http")) {
                    store.add("hist", t.title, url, 500, true);
                    if (isVideoPage(url)) store.add("vhist", t.title, url, 200, true);
                }
                injectVideoJs(t);
                applyNightPage(v);
                checkLogin(t, url);
                if (store.flag("force_zoom", false)) v.evaluateJavascript(ZOOM_JS, null);
                if (store.flag("link_visited", false)) v.evaluateJavascript(VISITED_JS, null);
                if (store.adblock() && store.flag("ad_power", false)) v.evaluateJavascript(STICKY_JS, null);
                int pre = store.num("preload", 1);
                String h = Uri.parse(url).getHost();
                boolean wap = h != null && (h.startsWith("m.") || h.startsWith("wap.") || h.startsWith("mobile."));
                if (pre == 2 || (pre == 1 && wap)) v.evaluateJavascript(PRELOAD_JS, null);
                if (t == cur) {
                    updateNav();
                    updateVideoFab();
                }
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) {
                    String u = r.getUrl().toString();
                    String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                            + "<body style='font-family:sans-serif;text-align:center;padding:56px 18px;color:#555'>"
                            + "<h2>Couldn't load this page</h2><p>" + TextUtils.htmlEncode(String.valueOf(e.getDescription()))
                            + "</p><p><a href='" + TextUtils.htmlEncode(u) + "'>Try again</a></p></body></html>";
                    v.loadDataWithBaseURL(u, html, "text/html", "utf-8", u);
                }
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (p >= 50) injectVideoJs(t);
                if (t != cur) return;
                loading = p < 100;
                progress.setProgress(p);
                progress.setVisibility(loading ? View.VISIBLE : View.INVISIBLE);
                btnRefresh.setImageResource(loading ? R.drawable.ic_close : R.drawable.ic_refresh);
            }

            @Override
            public void onReceivedTitle(WebView v, String title) {
                if (title != null && !title.isEmpty()) t.title = title;
                if (t == cur) updateUrlBar();
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean dialog, boolean gesture, Message msg) {
                if (store.popupBlock() && !gesture) return false;
                final WebView tmp = new WebView(MainActivity.this);
                tmp.setWebViewClient(new WebViewClient() {
                    boolean done;

                    boolean handle(final String url) {
                        if (url == null || url.equals("about:blank") || done) return true;
                        done = true;
                        ui.post(() -> {
                            tmp.destroy();
                            if (store.adblock() && isAdUrl(url)) {
                                if (store.flag("ad_toast", true)) toast(tr("Popup ad blocked"));
                            } else {
                                Tab nt = newTab();
                                loadIn(nt, url);
                            }
                        });
                        return true;
                    }

                    @Override
                    public boolean shouldOverrideUrlLoading(WebView w2, WebResourceRequest r) {
                        return handle(r.getUrl().toString());
                    }

                    @Override
                    public void onPageStarted(WebView w2, String url, Bitmap f) {
                        handle(url);
                    }
                });
                WebView.WebViewTransport tr = (WebView.WebViewTransport) msg.obj;
                tr.setWebView(tmp);
                msg.sendToTarget();
                return true;
            }

            @Override
            public boolean onJsAlert(WebView v, String url, String message, JsResult result) {
                if (store.adblock() && ++alertCount > 2) {
                    result.cancel();
                    return true;
                }
                return false;
            }

            @Override
            public void onShowCustomView(View v, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = v;
                customCb = cb;
                v.setBackgroundColor(Color.BLACK);
                FrameLayout holder = new FrameLayout(MainActivity.this);
                holder.setBackgroundColor(Color.BLACK);
                holder.addView(v, new FrameLayout.LayoutParams(-1, -1));
                if (store.detectVideo() && !blockedVideoHost(t.url) && !searchHost(t.url)) {
                    FrameLayout dlb = new FrameLayout(MainActivity.this);
                    dlb.setBackground(oval(0xCCE5121B));
                    dlb.addView(Ui.icon(MainActivity.this, R.drawable.ic_download, 22, Color.WHITE),
                            new FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER));
                    dlb.setOnClickListener(x -> askVideo(t));
                    FrameLayout.LayoutParams dp1 = new FrameLayout.LayoutParams(dp(46), dp(46), Gravity.END | Gravity.CENTER_VERTICAL);
                    dp1.rightMargin = dp(18);
                    holder.addView(dlb, dp1);
                }
                customHolder = holder;
                screen.addView(holder, new FrameLayout.LayoutParams(-1, -1));
                root.setVisibility(View.GONE);
                applySystemUi();
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(final String origin, final android.webkit.GeolocationPermissions.Callback cb) {
                if (store.num("perm_loc", 0) == 1) {
                    cb.invoke(origin, false, false);
                    return;
                }
                askSite(origin, tr("wants to know your location"), allow -> {
                    if (!allow) {
                        cb.invoke(origin, false, false);
                        return;
                    }
                    withPerms(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                            ok -> cb.invoke(origin, ok, ok));
                });
            }

            @Override
            public void onPermissionRequest(final android.webkit.PermissionRequest req) {
                ui.post(() -> {
                    final List<String> res = new ArrayList<>(), perms = new ArrayList<>();
                    for (String r : req.getResources()) {
                        if (android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) {
                            res.add(r);
                            perms.add(Manifest.permission.CAMERA);
                        } else if (android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) {
                            res.add(r);
                            perms.add(Manifest.permission.RECORD_AUDIO);
                        } else if (android.webkit.PermissionRequest.RESOURCE_PROTECTED_MEDIA_ID.equals(r)) {
                            res.add(r);
                        }
                    }
                    if (res.isEmpty() || store.num("perm_cam", 0) == 1) {
                        req.deny();
                        return;
                    }
                    if (perms.isEmpty()) {
                        req.grant(res.toArray(new String[0]));
                        return;
                    }
                    String what = perms.contains(Manifest.permission.CAMERA) ? tr("wants to use your camera and microphone") : tr("wants to use your microphone");
                    askSite(req.getOrigin().getHost(), what, allow -> {
                        if (!allow) {
                            req.deny();
                            return;
                        }
                        withPerms(perms.toArray(new String[0]), ok -> {
                            if (ok) req.grant(res.toArray(new String[0]));
                            else req.deny();
                        });
                    });
                });
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    toast("No app found to pick files");
                    return false;
                }
                return true;
            }
        });

        w.setOnLongClickListener(v -> {
            WebView.HitTestResult hr = w.getHitTestResult();
            String extra = hr.getExtra();
            int type = hr.getType();
            if (extra == null) return false;
            if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                linkMenu(extra, false);
                return true;
            }
            if (type == WebView.HitTestResult.IMAGE_TYPE) {
                linkMenu(extra, true);
                return true;
            }
            return false;
        });
        return w;
    }

    /* ------------------------------------------------------------------ */
    /* Video detection + Fast Download sheet (UC style)                   */
    /* ------------------------------------------------------------------ */

    /** Overlay button injected over the playing video; tapping it opens the download sheet. */
    private static final String VIDEO_JS = "(function(){try{if(window.__srv)return;window.__srv=1;"
            + "var b=document.createElement('div');"
            + "b.innerHTML='<svg viewBox=\"0 0 24 24\" width=\"22\" height=\"22\" fill=\"none\" stroke=\"#fff\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M12 4v10M7.5 10l4.5 4.5 4.5-4.5M5 19.5h14\"/></svg>';"
            + "b.style.cssText='position:fixed;z-index:2147483647;width:44px;height:44px;border-radius:22px;background:rgba(229,18,27,.92);display:none;align-items:center;justify-content:center;box-shadow:0 2px 10px rgba(0,0,0,.4);border:2px solid rgba(255,255,255,.85);box-sizing:border-box;cursor:pointer';"
            + "var cur=null,seen=0;"
            + "function best(){var vs=document.querySelectorAll('video'),bv=null,ba=0;for(var i=0;i<vs.length;i++){var r=vs[i].getBoundingClientRect(),a=r.width*r.height;"
            + "var d=vs[i].duration;if(vs[i].muted&&vs[i].loop)continue;if(d>0&&d<10)continue;"
            + "if(r.width>140&&r.height>80&&r.bottom>30&&r.top<innerHeight-30&&a>ba){ba=a;bv=vs[i];}}return bv;}"
            + "function place(){try{if(!b.parentNode&&document.body)document.body.appendChild(b);var v=best();cur=v||cur;"
            + "if(!v||document.fullscreenElement||document.webkitFullscreenElement){b.style.display='none';return;}"
            + "if(!seen){seen=1;try{SRBridge.found()}catch(e){}}"
            + "var r=v.getBoundingClientRect();var t=Math.max(8,Math.min(innerHeight-52,r.top+r.height/2-22));"
            + "b.style.left=(Math.min(innerWidth,r.right)-54)+'px';b.style.top=t+'px';b.style.display='flex';}catch(e){}}"
            + "setInterval(place,800);addEventListener('scroll',place,{passive:true});addEventListener('resize',place);"
            + "function add(o,u,l){if(!u||typeof u!='string')return;if(u.indexOf('http')!=0)return;o.srcs.push(l?u+'#srq='+l:u);}"
            + "function info(){var v=cur||best();var o={title:document.title||'',page:location.href,srcs:[],poster:'',dur:0};"
            + "if(v){o.poster=v.poster||'';o.dur=isFinite(v.duration)?v.duration:0;add(o,v.currentSrc);add(o,v.src);"
            + "var ss=v.querySelectorAll('source');for(var i=0;i<ss.length;i++){var s=ss[i];add(o,s.src,s.getAttribute('label')||s.getAttribute('size')||s.getAttribute('res')||s.getAttribute('title')||'');}}"
            + "var t='';var sc=document.querySelectorAll('script:not([src])');for(var i=0;i<sc.length&&t.length<4000000;i++)t+=sc[i].textContent+'\\n';"
            + "t=t.replace(/\\\\\\//g,'/').replace(/\\\\u0026/g,'&').replace(/&amp;/g,'&');"
            + "var m=t.match(/https?:\\/\\/[^\"'\\s<>\\\\]+?\\.(?:mp4|m3u8|webm)(?:\\?[^\"'\\s<>\\\\]*)?/gi)||[];"
            + "for(var i=0;i<m.length&&i<80;i++)add(o,m[i]);"
            + "var og=document.querySelector('meta[property=\"og:video\"],meta[property=\"og:video:url\"],meta[property=\"og:video:secure_url\"]');if(og)add(o,og.content);"
            + "if(!o.poster){var oi=document.querySelector('meta[property=\"og:image\"]');if(oi)o.poster=oi.content;}"
            + "return JSON.stringify(o);}"
            + "window.__srinfo=info;"
            + "b.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();try{SRBridge.video(info())}catch(x){}},true);"
            + "}catch(e){}})();";

    private static final java.util.regex.Pattern Q_PAT = java.util.regex.Pattern.compile(
            "(?<![0-9])(2160|1440|1080|720|540|480|360|240|144)(?:p|P|_|\\.|/|-|$)");

    static final class Quality {
        String label = "", url, audio;
        boolean hls;
        int height;
        long size = -1;
    }

    final class Bridge {
        final Tab t;

        Bridge(Tab t) {
            this.t = t;
        }

        @android.webkit.JavascriptInterface
        public void video(final String json) {
            if (System.currentTimeMillis() - lastTouch > 3000) return; // only after a real tap
            ui.post(() -> {
                if (t == cur) showVideoSheet(t, json);
            });
        }

        @android.webkit.JavascriptInterface
        public void saveData(final String dataUrl, final String name) {
            // only answers a download the user started, never a page on its own
            if (System.currentTimeMillis() - blobAsked > 60000) return;
            blobAsked = 0;
            ui.post(() -> saveDataUrl(dataUrl, name));
        }

        @android.webkit.JavascriptInterface
        public void found() {
            ui.post(() -> {
                if (!store.incognito() && t.url != null && t.url.startsWith("http") && !searchHost(t.url))
                    store.add("vhist", t.title, t.url, 300, true);
                if (t == cur) updateVideoFab();
            });
        }
    }

    private static boolean blockedVideoHost(String url) {
        String h = url == null ? "" : url.toLowerCase(java.util.Locale.US);
        return h.contains("youtube.com") || h.contains("youtu.be") || h.contains("googlevideo.com") || h.contains("ytimg.com");
    }

    /** True for a request that is a video file or a video playlist (not a small piece of one). */
    private static boolean isMediaUrl(String url) {
        if (url == null || !url.startsWith("http") || blockedVideoHost(url)) return false;
        String u = url.toLowerCase(java.util.Locale.US);
        int q = u.indexOf('?');
        String path = q < 0 ? u : u.substring(0, q);
        if (path.endsWith(".ts") || path.endsWith(".m4s") || path.endsWith(".aac") || path.contains("/seg-") || path.contains("segment")) return false;
        if (path.contains(".m3u8")) return true;
        return path.endsWith(".mp4") || path.endsWith(".webm") || path.endsWith(".m4v") || path.endsWith(".mov")
                || path.endsWith(".3gp") || path.endsWith(".flv") || path.endsWith(".mkv")
                || path.contains(".mp4/") || u.contains("mime=video");
    }

    /** Search pages (Google, Bing...) only show small previews, so no download button there. */
    private static boolean searchHost(String url) {
        if (url == null) return false;
        String h = Uri.parse(url).getHost();
        if (h == null) return false;
        h = h.toLowerCase(java.util.Locale.US);
        return h.contains("google.") || h.endsWith("bing.com") || h.contains("search.yahoo") || h.endsWith("duckduckgo.com")
                || h.endsWith("yandex.com") || h.endsWith("yandex.ru");
    }

    private void injectVideoJs(Tab t) {
        if (!store.detectVideo() || t.home || blockedVideoHost(t.url) || searchHost(t.url)) return;
        t.web.evaluateJavascript(VIDEO_JS, null);
    }

    private void updateVideoFab() {
        boolean show = store.detectVideo() && cur != null && !cur.home && !blockedVideoHost(cur.url)
                && !searchHost(cur.url) && !cur.media.isEmpty();
        videoFab.setVisibility(show ? View.VISIBLE : View.GONE);
    }

    /** Asks the page for its video info, then opens the sheet. Used by the floating button and in full screen. */
    private void askVideo(final Tab t) {
        if (t == null || t.home) return;
        if (blockedVideoHost(t.url)) {
            toast(tr("YouTube videos can't be downloaded."));
            return;
        }
        t.web.evaluateJavascript("(function(){try{return window.__srinfo?window.__srinfo():''}catch(e){return ''}})()", v -> {
            String json = "";
            try {
                json = new org.json.JSONArray("[" + v + "]").getString(0);
            } catch (Exception ignored) {
            }
            showVideoSheet(t, json);
        });
    }

    private static String fmtDur(double s) {
        int t = (int) Math.round(s);
        if (t <= 0) return "";
        return t >= 3600 ? String.format(java.util.Locale.US, "%d:%02d:%02d", t / 3600, (t / 60) % 60, t % 60)
                : String.format(java.util.Locale.US, "%02d:%02d", t / 60, t % 60);
    }

    private static String cleanName(String s) {
        if (s == null) s = "";
        s = s.replaceAll("[\\\\/:*?\"<>|\\n\\r\\t]", " ").replaceAll("\\s+", " ").trim();
        if (s.length() > 80) s = s.substring(0, 80).trim();
        return s.isEmpty() ? "video_" + System.currentTimeMillis() / 1000 : s;
    }

    private int qHeight(String url) {
        java.util.regex.Matcher m = Q_PAT.matcher(url);
        int best = 0;
        while (m.find()) best = Math.max(best, Integer.parseInt(m.group(1)));
        return best;
    }

    /** Turns the found links into a list of qualities (runs in the background). */
    private List<Quality> resolveQualities(List<String> srcs, String page) {
        String cookie = CookieManager.getInstance().getCookie(page);
        String ua = cur != null && store.desktop() ? DESKTOP_UA : mobileUa;
        List<Quality> out = new ArrayList<>();
        java.util.Set<String> covered = new java.util.HashSet<>();
        List<String> masters = new ArrayList<>(), medias = new ArrayList<>(), files = new ArrayList<>();
        for (String raw : srcs) {
            String u = raw, lbl = "";
            int h = raw.indexOf("#srq=");
            if (h > 0) {
                u = raw.substring(0, h);
                lbl = raw.substring(h + 5);
            }
            if (isHls(u)) {
                if (!medias.contains(u)) medias.add(u);
            } else if (!files.contains(raw)) files.add(lbl.isEmpty() ? u : raw);
        }
        // Playlists: masters give us every quality
        for (String u : medias) {
            if (covered.contains(u)) continue;
            try {
                String text = Grabber.fetchText(u, ua, cookie, page);
                if (Grabber.isMaster(text)) {
                    masters.add(u);
                    for (Grabber.Variant v : Grabber.variants(u, text)) {
                        covered.add(v.url);
                        Quality q = new Quality();
                        q.url = v.url;
                        q.audio = v.audio;
                        q.hls = true;
                        q.height = v.height > 0 ? v.height : qHeight(v.url);
                        q.label = q.height > 0 ? q.height + "P" : (v.bandwidth > 0 ? (v.bandwidth / 1000) + "K" : "Auto");
                        out.add(q);
                    }
                }
            } catch (Exception ignored) {
            }
        }
        for (String u : medias) {
            if (covered.contains(u) || masters.contains(u)) continue;
            Quality q = new Quality();
            q.url = u;
            q.hls = true;
            q.height = qHeight(u);
            q.label = q.height > 0 ? q.height + "P" : "HD";
            out.add(q);
        }
        int heads = 0;
        for (String raw : files) {
            String u = raw, lbl = "";
            int h = raw.indexOf("#srq=");
            if (h > 0) {
                u = raw.substring(0, h);
                lbl = raw.substring(h + 5);
            }
            Quality q = new Quality();
            q.url = u;
            q.height = qHeight(lbl.isEmpty() ? u : lbl + "_");
            if (q.height == 0) q.height = qHeight(u);
            q.label = q.height > 0 ? q.height + "P" : (lbl.isEmpty() ? "SD" : lbl.toUpperCase(java.util.Locale.US));
            if (heads++ < 8) q.size = Grabber.size(u, ua, cookie, page);
            if (q.size >= 0 && q.size < 300 * 1024) continue; // tiny preview clips, not the real video
            out.add(q);
        }
        // One choice per label: a direct file beats a stream (faster); bigger file wins
        java.util.LinkedHashMap<String, Quality> pick = new java.util.LinkedHashMap<>();
        for (Quality q : out) {
            Quality o = pick.get(q.label);
            if (o == null || (o.hls && !q.hls) || (o.hls == q.hls && q.size > o.size)) pick.put(q.label, q);
        }
        List<Quality> res = new ArrayList<>(pick.values());
        java.util.Collections.sort(res, (a, b) -> {
            if (a.height != b.height) return b.height - a.height;
            return Long.compare(b.size, a.size);
        });
        return res;
    }

    private void showVideoSheet(final Tab t, String json) {
        String title = t.title, poster = "", page = t.url;
        double dur = 0;
        final List<String> srcs = new ArrayList<>();
        try {
            org.json.JSONObject o = new org.json.JSONObject(json);
            if (!o.optString("title").isEmpty()) title = o.optString("title");
            poster = o.optString("poster");
            dur = o.optDouble("dur", 0);
            if (!o.optString("page").isEmpty()) page = o.optString("page");
            org.json.JSONArray a = o.optJSONArray("srcs");
            if (a != null) for (int i = 0; i < a.length(); i++) {
                String u = a.optString(i);
                if (u.startsWith("http") && !blockedVideoHost(u) && !srcs.contains(u)) srcs.add(u);
            }
        } catch (Exception ignored) {
        }
        synchronized (t.media) {
            for (String u : t.media) if (!srcs.contains(u)) srcs.add(u);
        }
        final String pageUrl = page;

        LinearLayout c = ucCard(true);
        c.setPadding(dp(20), dp(14), dp(20), dp(20));
        FrameLayout head = new FrameLayout(this);
        TextView ht = Ui.text(this, tr("Fast Download"), 21, pal.fg, true);
        ht.setGravity(Gravity.CENTER);
        ht.setPadding(0, dp(10), 0, dp(14));
        head.addView(ht, new FrameLayout.LayoutParams(-1, -2));
        ImageView x = Ui.icon(this, R.drawable.ic_close, 22, pal.muted);
        x.setPadding(dp(4), dp(4), dp(4), dp(4));
        head.addView(x, new FrameLayout.LayoutParams(dp(32), dp(32), Gravity.TOP | Gravity.END));
        c.addView(head);

        // Thumbnail + editable name + duration
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        FrameLayout thumbBox = new FrameLayout(this);
        thumbBox.setBackground(Ui.round(this, pal.surface2, 10));
        thumbBox.setClipToOutline(true);
        final ImageView thumb = new ImageView(this);
        thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
        thumbBox.addView(thumb, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout play = new FrameLayout(this);
        play.setBackground(oval(0xAA1C2024));
        play.addView(Ui.icon(this, R.drawable.ic_video, 16, Color.WHITE), new FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER));
        thumbBox.addView(play, new FrameLayout.LayoutParams(dp(32), dp(32), Gravity.CENTER));
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(112), dp(70));
        tp.rightMargin = dp(12);
        row.addView(thumbBox, tp);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        final EditText name = new EditText(this);
        name.setText(cleanName(title));
        name.setTextColor(pal.fg);
        name.setTextSize(15);
        name.setMaxLines(2);
        name.setBackground(null);
        name.setPadding(0, 0, 0, dp(2));
        name.setCompoundDrawablePadding(dp(4));
        col.addView(name, new LinearLayout.LayoutParams(-1, -2));
        final TextView meta = Ui.text(this, fmtDur(dur), 13, pal.muted, false);
        col.addView(meta);
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        c.addView(row, new LinearLayout.LayoutParams(-1, -2));

        // Quality chips
        final LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.topMargin = dp(16);
        cp.bottomMargin = dp(6);
        c.addView(chips, cp);
        final ProgressBar spin = new ProgressBar(this);
        spin.setIndeterminateTintList(ColorStateList.valueOf(pal.accent));
        chips.addView(spin, new LinearLayout.LayoutParams(dp(28), dp(28)));
        TextView finding = Ui.text(this, tr("Finding video quality..."), 13, pal.muted, false);
        chips.addView(finding);

        final TextView dlBtn = Ui.text(this, tr("Download to device"), 17, Color.WHITE, true);
        dlBtn.setGravity(Gravity.CENTER);
        dlBtn.setBackground(Ui.round(this, 0xFF1C2024, 16));
        dlBtn.setAlpha(0.4f);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(54));
        bp.topMargin = dp(14);
        c.addView(dlBtn, bp);
        final TextView playBtn = Ui.text(this, tr("Play online"), 16, pal.fg, true);
        playBtn.setGravity(Gravity.CENTER);
        playBtn.setBackground(Ui.round(this, pal.surface2, 16));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(50));
        pp.topMargin = dp(10);
        c.addView(playBtn, pp);

        final Dialog d = ucShow(c, true);
        x.setOnClickListener(v -> d.dismiss());
        playBtn.setOnClickListener(v -> d.dismiss());

        final String posterUrl = poster;
        final String ua = store.desktop() ? DESKTOP_UA : mobileUa;
        final String cookie = CookieManager.getInstance().getCookie(pageUrl);
        if (posterUrl != null && posterUrl.startsWith("http")) {
            bg.execute(() -> {
                try {
                    byte[] b = Grabber.fetch(posterUrl, ua, cookie, pageUrl, 3 * 1024 * 1024);
                    BitmapFactory.Options op = new BitmapFactory.Options();
                    op.inSampleSize = 2;
                    final Bitmap bm = BitmapFactory.decodeByteArray(b, 0, b.length, op);
                    if (bm != null) ui.post(() -> thumb.setImageBitmap(bm));
                } catch (Exception ignored) {
                }
            });
        } else {
            Bitmap tb = t.thumb;
            if (tb == null) {
                captureThumb(t);
                tb = t.thumb;
            }
            if (tb != null) thumb.setImageBitmap(tb);
        }

        final Quality[] sel = new Quality[1];
        bg.execute(() -> {
            final List<Quality> qs = resolveQualities(srcs, pageUrl);
            ui.post(() -> {
                if (!d.isShowing()) return;
                chips.removeAllViews();
                if (qs.isEmpty()) {
                    TextView n = Ui.text(this, tr("No downloadable video found yet. Play the video for a few seconds, then tap download again."), 14, pal.muted, false);
                    n.setGravity(Gravity.CENTER);
                    chips.addView(n);
                    return;
                }
                int def = 0;
                int want = store.num("vq", 0); // 0 highest, 1 = 720, 2 = 480, 3 = lowest
                if (want == 3) def = qs.size() - 1;
                else if (want > 0) {
                    int target = want == 1 ? 720 : 480;
                    for (int i = 0; i < qs.size(); i++) if (qs.get(i).height <= target) {
                        def = i;
                        break;
                    }
                }
                final List<TextView> views = new ArrayList<>();
                LinearLayout line = null;
                for (int i = 0; i < qs.size(); i++) {
                    if (i % 4 == 0) {
                        line = new LinearLayout(this);
                        line.setOrientation(LinearLayout.HORIZONTAL);
                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                        lp.bottomMargin = dp(8);
                        chips.addView(line, lp);
                    }
                    final Quality q = qs.get(i);
                    TextView ch = Ui.text(this, q.label, 15, pal.fg, false);
                    ch.setGravity(Gravity.CENTER);
                    ch.setPadding(0, dp(10), 0, dp(10));
                    views.add(ch);
                    ch.setOnClickListener(v -> {
                        sel[0] = q;
                        for (int k = 0; k < views.size(); k++) paintChip(views.get(k), qs.get(k) == q);
                        meta.setText(metaLine(fmtDurText(meta), q));
                    });
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1);
                    lp.rightMargin = dp(8);
                    line.addView(ch, lp);
                }
                for (int k = qs.size(); k % 4 != 0; k++) line.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
                sel[0] = qs.get(def);
                meta.setTag(meta.getText().toString());
                for (int k = 0; k < views.size(); k++) paintChip(views.get(k), k == def);
                meta.setText(metaLine(fmtDurText(meta), sel[0]));
                dlBtn.setAlpha(1f);
            });
        });

        dlBtn.setOnClickListener(v -> {
            Quality q = sel[0];
            if (q == null) return;
            String n = cleanName(name.getText().toString());
            d.dismiss();
            if (!store.incognito()) store.add("vhist", t.title, pageUrl, 300, true);
            if (q.hls) startStream(q.url, q.audio, n, pageUrl);
            else {
                String e = ext(Uri.parse(q.url).getLastPathSegment() == null ? "" : Uri.parse(q.url).getLastPathSegment());
                if (e.isEmpty() || e.length() > 4 || dlCatOf("x." + e) != 1) e = "mp4";
                enqueue(q.url, ua, "video/" + (e.equals("webm") ? "webm" : "mp4"), n + "." + e);
            }
        });
    }

    private String fmtDurText(TextView meta) {
        Object t = meta.getTag();
        return t == null ? "" : t.toString();
    }

    private String metaLine(String dur, Quality q) {
        String s = dur;
        if (q.size > 0) s += (s.isEmpty() ? "" : "   ·   ") + fmtSize(q.size);
        return s;
    }

    private void paintChip(TextView ch, boolean on) {
        ch.setTextColor(on ? pal.accent : pal.fg);
        ch.setTypeface(Typeface.DEFAULT, on ? Typeface.BOLD : Typeface.NORMAL);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(10));
        g.setColor(on ? (pal.night ? 0xFF3A1518 : 0xFFFFEFF0) : pal.surface2);
        if (on) g.setStroke(dp(1.5f), pal.accent);
        ch.setBackground(g);
    }

    /** Streaming (m3u8) video: downloaded by the app itself and saved as MP4. */
    private void startStream(String url, String audio, String name, String page) {
        if (store.wifiOnly() && isMetered()) {
            toast(tr("Wi-Fi only is on. Connect to Wi-Fi or turn it off in Download Settings."));
            return;
        }
        if (page == null) page = cur != null && !cur.home ? cur.url : "";
        String cookie = CookieManager.getInstance().getCookie(page.isEmpty() ? url : page);
        String ua = store.desktop() ? DESKTOP_UA : mobileUa;
        if (!name.toLowerCase(java.util.Locale.US).endsWith(".mp4")) name = name + ".mp4";
        Grabber.Task g = Grabber.start(getApplicationContext(), url, audio, name, ua, cookie, page,
                maxDownloads(), store.dlNotify());
        store.add("dl", name, g.id + "|" + url + "|" + (audio == null ? "" : audio), 300, true);
        dlTab = 0;
        snack(tr("Download started") + ": " + name, tr("VIEW"), () -> {
            if (!dlPanelOnTop()) openDownloader();
        });
        if (dlPanelOnTop()) refreshPanel();
    }

    private boolean isMetered() {
        try {
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            return cm != null && cm.isActiveNetworkMetered();
        } catch (Exception e) {
            return false;
        }
    }

    private void hideCustom() {
        if (customView == null) return;
        if (customHolder != null) {
            customHolder.removeAllViews();
            screen.removeView(customHolder);
            customHolder = null;
        } else screen.removeView(customView);
        customView = null;
        root.setVisibility(View.VISIBLE);
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        applySystemUi();
    }

    /** UC style long-press menu for links and images. */
    private void linkMenu(final String url, final boolean image) {
        LinearLayout c = ucCard(true);
        TextView u = Ui.oneLine(Ui.text(this, url, 13, pal.muted, false));
        u.setPadding(dp(6), 0, dp(6), dp(8));
        c.addView(u);
        final Dialog d = ucShow(c, true);
        boolean bgFirst = store.flag("open_bg", false);
        c.addView(sheetRow(R.drawable.ic_plus, image ? "Open image in new tab" : "Open in new tab", () -> {
            d.dismiss();
            openLinkTab(url, bgFirst);
        }));
        c.addView(sheetRow(R.drawable.ic_tabs, bgFirst ? "Open and switch to tab" : "Open in background", () -> {
            d.dismiss();
            openLinkTab(url, !bgFirst);
        }));
        c.addView(sheetRow(R.drawable.ic_download, image ? "Download image" : "Download link", () -> {
            d.dismiss();
            startDownload(url, mobileUa, null, null, -1);
        }));
        c.addView(sheetRow(R.drawable.ic_notes, "Copy link", () -> {
            d.dismiss();
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("link", url));
            lastClip = url;
            store.setStr("lastclip", url);
            toast(tr("Link copied"));
        }));
        c.addView(sheetRow(R.drawable.ic_share, "Share", () -> {
            d.dismiss();
            Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, url);
            startActivity(Intent.createChooser(i, tr("Share")));
        }));
        if (!image) c.addView(sheetRow(R.drawable.ic_star, "Add to Bookmarks", () -> {
            d.dismiss();
            store.add("bm", host(url), url, 500, false);
            refreshHome();
            toast(tr("Added to bookmarks"));
        }));
    }

    private void openLinkTab(String url, boolean background) {
        if (!background) {
            Tab nt = newTab();
            loadIn(nt, url);
            return;
        }
        Tab prev = cur;
        Tab nt = newTab();
        loadIn(nt, url);
        switchTo(prev);
        toast(tr("Opened in background"));
    }

    private void startDownload(final String url, final String ua, final String cd, final String mime, final long len) {
        if (url != null && url.startsWith("data:")) {
            saveDataUrl(url, URLUtil.guessFileName(url, cd, mime));
            return;
        }
        if (url != null && url.startsWith("blob:") && cur != null && !cur.home) {
            String nm = URLUtil.guessFileName(url, cd, mime);
            if (nm == null || nm.endsWith(".bin")) nm = "file_" + System.currentTimeMillis() + extFromMime(mime);
            String js = "(function(){try{var x=new XMLHttpRequest();x.open('GET'," + org.json.JSONObject.quote(url) + ",true);x.responseType='blob';"
                    + "x.onload=function(){var r=new FileReader();r.onloadend=function(){SRBridge.saveData(r.result," + org.json.JSONObject.quote(nm) + ")};r.readAsDataURL(x.response)};"
                    + "x.onerror=function(){SRBridge.saveData('',''+" + org.json.JSONObject.quote(nm) + ")};x.send();}catch(e){SRBridge.saveData('','')}})()";
            blobAsked = System.currentTimeMillis();
            cur.web.evaluateJavascript(js, null);
            toast(tr("Saving file..."));
            return;
        }
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
            toast(tr("This file can't be downloaded directly. Try the site's own download button."));
            return;
        }
        String guess = URLUtil.guessFileName(url, cd, mime);
        if (guess == null || guess.trim().isEmpty()) guess = "download";
        final String name = guess;
        if (!store.askDownload()) {
            enqueue(url, ua, mime, name);
            return;
        }
        // UC style download sheet: file icon, editable name, size, location
        LinearLayout c = ucCard(true);
        c.addView(ucTitle("Download"));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        final FrameLayout badgeBox = new FrameLayout(this);
        badgeBox.addView(fileBadge(name, 52));
        LinearLayout.LayoutParams bbp = new LinearLayout.LayoutParams(dp(52), dp(52));
        bbp.rightMargin = dp(14);
        row.addView(badgeBox, bbp);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        final EditText e = new EditText(this);
        e.setText(name);
        e.setSingleLine(true);
        e.setTextSize(16);
        e.setTextColor(pal.fg);
        e.setBackground(null);
        e.setPadding(0, dp(4), 0, dp(4));
        e.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int st, int co, int af) {
            }

            @Override
            public void onTextChanged(CharSequence s, int st, int be, int co) {
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {
                badgeBox.removeAllViews();
                badgeBox.addView(fileBadge(s.toString(), 52));
            }
        });
        col.addView(e, new LinearLayout.LayoutParams(-1, -2));
        View ul = new View(this);
        ul.setBackgroundColor(pal.line);
        col.addView(ul, new LinearLayout.LayoutParams(-1, dp(1)));
        String meta = (len > 0 ? tr("Size") + ": " + fmtSize(len) + "   ·   " : "") + tr("Save to") + ": Download";
        TextView mt = Ui.text(this, meta, 12.5f, pal.muted, false);
        mt.setPadding(0, dp(6), 0, 0);
        col.addView(mt);
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        c.addView(row, new LinearLayout.LayoutParams(-1, -2));
        final CheckBox wifi = ucCheck("Download on Wi-Fi only", store.wifiOnly());
        c.addView(wifi);
        final Dialog d = ucShow(c, true);
        c.addView(ucBtn("Download", true, v -> {
            String n = e.getText().toString().trim();
            if (n.isEmpty()) n = name;
            store.setWifiOnly(wifi.isChecked());
            d.dismiss();
            enqueue(url, ua, mime, n);
        }));
        c.addView(ucBtn("Cancel", false, v -> d.dismiss()));
    }

    private static String extFromMime(String mime) {
        if (mime == null) return "";
        String e = android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(mime.split(";")[0].trim());
        return e == null ? "" : "." + e;
    }

    /** Saves a data: link (or a blob turned into one) straight into Downloads. */
    private void saveDataUrl(final String dataUrl, String name) {
        if (dataUrl == null || !dataUrl.startsWith("data:")) {
            toast(tr("Download failed"));
            return;
        }
        int comma = dataUrl.indexOf(',');
        if (comma < 0) {
            toast(tr("Download failed"));
            return;
        }
        final String head = dataUrl.substring(5, comma);
        final String mime = head.split(";")[0];
        String n = name == null || name.isEmpty() || name.endsWith(".bin") ? "file_" + System.currentTimeMillis() + extFromMime(mime) : name;
        final String fname = n.replaceAll("[\\\\/:*?\"<>|\\n\\r]", "_");
        bg.execute(() -> {
            try {
                String body = dataUrl.substring(comma + 1);
                byte[] data = head.contains("base64") ? android.util.Base64.decode(body, android.util.Base64.DEFAULT)
                        : Uri.decode(body).getBytes("UTF-8");
                final long id = Grabber.saveBytes(getApplicationContext(), data, fname, mime);
                ui.post(() -> {
                    store.add("dl", fname, id + "|", 300, true);
                    dlFinished(id, fname, true);
                });
            } catch (Throwable e) {
                ui.post(() -> toast(tr("Download failed")));
            }
        });
    }

    private void enqueue(String url, String ua, String mime, String name) {
        try {
            name = name.replaceAll("[\\\\/:*?\"<>|\\n\\r]", "_").trim();
            if (name.isEmpty()) name = "download";
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (mime != null && !mime.isEmpty()) r.setMimeType(mime);
            r.addRequestHeader("User-Agent", ua != null ? ua : mobileUa);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) r.addRequestHeader("Cookie", cookie);
            if (cur != null && cur.url != null && cur.url.startsWith("http")) r.addRequestHeader("Referer", cur.url);
            r.setTitle(name);
            r.setDescription("S.R Browser");
            r.setNotificationVisibility(store.dlNotify()
                    ? DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                    : DownloadManager.Request.VISIBILITY_VISIBLE);
            r.setAllowedOverMetered(!store.wifiOnly());
            r.setAllowedOverRoaming(!store.wifiOnly());
            String sub = dlSubDir();
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, sub.isEmpty() ? name : sub + "/" + name);
            if (dlCatOf(name) == 2 || dlCatOf(name) == 1 || dlCatOf(name) == 3) {
                try {
                    r.allowScanningByMediaScanner();
                } catch (Exception ignored) {
                }
            }
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            long id = dm.enqueue(r);
            store.add("dl", name, id + "|" + url, 300, true);
            dlTab = 0;
            snack(tr("Download started") + ": " + name, tr("VIEW"), () -> {
                if (!dlPanelOnTop()) openDownloader();
            });
            if (dlPanelOnTop()) refreshPanel();
        } catch (Exception e) {
            toast(tr("Download failed"));
        }
    }

    /* ------------------------------------------------------------------ */
    /* Address bar                                                        */
    /* ------------------------------------------------------------------ */

    private void hideKb(View v) {
        InputMethodManager m = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (m != null) m.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    private void submitFrom(EditText e) {
        String q = e.getText().toString().trim();
        if (q.isEmpty()) return;
        hideKb(e);
        e.clearFocus();
        loadIn(cur, toUrl(q));
        if (e == homeEdit) e.setText("");
    }

    private String toUrl(String q) {
        if (q.startsWith("http://") || q.startsWith("https://")) return q;
        if (!q.contains(" ") && q.contains(".") && Patterns.WEB_URL.matcher(q).matches()) return "https://" + q;
        return searchUrl(q);
    }

    private String searchUrl(String q) {
        String e = store.engine();
        String en = Uri.encode(q);
        switch (e) {
            case "bing":
                if (mode == 1) return "https://www.bing.com/videos/search?q=" + en;
                if (mode == 2) return "https://www.bing.com/images/search?q=" + en;
                return "https://www.bing.com/search?q=" + en;
            case "ddg":
                if (mode == 1) return "https://duckduckgo.com/?q=" + en + "&iax=videos&ia=videos";
                if (mode == 2) return "https://duckduckgo.com/?q=" + en + "&iax=images&ia=images";
                return "https://duckduckgo.com/?q=" + en;
            case "yahoo":
                return "https://search.yahoo.com/search?p=" + en;
            default:
                if (mode == 1) return "https://www.google.com/search?q=" + en + "&tbm=vid";
                if (mode == 2) return "https://www.google.com/search?q=" + en + "&tbm=isch";
                return "https://www.google.com/search?q=" + en;
        }
    }

    private String host(String url) {
        try {
            String h = Uri.parse(url).getHost();
            return h == null ? url : h.replaceFirst("^www\\.", "");
        } catch (Exception e) {
            return url;
        }
    }

    private void pickEngine() {
        LinearLayout c = ucCard(false);
        c.addView(ucTitle("Search engine"));
        final Dialog d = ucShow(c, false);
        for (int i = 0; i < ENGINES.length; i++) {
            final int idx = i;
            boolean on = ENGINES[i][0].equals(store.engine());
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(8), dp(14), dp(8));
            row.setBackground(on ? Ui.round(this, pal.surface2, 16) : null);
            View badge = engineBadgeAt(i, 34);
            row.addView(badge);
            TextView n = Ui.text(this, ENGINES[i][1], 18, pal.fg, on);
            n.setPadding(dp(16), 0, 0, 0);
            row.addView(n, new LinearLayout.LayoutParams(0, -2, 1));
            if (on) row.addView(Ui.icon(this, R.drawable.ic_check, 22, 0xFF2F8CFF));
            row.setOnClickListener(v -> {
                store.setEngine(ENGINES[idx][0]);
                d.dismiss();
                refreshHome();
                refreshPanel();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(58));
            lp.bottomMargin = dp(4);
            c.addView(row, lp);
        }
        c.addView(ucBtn("Cancel", false, v -> d.dismiss()));
    }

    /* ------------------------------------------------------------------ */
    /* Menu sheet (UC style)                                              */
    /* ------------------------------------------------------------------ */

    private void buildSheet() {
        scrim = new View(this);
        scrim.setBackgroundColor(0x99000000);
        scrim.setVisibility(View.GONE);
        scrim.setOnClickListener(v -> closeMenu());
        screen.addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        sheetBox = new LinearLayout(this);
        sheetBox.setOrientation(LinearLayout.VERTICAL);
        sheetBox.setBackground(Ui.round(this, pal.sheet, 24));
        sheetBox.setElevation(dp(10));
        sheetBox.setVisibility(View.GONE);
        sheetBox.setClickable(true);
        sheetBox.setPadding(dp(16), dp(18), dp(16), dp(2));
        FrameLayout.LayoutParams sbp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        sbp.setMargins(dp(10), 0, dp(10), dp(10));
        screen.addView(sheetBox, sbp);
    }

    private void openMenu() {
        if (sheetBox.getVisibility() == View.VISIBLE) {
            closeMenu();
            return;
        }
        fillMenu();
        scrim.setVisibility(View.VISIBLE);
        sheetBox.setVisibility(View.VISIBLE);
        setMenuIcon(true);
        if (store.flag("anim", true)) {
            scrim.setAlpha(0f);
            scrim.animate().alpha(1f).setDuration(180).start();
            sheetBox.setTranslationY(dp(300));
            sheetBox.animate().translationY(0).setDuration(240).setInterpolator(new android.view.animation.DecelerateInterpolator(1.8f)).start();
        }
    }

    private void closeMenu() {
        if (sheetBox.getVisibility() != View.VISIBLE) return;
        setMenuIcon(false);
        if (store.flag("anim", true)) {
            scrim.animate().alpha(0f).setDuration(160).withEndAction(() -> scrim.setVisibility(View.GONE)).start();
            sheetBox.animate().translationY(sheetBox.getHeight() + dp(20)).setDuration(180)
                    .withEndAction(() -> sheetBox.setVisibility(View.GONE)).start();
        } else {
            scrim.setVisibility(View.GONE);
            sheetBox.setVisibility(View.GONE);
        }
    }

    /** UC style: the menu button turns into an X while the menu is open. */
    private void setMenuIcon(boolean open) {
        if (btnMenuV instanceof ViewGroup && ((ViewGroup) btnMenuV).getChildCount() > 0
                && ((ViewGroup) btnMenuV).getChildAt(0) instanceof ImageView) {
            ImageView iv = (ImageView) ((ViewGroup) btnMenuV).getChildAt(0);
            iv.setImageResource(open ? R.drawable.ic_close : R.drawable.ic_menu);
            iv.setRotation(open ? -90 : 90);
            iv.animate().rotation(0).setDuration(200).start();
        }
    }

    private void fillMenu() {
        sheetBox.removeAllViews();

        // Header: User Center (sign in), incognito pill - like UC
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        View av = avatarView(50);
        ((LinearLayout.LayoutParams) av.getLayoutParams()).rightMargin = dp(12);
        head.addView(av);
        LinearLayout hc = new LinearLayout(this);
        hc.setOrientation(LinearLayout.VERTICAL);
        boolean signed = !store.str("acct", "").isEmpty();
        hc.addView(Ui.oneLine(Ui.text(this, signed ? accountName() : tr("User Center"), 18, pal.fg, true)));
        TextView hs = Ui.text(this, signed ? tr("Signed in") : tr("Sign in with Google or Facebook"), 12.5f, pal.muted, false);
        hs.setPadding(0, dp(2), 0, 0);
        hc.addView(Ui.oneLine(hs));
        head.addView(hc, new LinearLayout.LayoutParams(0, -2, 1));
        hc.setOnClickListener(v -> {
            closeMenu();
            showSignIn();
        });
        av.setOnClickListener(v -> {
            closeMenu();
            showSignIn();
        });

        boolean inc = store.incognito();
        FrameLayout ghost = new FrameLayout(this);
        ghost.setBackground(Ui.round(this, inc ? PURPLE : (pal.night ? pal.surface2 : 0xFFFFFFFF), 24));
        ghost.addView(Ui.icon(this, R.drawable.ic_ghost, 26, inc ? 0xFFFFFFFF : pal.fg),
                new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        ghost.setOnClickListener(v -> {
            store.setIncognito(!store.incognito());
            updateTabBtn();
            toast(store.incognito() ? "Incognito on" : "Incognito off");
            fillMenu();
        });
        head.addView(ghost, new LinearLayout.LayoutParams(dp(92), dp(46)));
        sheetBox.addView(head, new LinearLayout.LayoutParams(-1, -2));

        // Row 1: colour circles
        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.addView(menuItem(R.drawable.ic_bookmark_o, "Bookmarks", 0xFF19C9A6, false, false, this::openBookmarks), new LinearLayout.LayoutParams(0, -2, 1));
        r1.addView(menuItem(R.drawable.ic_clock, "History", 0xFFFFB400, false, false, this::openHistory), new LinearLayout.LayoutParams(0, -2, 1));
        r1.addView(menuItem(R.drawable.ic_download, "Downloads", 0xFF3B82F6, false, false, this::openDownloader), new LinearLayout.LayoutParams(0, -2, 1));
        r1.addView(menuItem(R.drawable.ic_tshirt, "Themes", 0xFFF0508A, false, false, this::openThemes), new LinearLayout.LayoutParams(0, -2, 1));
        r1.addView(menuItem(R.drawable.ic_wrench, "More Tools", 0xFF8B5CF6, false, false, this::openToolsSheet), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams r1p = new LinearLayout.LayoutParams(-1, -2);
        r1p.topMargin = dp(24);
        sheetBox.addView(r1, r1p);

        // Row 2: plain icons
        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        r2.addView(menuItem(R.drawable.ic_star, "Add to Bookmarks", 0, false, cur.home, this::addBookmark), new LinearLayout.LayoutParams(0, -2, 1));
        r2.addView(menuItem(R.drawable.ic_moon, "Night", 0, pal.night, false, () -> {
            closeMenu();
            ui.postDelayed(() -> switchNight(!store.night()), 150);
        }), new LinearLayout.LayoutParams(0, -2, 1));
        r2.addView(menuItem(R.drawable.ic_refresh, "Refresh", 0, false, cur.home, () -> cur.web.reload()), new LinearLayout.LayoutParams(0, -2, 1));
        r2.addView(menuItem(R.drawable.ic_feedback, "Feedback", 0, false, false, this::feedback), new LinearLayout.LayoutParams(0, -2, 1));
        r2.addView(menuItem(R.drawable.ic_sharebox, "Share", 0, false, false, this::share), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams r2p = new LinearLayout.LayoutParams(-1, -2);
        r2p.topMargin = dp(22);
        r2p.bottomMargin = dp(16);
        sheetBox.addView(r2, r2p);

        View line = new View(this);
        line.setBackgroundColor(pal.line);
        sheetBox.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        View b1 = barBtn(R.drawable.ic_hexgear, () -> {
            closeMenu();
            openSettings();
        });
        View b2 = barBtn(R.drawable.ic_chevron, this::closeMenu);
        View b3 = barBtn(R.drawable.ic_power, () -> {
            closeMenu();
            confirmExit();
        });
        bar.addView(b1, new LinearLayout.LayoutParams(0, dp(54), 1));
        bar.addView(b2, new LinearLayout.LayoutParams(0, dp(54), 1));
        bar.addView(b3, new LinearLayout.LayoutParams(0, dp(54), 1));
        sheetBox.addView(bar, new LinearLayout.LayoutParams(-1, -2));
    }

    private View menuItem(int icon, String label, int circle, boolean on, boolean off, final Runnable action) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout holder = new FrameLayout(this);
        if (circle != 0) {
            holder.setBackground(oval(circle));
            holder.addView(Ui.icon(this, icon, 26, Color.WHITE), new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        } else {
            holder.addView(Ui.icon(this, icon, 30, on ? pal.accent : pal.icon), new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER));
        }
        v.addView(holder, new LinearLayout.LayoutParams(dp(54), dp(54)));
        TextView t = Ui.text(this, tr(label), 12, on ? pal.accent : (circle != 0 ? pal.fg : pal.icon), false);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(2);
        t.setPadding(0, dp(7), 0, 0);
        v.addView(t, new LinearLayout.LayoutParams(-1, -2));
        v.setAlpha(off ? 0.35f : 1f);
        if (!off) {
            v.setOnClickListener(x -> {
                closeMenu();
                action.run();
            });
        }
        return v;
    }

    private void share() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, cur.home ? "S.R Browser - Made in India" : cur.url);
        startActivity(Intent.createChooser(i, "Share"));
    }

    private TextView chip(String label, boolean on) {
        TextView t = Ui.text(this, label, 14, on ? Color.WHITE : pal.fg, on);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(16), dp(9), dp(16), dp(9));
        t.setBackground(Ui.round(this, on ? pal.accent : pal.surface2, 20));
        return t;
    }

    private TextView sectionTitle(String s) {
        TextView t = Ui.text(this, s, 15, pal.fg, true);
        t.setPadding(dp(20), dp(22), dp(20), dp(8));
        return t;
    }

    private void feedback() {
        openPanel(tr("Feedback"), null, null, body -> {
            TextView intro = Ui.text(this, "We love hearing from you. Tell us what you like, what is broken or what you want next. Every message helps make S.R Browser better.", 15, pal.muted, false);
            intro.setPadding(dp(20), dp(16), dp(20), dp(4));
            body.addView(intro);

            body.addView(sectionTitle("What is it about?"));
            final String[] topics = {"Suggestion", "Bug report", "Compliment", "Ads or pop-ups", "Other"};
            final int[] topic = {0};
            final List<TextView> chips = new ArrayList<>();
            LinearLayout wrap = new LinearLayout(this);
            wrap.setOrientation(LinearLayout.VERTICAL);
            wrap.setPadding(dp(16), 0, dp(16), 0);
            LinearLayout line = null;
            for (int i2 = 0; i2 < topics.length; i2++) {
                if (i2 % 3 == 0) {
                    line = new LinearLayout(this);
                    line.setOrientation(LinearLayout.HORIZONTAL);
                    wrap.addView(line, new LinearLayout.LayoutParams(-2, -2));
                }
                final int idx = i2;
                final TextView c = chip(topics[i2], i2 == 0);
                chips.add(c);
                c.setOnClickListener(v -> {
                    topic[0] = idx;
                    for (int k = 0; k < chips.size(); k++) {
                        TextView cc = chips.get(k);
                        boolean on = k == idx;
                        cc.setTextColor(on ? Color.WHITE : pal.fg);
                        cc.setTypeface(null, on ? Typeface.BOLD : Typeface.NORMAL);
                        cc.setBackground(Ui.round(this, on ? pal.accent : pal.surface2, 20));
                    }
                });
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
                cp.setMargins(dp(4), dp(4), dp(4), dp(4));
                line.addView(c, cp);
            }
            body.addView(wrap);

            body.addView(sectionTitle("How would you rate S.R Browser?"));
            final int[] rating = {0};
            final List<TextView> stars = new ArrayList<>();
            LinearLayout sr = new LinearLayout(this);
            sr.setOrientation(LinearLayout.HORIZONTAL);
            sr.setPadding(dp(16), 0, dp(16), 0);
            for (int i2 = 0; i2 < 5; i2++) {
                final int idx = i2;
                TextView s = Ui.text(this, "\u2605", 34, pal.line, false);
                s.setPadding(dp(4), 0, dp(4), 0);
                stars.add(s);
                s.setOnClickListener(v -> {
                    rating[0] = idx + 1;
                    for (int k = 0; k < stars.size(); k++)
                        stars.get(k).setTextColor(k <= idx ? 0xFFFFB400 : pal.line);
                });
                sr.addView(s);
            }
            body.addView(sr);

            body.addView(sectionTitle("Your message"));
            final EditText msg = new EditText(this);
            msg.setHint("Write here... what happened, or what should we add?");
            msg.setHintTextColor(pal.muted);
            msg.setTextColor(pal.fg);
            msg.setTextSize(16);
            msg.setMinLines(5);
            msg.setGravity(Gravity.TOP);
            msg.setPadding(dp(16), dp(14), dp(16), dp(14));
            msg.setBackground(Ui.round(this, pal.surface2, 16));
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
            mp.setMargins(dp(20), 0, dp(20), 0);
            body.addView(msg, mp);

            final EditText contact = new EditText(this);
            contact.setHint("Email or phone (optional)");
            contact.setHintTextColor(pal.muted);
            contact.setTextColor(pal.fg);
            contact.setTextSize(16);
            contact.setSingleLine(true);
            contact.setPadding(dp(16), 0, dp(16), 0);
            contact.setBackground(Ui.round(this, pal.surface2, 16));
            LinearLayout.LayoutParams cp2 = new LinearLayout.LayoutParams(-1, dp(52));
            cp2.setMargins(dp(20), dp(12), dp(20), 0);
            body.addView(contact, cp2);

            TextView send = Ui.text(this, "Send feedback", 17, Color.WHITE, true);
            send.setGravity(Gravity.CENTER);
            send.setBackground(Ui.round(this, pal.accent, 24));
            send.setOnClickListener(v -> {
                String text = msg.getText().toString().trim();
                if (text.isEmpty()) {
                    toast("Please write your message first");
                    return;
                }
                StringBuilder sb = new StringBuilder();
                sb.append("Topic: ").append(topics[topic[0]]).append('\n');
                if (rating[0] > 0) sb.append("Rating: ").append(rating[0]).append("/5\n");
                if (!contact.getText().toString().trim().isEmpty())
                    sb.append("Contact: ").append(contact.getText().toString().trim()).append('\n');
                sb.append("\n").append(text).append("\n\n");
                sb.append("App: S.R Browser ").append(APP_VER).append('\n');
                sb.append("Android ").append(Build.VERSION.RELEASE).append(" | ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL);
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, "S.R Browser feedback - " + topics[topic[0]]);
                i.putExtra(Intent.EXTRA_TEXT, sb.toString());
                startActivity(Intent.createChooser(i, "Send feedback with"));
            });
            LinearLayout.LayoutParams sp2 = new LinearLayout.LayoutParams(-1, dp(54));
            sp2.setMargins(dp(20), dp(18), dp(20), 0);
            body.addView(send, sp2);

            body.addView(sectionTitle("Quick help"));
            String[][] faq = {
                    {"Too many ads or pop-ups?", "Open Settings > Browsing Settings and make sure Block ads and Block pop-ups are on. Tell us the site name and we will block it."},
                    {"A site looks wrong?", "Turn on Desktop Site from the Tools menu, or turn off Data Saver, then reload the page."},
                    {"Video will not download?", "Downloads work when a page has a direct video file. YouTube, Instagram and Facebook protect their videos."},
                    {"Want a clean start?", "Settings > Clear Records lets you clear history, cookies, forms and cache in one tap."}
            };
            for (String[] f : faq) {
                LinearLayout card = new LinearLayout(this);
                card.setOrientation(LinearLayout.VERTICAL);
                card.setPadding(dp(16), dp(14), dp(16), dp(14));
                card.setBackground(Ui.round(this, pal.surface2, 16));
                card.addView(Ui.text(this, f[0], 15, pal.fg, true));
                TextView a = Ui.text(this, f[1], 14, pal.muted, false);
                a.setPadding(0, dp(4), 0, 0);
                card.addView(a);
                LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
                fp.setMargins(dp(20), 0, dp(20), dp(10));
                body.addView(card, fp);
            }
            View pad = new View(this);
            body.addView(pad, new LinearLayout.LayoutParams(-1, dp(24)));
        });
    }

    private void toggleDesktop(boolean v) {
        store.setDesktop(v);
        applyAllWebPrefs();
        if (!cur.home) cur.web.reload();
    }

    private void about() {
        new AlertDialog.Builder(this).setTitle("S.R Browser")
                .setMessage("Version 1.4\n" + tr("Made in India") + "\nSearch, videos, social and shopping in one place.")
                .setPositiveButton("OK", null).show();
    }

    /* ------------------------------------------------------------------ */
    /* Tab switcher (UC style)                                            */
    /* ------------------------------------------------------------------ */

    private void captureThumb(Tab t) {
        try {
            View v = t.home ? homeView : t.web;
            int w = v.getWidth(), h = v.getHeight();
            if (w <= 0 || h <= 0 || v.getVisibility() != View.VISIBLE) return;
            Bitmap b = Bitmap.createBitmap(w / 2, h / 2, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            c.scale(0.5f, 0.5f);
            v.draw(c);
            t.thumb = b;
        } catch (Throwable ignored) {
        }
    }

    private void openTabs() {
        if (cur != null) captureThumb(cur);
        if (store.num("tabview", 0) == 1) openTabsList();
        else buildTabsView();
    }

    /** Tab View: List View, from Browsing Settings. */
    private void openTabsList() {
        openPanel(tr("Tabs") + " (" + tabs.size() + ")", "+ " + tr("New"), () -> {
            closeAllPanels();
            newTab();
        }, b -> {
            LinearLayout card = card(b);
            for (int i = 0; i < tabs.size(); i++) {
                final Tab t = tabs.get(i);
                if (i > 0) {
                    View d = new View(this);
                    d.setBackgroundColor(pal.line);
                    card.addView(d, new LinearLayout.LayoutParams(-1, dp(1)));
                }
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(14), dp(12), dp(4), dp(12));
                if (t == cur) row.setBackgroundColor(pal.night ? 0xFF2A1518 : 0xFFFFF1F1);
                LinearLayout col = new LinearLayout(this);
                col.setOrientation(LinearLayout.VERTICAL);
                String title = t.home ? tr("Home") : (t.title == null || t.title.isEmpty() ? host(t.url) : t.title);
                col.addView(Ui.oneLine(Ui.text(this, title, 15.5f, t == cur ? pal.accent : pal.fg, t == cur)));
                if (!t.home) col.addView(Ui.oneLine(Ui.text(this, host(t.url), 12.5f, pal.muted, false)));
                row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
                ImageView x = Ui.icon(this, R.drawable.ic_close, 20, pal.muted);
                x.setPadding(dp(12), dp(12), dp(12), dp(12));
                x.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
                x.setOnClickListener(v -> {
                    closeTab(t);
                    refreshPanel();
                });
                row.addView(x);
                row.setOnClickListener(v -> {
                    closeAllPanels();
                    switchTo(t);
                });
                card.addView(row, new LinearLayout.LayoutParams(-1, -2));
            }
        });
    }

    private void closeTabsView() {
        if (tabsView != null) {
            screen.removeView(tabsView);
            tabsView = null;
        }
        showCurrent();
    }

    private void buildTabsView() {
        buildTabsView(-1);
    }

    /** Closes a tab from the tab switcher with a fly-out, then the others slide in to fill the gap. */
    private void closeTabAnimated(final Tab t, View card, boolean sideways, float dir) {
        final int idx = tabs.indexOf(t);
        int sw = getResources().getDisplayMetrics().widthPixels, sh = getResources().getDisplayMetrics().heightPixels;
        android.view.ViewPropertyAnimator a = card.animate().alpha(0f).setDuration(200);
        if (sideways) a.translationX(dir * sw);
        else a.translationY(-sh);
        a.withEndAction(() -> {
            closeTab(t);
            buildTabsView(idx);
        }).start();
    }

    private void buildTabsView(final int closedIdx) {
        boolean opening = tabsView == null;
        if (tabsView != null) screen.removeView(tabsView);
        final boolean inc = store.incognito();
        int bg = inc ? 0xFF272240 : 0xFF3A3A3C;
        final int ac = inc ? PURPLE : Pal.RED;
        int sw = getResources().getDisplayMetrics().widthPixels;
        int sh = getResources().getDisplayMetrics().heightPixels;

        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(bg);
        f.setClickable(true);

        ImageView more = Ui.icon(this, R.drawable.ic_dots, 26, 0xFFFFFFFF);
        more.setPadding(dp(10), dp(10), dp(10), dp(10));
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP | Gravity.END);
        mp.topMargin = dp(36);
        mp.rightMargin = dp(8);
        more.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setItems(new String[]{"Close all tabs"}, (d, which) -> {
                    List<Tab> copy = new ArrayList<>(tabs);
                    for (Tab t : copy) closeTab(t);
                    buildTabsView();
                }).show());
        f.addView(more, mp);

        if (inc) {
            LinearLayout info = new LinearLayout(this);
            info.setOrientation(LinearLayout.VERTICAL);
            info.setGravity(Gravity.CENTER_HORIZONTAL);
            info.setPadding(dp(20), dp(80), dp(20), 0);
            info.addView(Ui.text(this, tr("Incognito mode on"), 19, 0xFFFFFFFF, false));
            TextView d = Ui.text(this, "Browsing and search history will not be saved. Downloaded files and bookmarks are kept.", 13.5f, 0xCCFFFFFF, false);
            d.setGravity(Gravity.CENTER);
            d.setPadding(0, dp(8), 0, 0);
            info.addView(d);
            f.addView(info, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        }

        int cardW = (int) (sw * 0.75f);
        int cardH = (int) Math.min(cardW * 2.0f, sh * 0.66f);
        int gap = dp(18);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout rowL = new LinearLayout(this);
        rowL.setOrientation(LinearLayout.HORIZONTAL);
        rowL.setPadding((sw - cardW) / 2, 0, (sw - cardW) / 2, 0);
        int curIdx = Math.max(0, tabs.indexOf(cur));
        for (final Tab t : new ArrayList<>(tabs)) {
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);

            FrameLayout card = new FrameLayout(this);
            card.setBackground(Ui.round(this, pal.bg, 14));
            card.setElevation(dp(8));
            card.setClipToOutline(true);
            // UC style header strip inside the card: accent bar + page title
            LinearLayout tl = new LinearLayout(this);
            tl.setOrientation(LinearLayout.HORIZONTAL);
            tl.setGravity(Gravity.CENTER_VERTICAL);
            tl.setBackgroundColor(t == cur ? 0xFF7A7A7E : 0xFF6A6A6E);
            tl.setPadding(0, 0, dp(10), 0);
            View bar = new View(this);
            bar.setBackgroundColor(ac);
            tl.addView(bar, new LinearLayout.LayoutParams(dp(3), dp(22)));
            String title = t.home ? "S.R Browser" : (t.title == null || t.title.isEmpty() ? host(t.url) : t.title);
            TextView tt = Ui.oneLine(Ui.text(this, title, 16, t == cur ? 0xFFFFB27A : 0xFFEDEDED, true));
            tt.setPadding(dp(12), 0, 0, 0);
            tl.addView(tt, new LinearLayout.LayoutParams(0, -2, 1));
            if (t.thumb != null) {
                ImageView iv = new ImageView(this);
                iv.setImageBitmap(t.thumb);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setScaleType(ImageView.ScaleType.MATRIX);
                FrameLayout.LayoutParams ivp = new FrameLayout.LayoutParams(-1, -1);
                ivp.topMargin = dp(46);
                card.addView(iv, ivp);
                final ImageView ivf = iv;
                final Bitmap bm = t.thumb;
                iv.post(() -> {
                    float sc = ivf.getWidth() / (float) Math.max(1, bm.getWidth());
                    android.graphics.Matrix mx = new android.graphics.Matrix();
                    mx.setScale(sc, sc);
                    ivf.setImageMatrix(mx);
                });
            } else {
                String hn = t.home ? "S.R" : host(t.url);
                String letter = hn.isEmpty() ? "?" : hn.substring(0, 1).toUpperCase();
                TextView l = Ui.text(this, letter, 40, pal.accent, true);
                l.setGravity(Gravity.CENTER);
                card.addView(l, new FrameLayout.LayoutParams(-1, -1));
            }
            card.addView(tl, new FrameLayout.LayoutParams(-1, dp(46), Gravity.TOP));
            FrameLayout bottom = new FrameLayout(this);
            bottom.setBackgroundColor(0xAA000000);
            ImageView x = Ui.icon(this, R.drawable.ic_close, 26, 0xFFFFFFFF);
            bottom.addView(x, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
            bottom.setOnClickListener(v -> closeTabAnimated(t, col, false, 0));
            card.addView(bottom, new FrameLayout.LayoutParams(-1, dp(52), Gravity.BOTTOM));
            card.setOnClickListener(v -> openTabFromSwitcher(t, col));
            final LinearLayout colRef = col;
            final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
            final View.OnTouchListener swipe = new View.OnTouchListener() {
                float dx0, dy0;
                boolean swiping, side;

                @Override
                public boolean onTouch(View v, MotionEvent e) {
                    switch (e.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            dx0 = e.getRawX();
                            dy0 = e.getRawY();
                            swiping = false;
                            return false;
                        case MotionEvent.ACTION_MOVE: {
                            float dy = e.getRawY() - dy0;
                            float dx = e.getRawX() - dx0;
                            if (!swiping && !side && dy < -slop && Math.abs(dy) > Math.abs(dx) * 1.2f) {
                                swiping = true;
                                v.getParent().requestDisallowInterceptTouchEvent(true);
                            }
                            if (!swiping && !side && tabs.size() == 1 && Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.2f) {
                                side = true;
                                v.getParent().requestDisallowInterceptTouchEvent(true);
                            }
                            if (side) {
                                colRef.setTranslationX(dx);
                                colRef.setAlpha(Math.max(0.25f, 1f - Math.abs(dx) / (sw * 0.8f)));
                                colRef.setRotation(dx / sw * 8f);
                                return true;
                            }
                            if (swiping) {
                                float ty = Math.min(0, dy);
                                colRef.setTranslationY(ty);
                                colRef.setAlpha(Math.max(0.25f, 1f + ty / (sh * 0.5f)));
                                return true;
                            }
                            return false;
                        }
                        case MotionEvent.ACTION_UP:
                        case MotionEvent.ACTION_CANCEL:
                            if (side) {
                                side = false;
                                float tx = colRef.getTranslationX();
                                if (Math.abs(tx) > sw * 0.3f && e.getActionMasked() == MotionEvent.ACTION_UP) {
                                    closeTabAnimated(t, colRef, true, Math.signum(tx));
                                } else {
                                    colRef.animate().translationX(0).rotation(0).alpha(1f).setDuration(180).start();
                                }
                                return true;
                            }
                            if (swiping) {
                                swiping = false;
                                float ty = colRef.getTranslationY();
                                if (ty < -dp(110) && e.getActionMasked() == MotionEvent.ACTION_UP) {
                                    closeTabAnimated(t, colRef, false, 0);
                                } else {
                                    colRef.animate().translationY(0).alpha(1f).setDuration(180).start();
                                }
                                return true;
                            }
                            return false;
                    }
                    return false;
                }
            };
            card.setOnTouchListener(swipe);
            col.addView(card, new LinearLayout.LayoutParams(cardW, cardH));

            LinearLayout.LayoutParams colp = new LinearLayout.LayoutParams(-2, -2);
            colp.rightMargin = gap;
            rowL.addView(col, colp);
        }
        hs.addView(rowL, new ViewGroup.LayoutParams(-2, -2));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER_VERTICAL);
        hp.topMargin = dp(inc ? 70 : 20);
        f.addView(hs, hp);
        final int scrollTo = curIdx * (cardW + gap);
        hs.post(() -> hs.scrollTo(scrollTo, 0));

        // Bottom: incognito, new tab, undo
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);

        FrameLayout g = new FrameLayout(this);
        g.addView(Ui.icon(this, R.drawable.ic_ghost, 32, inc ? PURPLE : 0xFFFFFFFF),
                new FrameLayout.LayoutParams(dp(32), dp(32), Gravity.CENTER));
        g.setOnClickListener(v -> {
            store.setIncognito(!store.incognito());
            updateTabBtn();
            buildTabsView();
        });
        bar.addView(g, new LinearLayout.LayoutParams(dp(64), dp(64)));

        FrameLayout plus = new FrameLayout(this);
        plus.setBackground(oval(ac));
        plus.addView(Ui.icon(this, R.drawable.ic_plus, 34, 0xFFFFFFFF), new FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER));
        plus.setElevation(dp(4));
        plus.setOnClickListener(v -> {
            closeTabsView();
            newTab();
            if (store.num("newtab", 0) == 1 && homeEdit != null) {
                homeEdit.requestFocus();
                InputMethodManager m = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (m != null) m.showSoftInput(homeEdit, 0);
            }
        });
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(dp(66), dp(66));
        plp.leftMargin = dp(28);
        plp.rightMargin = dp(28);
        bar.addView(plus, plp);

        FrameLayout u = new FrameLayout(this);
        u.addView(Ui.icon(this, R.drawable.ic_undo, 30, 0xFFFFFFFF), new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER));
        u.setOnClickListener(v -> {
            if (closedUrls.isEmpty()) {
                toast("No closed tabs");
                return;
            }
            String last = closedUrls.remove(closedUrls.size() - 1);
            Tab nt = newTab();
            if (!last.isEmpty()) loadIn(nt, last);
            buildTabsView();
        });
        bar.addView(u, new LinearLayout.LayoutParams(dp(64), dp(64)));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        bp.bottomMargin = dp(36);
        f.addView(bar, bp);

        tabsView = f;
        screen.addView(f, new FrameLayout.LayoutParams(-1, -1));
        if (store.flag("anim", true)) {
            if (opening) {
                // UC style: the page shrinks into the tab card
                hs.setScaleX(1.25f);
                hs.setScaleY(1.25f);
                hs.setAlpha(0f);
                hs.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(260)
                        .setInterpolator(new android.view.animation.DecelerateInterpolator(1.6f)).start();
                f.setAlpha(0f);
                f.animate().alpha(1f).setDuration(180).start();
            } else if (closedIdx >= 0) {
                for (int i = 0; i < rowL.getChildCount(); i++) {
                    View c = rowL.getChildAt(i);
                    if (i >= closedIdx) {
                        c.setTranslationX(cardW + gap);
                        c.animate().translationX(0).setDuration(240).setStartDelay(30L * (i - closedIdx))
                                .setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
                    }
                }
            }
        }
    }

    /** UC style: the tapped card zooms up into the full page. */
    private void openTabFromSwitcher(final Tab t, View col) {
        if (!store.flag("anim", true) || tabsView == null) {
            switchTo(t);
            closeTabsView();
            return;
        }
        final View tv = tabsView;
        col.animate().scaleX(1.3f).scaleY(1.3f).setDuration(200).start();
        tv.animate().alpha(0f).setDuration(220).withEndAction(() -> {
            switchTo(t);
            closeTabsView();
        }).start();
    }

    /* ------------------------------------------------------------------ */
    /* Panels (stack)                                                     */
    /* ------------------------------------------------------------------ */

    private PanelState openPanel(String title, String rightLabel, Runnable rightAction,
                                 String bottomLabel, Runnable bottomAction, Renderer r) {
        final PanelState ps = new PanelState();
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackgroundColor(pal.bg);
        p.setClickable(true);

        FrameLayout head = new FrameLayout(this);
        head.setBackgroundColor(pal.bg);
        ImageView back = Ui.icon(this, R.drawable.ic_back, 26, pal.fg);
        back.setPadding(dp(10), dp(10), dp(10), dp(10));
        back.setOnClickListener(v -> closePanel());
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER_VERTICAL | Gravity.START);
        bl.leftMargin = dp(6);
        head.addView(back, bl);
        TextView tt = Ui.text(this, title, 19, pal.fg, true);
        head.addView(tt, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        if (rightLabel != null) {
            TextView a = Ui.text(this, rightLabel, 14.5f, pal.accent, true);
            a.setPadding(dp(10), dp(10), dp(10), dp(10));
            a.setOnClickListener(v -> rightAction.run());
            FrameLayout.LayoutParams al = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_VERTICAL | Gravity.END);
            al.rightMargin = dp(10);
            head.addView(a, al);
        }
        p.addView(head, new LinearLayout.LayoutParams(-1, dp(56)));

        ScrollView sv = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(6), dp(14), dp(24));
        sv.addView(body, new ViewGroup.LayoutParams(-1, -2));
        p.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        if (bottomLabel != null) {
            View line = new View(this);
            line.setBackgroundColor(pal.line);
            p.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
            TextView bt = Ui.text(this, bottomLabel, 17, pal.muted, false);
            bt.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            bt.setPadding(dp(24), 0, dp(24), 0);
            bt.setBackgroundColor(pal.bar);
            bt.setOnClickListener(v -> bottomAction.run());
            p.addView(bt, new LinearLayout.LayoutParams(-1, dp(58)));
        }

        ps.view = p;
        ps.body = body;
        ps.renderer = r;
        ps.id = title;
        panels.add(ps);
        screen.addView(p, new FrameLayout.LayoutParams(-1, -1));
        r.render(body);
        if (store.flag("anim", true)) {
            p.setTranslationX(getResources().getDisplayMetrics().widthPixels * 0.35f);
            p.setAlpha(0f);
            p.animate().translationX(0).alpha(1f).setDuration(200).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
        }
        return ps;
    }

    private PanelState openPanel(String title, String rightLabel, Runnable rightAction, Renderer r) {
        return openPanel(title, rightLabel, rightAction, null, null, r);
    }

    private void refreshPanel() {
        if (panels.isEmpty()) return;
        PanelState ps = panels.get(panels.size() - 1);
        ps.body.removeAllViews();
        ps.renderer.render(ps.body);
    }

    private void closePanel() {
        if (panels.isEmpty()) return;
        PanelState ps = panels.remove(panels.size() - 1);
        screen.removeView(ps.view);
        refreshPanel();
    }

    private void closeAllPanels() {
        while (!panels.isEmpty()) {
            PanelState ps = panels.remove(panels.size() - 1);
            screen.removeView(ps.view);
        }
    }

    private LinearLayout card(LinearLayout body) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Ui.round(this, pal.surface, 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(14);
        body.addView(c, lp);
        return c;
    }

    private void emptyState(LinearLayout body, int icon, String msg) {
        LinearLayout e = new LinearLayout(this);
        e.setOrientation(LinearLayout.VERTICAL);
        e.setGravity(Gravity.CENTER);
        e.setPadding(dp(16), dp(90), dp(16), dp(40));
        if (icon != 0) {
            ImageView iv = Ui.icon(this, icon, 84, pal.line);
            e.addView(iv, new LinearLayout.LayoutParams(dp(84), dp(84)));
        }
        TextView t = Ui.text(this, msg, 17, pal.muted, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(18), 0, 0);
        e.addView(t);
        body.addView(e, new LinearLayout.LayoutParams(-1, -2));
    }

    private void renderRows(LinearLayout body, List<Row> rows, String empty, int emptyIcon) {
        if (rows.isEmpty()) {
            emptyState(body, emptyIcon, empty);
            return;
        }
        LinearLayout c = card(body);
        for (int i = 0; i < rows.size(); i++) {
            final Row r = rows.get(i);
            if (i > 0) {
                View d = new View(this);
                d.setBackgroundColor(pal.line);
                c.addView(d, new LinearLayout.LayoutParams(-1, dp(1)));
            }
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(11), dp(8), dp(11));

            FrameLayout ib = new FrameLayout(this);
            ib.setBackground(Ui.round(this, pal.surface2, 11));
            if (r.icon != 0) {
                ib.addView(Ui.icon(this, r.icon, 20, pal.accent), new FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER));
            } else {
                String l = r.title.isEmpty() ? "?" : r.title.substring(0, 1).toUpperCase();
                TextView lt = Ui.text(this, l, 16, pal.accent, true);
                lt.setGravity(Gravity.CENTER);
                ib.addView(lt, new FrameLayout.LayoutParams(-1, -1));
            }
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(38), dp(38));
            ip.rightMargin = dp(12);
            row.addView(ib, ip);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(Ui.oneLine(Ui.text(this, r.title, 15, pal.fg, true)));
            if (r.sub != null && !r.sub.isEmpty()) col.addView(Ui.oneLine(Ui.text(this, r.sub, 12, pal.muted, false)));
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));

            if (r.delete != null) {
                ImageView x = Ui.icon(this, R.drawable.ic_close, 20, pal.muted);
                x.setPadding(dp(10), dp(10), dp(10), dp(10));
                x.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
                x.setOnClickListener(v -> r.delete.run());
                row.addView(x);
            }
            row.setOnClickListener(v -> {
                if (r.click != null) r.click.run();
            });
            c.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    /* ---- Bookmarks ---- */

    private void openBookmarks() {
        openPanel(tr("Bookmarks"), "+ Add", this::promptAddSite, body -> {
            List<Row> rows = new ArrayList<>();
            List<Store.Item> l = store.list("bm");
            for (int i = 0; i < l.size(); i++) {
                final Store.Item it = l.get(i);
                final int idx = i;
                rows.add(new Row(it.title, host(it.url), 0, () -> {
                    closeAllPanels();
                    loadIn(cur, it.url);
                }, () -> {
                    store.remove("bm", idx);
                    refreshHome();
                    refreshPanel();
                }));
            }
            renderRows(body, rows, "No bookmarks yet. Tap the star in the menu to save a page.", R.drawable.ic_bookmark_o);
        });
    }

    /* ---- History (UC style: Video / Website, grouped by day, search) ---- */

    private String histQuery = "";

    private void openHistory() {
        histQuery = "";
        openPanel(tr("History"), null, null, tr("Clear all"), this::editHistory, this::renderHistory);
    }

    private void editHistory() {
        final String key = histTab == 0 ? "vhist" : "hist";
        if (store.list(key).isEmpty()) {
            toast(tr("Nothing to clear"));
            return;
        }
        LinearLayout c = ucCard(false);
        c.addView(ucTitle(histTab == 0 ? "Clear video history?" : "Clear website history?"));
        final Dialog d = ucShow(c, false);
        c.addView(ucBtn("Clear", true, v -> {
            store.clear(key);
            d.dismiss();
            refreshPanel();
        }));
        c.addView(ucBtn("Cancel", false, v -> d.dismiss()));
    }

    private String dayLabel(long t) {
        if (t <= 0) return tr("Earlier");
        java.util.Calendar now = java.util.Calendar.getInstance(), c = java.util.Calendar.getInstance();
        c.setTimeInMillis(t);
        int dn = now.get(java.util.Calendar.YEAR) * 400 + now.get(java.util.Calendar.DAY_OF_YEAR);
        int dc = c.get(java.util.Calendar.YEAR) * 400 + c.get(java.util.Calendar.DAY_OF_YEAR);
        if (dn == dc) return tr("Today");
        if (dn - dc == 1) return tr("Yesterday");
        return new java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault()).format(new java.util.Date(t));
    }

    private void historyItemMenu(final String key, final int idx, final Store.Item it) {
        LinearLayout c = ucCard(true);
        TextView tt = Ui.text(this, it.title.isEmpty() ? host(it.url) : it.title, 16, pal.fg, true);
        tt.setMaxLines(2);
        tt.setPadding(dp(6), 0, dp(6), dp(2));
        c.addView(tt);
        TextView uu = Ui.oneLine(Ui.text(this, it.url, 12.5f, pal.muted, false));
        uu.setPadding(dp(6), 0, dp(6), dp(8));
        c.addView(uu);
        final Dialog d = ucShow(c, true);
        c.addView(sheetRow(R.drawable.ic_plus, "Open in new tab", () -> {
            d.dismiss();
            closeAllPanels();
            Tab nt = newTab();
            loadIn(nt, it.url);
        }));
        c.addView(sheetRow(R.drawable.ic_star, "Add to Bookmarks", () -> {
            d.dismiss();
            store.add("bm", it.title, it.url, 500, false);
            toast(tr("Added to bookmarks"));
        }));
        c.addView(sheetRow(R.drawable.ic_notes, "Copy link", () -> {
            d.dismiss();
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("link", it.url));
            toast(tr("Link copied"));
        }));
        c.addView(sheetRow(R.drawable.ic_share, "Share", () -> {
            d.dismiss();
            Intent i = new Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, it.url);
            startActivity(Intent.createChooser(i, tr("Share")));
        }));
        c.addView(sheetRow(R.drawable.ic_trash, "Delete", () -> {
            d.dismiss();
            store.remove(key, idx);
            refreshPanel();
        }));
    }

    private void renderHistory(LinearLayout body) {
        body.setPadding(0, 0, 0, dp(20));
        // Video / Website tabs
        LinearLayout tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {tr("Video"), tr("Website")};
        for (int i = 0; i < 2; i++) {
            final int idx = i;
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setGravity(Gravity.CENTER_HORIZONTAL);
            TextView t = Ui.text(this, names[i], 17, i == histTab ? pal.fg : pal.muted, i == histTab);
            t.setPadding(0, dp(8), 0, dp(8));
            c.addView(t);
            View u = new View(this);
            u.setBackground(Ui.round(this, i == histTab ? pal.accent : Color.TRANSPARENT, 2));
            c.addView(u, new LinearLayout.LayoutParams(dp(36), dp(3)));
            c.setOnClickListener(v -> {
                histTab = idx;
                refreshPanel();
            });
            tabsRow.addView(c, new LinearLayout.LayoutParams(0, -2, 1));
        }
        body.addView(tabsRow, new LinearLayout.LayoutParams(-1, -2));
        View tl = new View(this);
        tl.setBackgroundColor(pal.line);
        body.addView(tl, new LinearLayout.LayoutParams(-1, dp(1)));

        final String key = histTab == 0 ? "vhist" : "hist";
        final List<Store.Item> l = store.list(key);

        // Search box
        LinearLayout sb = new LinearLayout(this);
        sb.setOrientation(LinearLayout.HORIZONTAL);
        sb.setGravity(Gravity.CENTER_VERTICAL);
        sb.setBackground(Ui.round(this, pal.surface2, 20));
        sb.setPadding(dp(14), 0, dp(10), 0);
        sb.addView(Ui.icon(this, R.drawable.ic_search, 18, pal.muted));
        final EditText q = new EditText(this);
        q.setHint(tr("Search history"));
        q.setHintTextColor(pal.muted);
        q.setTextColor(pal.fg);
        q.setTextSize(15);
        q.setSingleLine(true);
        q.setBackground(null);
        q.setText(histQuery);
        q.setPadding(dp(10), 0, 0, 0);
        sb.addView(q, new LinearLayout.LayoutParams(0, -1, 1));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(42));
        sp.setMargins(dp(14), dp(12), dp(14), dp(4));
        body.addView(sb, sp);

        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(14), dp(4), dp(14), 0);
        body.addView(list, new LinearLayout.LayoutParams(-1, -2));
        final Runnable fill = () -> fillHistory(list, key, l, histQuery);
        q.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int st, int co, int af) {
            }

            @Override
            public void onTextChanged(CharSequence s, int st, int be, int co) {
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {
                histQuery = s.toString().trim();
                fill.run();
            }
        });
        fill.run();
    }

    private void fillHistory(LinearLayout list, final String key, List<Store.Item> l, String query) {
        list.removeAllViews();
        String ql = query.toLowerCase(java.util.Locale.getDefault());
        String lastDay = null;
        LinearLayout card = null;
        int shown = 0;
        java.text.SimpleDateFormat tf = new java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault());
        for (int i = 0; i < l.size(); i++) {
            final Store.Item it = l.get(i);
            final int idx = i;
            if (!ql.isEmpty() && !it.title.toLowerCase(java.util.Locale.getDefault()).contains(ql)
                    && !it.url.toLowerCase(java.util.Locale.getDefault()).contains(ql)) continue;
            String day = dayLabel(it.time);
            if (!day.equals(lastDay)) {
                TextView h = Ui.text(this, day, 13, pal.muted, true);
                h.setPadding(dp(6), dp(14), 0, dp(8));
                list.addView(h);
                card = card(list);
                lastDay = day;
            } else {
                View dv = new View(this);
                dv.setBackgroundColor(pal.line);
                LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, dp(1));
                dl.leftMargin = dp(62);
                card.addView(dv, dl);
            }
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(11), dp(4), dp(11));
            FrameLayout ib = new FrameLayout(this);
            ib.setBackground(Ui.round(this, histTab == 0 ? 0xFFFFEFF0 : pal.surface2, 11));
            if (histTab == 0) {
                ib.addView(Ui.icon(this, R.drawable.ic_video, 20, pal.accent), new FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER));
            } else {
                String h = host(it.url);
                String letter = h.isEmpty() ? "?" : h.replace("www.", "").substring(0, 1).toUpperCase();
                TextView lt = Ui.text(this, letter, 16, pal.accent, true);
                lt.setGravity(Gravity.CENTER);
                ib.addView(lt, new FrameLayout.LayoutParams(-1, -1));
            }
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(38), dp(38));
            ip.rightMargin = dp(12);
            row.addView(ib, ip);
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(Ui.oneLine(Ui.text(this, it.title.isEmpty() ? host(it.url) : it.title, 15, pal.fg, false)));
            String sub = host(it.url) + (it.time > 0 ? "  ·  " + tf.format(new java.util.Date(it.time)) : "");
            col.addView(Ui.oneLine(Ui.text(this, sub, 12, pal.muted, false)));
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
            ImageView more = Ui.icon(this, R.drawable.ic_dots, 20, pal.muted);
            more.setPadding(dp(10), dp(10), dp(10), dp(10));
            more.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
            more.setOnClickListener(v -> historyItemMenu(key, idx, it));
            row.addView(more);
            row.setOnClickListener(v -> {
                closeAllPanels();
                loadIn(cur, it.url);
            });
            row.setOnLongClickListener(v -> {
                historyItemMenu(key, idx, it);
                return true;
            });
            card.addView(row, new LinearLayout.LayoutParams(-1, -2));
            shown++;
        }
        if (shown == 0) {
            emptyState(list, histTab == 0 ? R.drawable.ic_video : R.drawable.ic_clock,
                    !query.isEmpty() ? tr("No results") : histTab == 0 ? tr("Videos you watch will show up here") : tr("No sites visited yet"));
        }
    }


    /* ---- Downloads (UC style) ---- */

    static final class DlState {
        int status = -1;
        long got, total;
        String reason = "";
    }

    static final class DlHolder {
        ProgressBar bar;
        TextView info;
        int status;
    }

    private static final String[] DL_CATS = {"All", "Video", "Music", "Image", "Document", "APK", "Others"};
    private static final int[] DL_CAT_COLOR = {0xFF8A90A0, 0xFFE5121B, 0xFFF59E0B, 0xFF10B981, 0xFF3B82F6, 0xFF22A35A, 0xFF8B5CF6};
    private int dlTab = 0;
    private int dlCat = 0;
    private PanelState dlPanel;
    private final java.util.Map<Long, DlHolder> dlViews = new java.util.HashMap<>();
    private final java.util.Map<Long, long[]> dlSpeed = new java.util.HashMap<>();
    private android.content.BroadcastReceiver dlDone;
    private TextView snackView;

    private static long dlId(Store.Item it) {
        try {
            int b = it.url.indexOf('|');
            return Long.parseLong(b < 0 ? it.url : it.url.substring(0, b));
        } catch (Exception e) {
            return -1;
        }
    }

    private static String dlSrc(Store.Item it) {
        String[] p = it.url.split("\\|", -1);
        return p.length > 1 ? p[1] : "";
    }

    private static String dlAudio(Store.Item it) {
        String[] p = it.url.split("\\|", -1);
        return p.length > 2 && !p[2].isEmpty() ? p[2] : null;
    }

    private static boolean isHls(String u) {
        return u != null && u.toLowerCase(java.util.Locale.US).contains(".m3u8");
    }

    private static String ext(String name) {
        int d = name == null ? -1 : name.lastIndexOf('.');
        return d < 0 || d == name.length() - 1 ? "" : name.substring(d + 1).toLowerCase();
    }

    /** 1 video, 2 music, 3 image, 4 document, 5 apk, 6 others. */
    private static int dlCatOf(String name) {
        String e = ext(name);
        switch (e) {
            case "mp4": case "mkv": case "webm": case "3gp": case "avi": case "mov": case "m4v": case "flv": case "ts": case "m3u8":
                return 1;
            case "mp3": case "m4a": case "aac": case "wav": case "ogg": case "flac": case "opus": case "amr":
                return 2;
            case "jpg": case "jpeg": case "png": case "gif": case "webp": case "bmp": case "heic": case "svg":
                return 3;
            case "pdf": case "doc": case "docx": case "xls": case "xlsx": case "ppt": case "pptx": case "txt": case "csv": case "epub": case "rtf":
                return 4;
            case "apk": case "xapk": case "apks":
                return 5;
            default:
                return 6;
        }
    }

    private static String fmtSize(long b) {
        if (b < 0) return "?";
        if (b < 1024) return b + " B";
        if (b < 1024L * 1024) return String.format(java.util.Locale.US, "%.0f KB", b / 1024f);
        if (b < 1024L * 1024 * 1024) return String.format(java.util.Locale.US, "%.1f MB", b / 1048576f);
        return String.format(java.util.Locale.US, "%.2f GB", b / 1073741824f);
    }

    private View fileBadge(String name, int sizeDp) {
        int cat = dlCatOf(name);
        FrameLayout f = new FrameLayout(this);
        f.setBackground(Ui.round(this, DL_CAT_COLOR[cat], 12));
        String e = ext(name).toUpperCase();
        if (e.isEmpty() || e.length() > 4) e = "FILE";
        TextView t = Ui.text(this, e, sizeDp > 44 ? 12 : 10.5f, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        f.addView(t, new FrameLayout.LayoutParams(-1, -1));
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        return f;
    }

    /** One cursor for all ids: fast even with many downloads. */
    private java.util.Map<Long, DlState> dlStates(List<Store.Item> l) {
        java.util.Map<Long, DlState> out = new java.util.HashMap<>();
        if (l.isEmpty()) return out;
        List<Long> dmIds = new ArrayList<>();
        for (Store.Item it : l) {
            long id = dlId(it);
            if (id >= 0) {
                dmIds.add(id);
                continue;
            }
            Grabber.Task g = Grabber.state(this, id);
            DlState s = new DlState();
            s.got = g.got;
            s.total = g.total;
            switch (g.status) {
                case Grabber.DONE:
                    s.status = DownloadManager.STATUS_SUCCESSFUL;
                    break;
                case Grabber.RUNNING:
                    s.status = DownloadManager.STATUS_RUNNING;
                    break;
                case Grabber.PENDING:
                    s.status = DownloadManager.STATUS_PENDING;
                    break;
                default:
                    s.status = DownloadManager.STATUS_FAILED;
                    s.reason = g.error == null || g.error.isEmpty() ? "Failed" : g.error;
            }
            out.put(id, s);
        }
        if (dmIds.isEmpty()) return out;
        long[] ids = new long[dmIds.size()];
        for (int i = 0; i < ids.length; i++) ids[i] = dmIds.get(i);
        try {
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            Cursor c = dm.query(new DownloadManager.Query().setFilterById(ids));
            if (c == null) return out;
            try {
                int iId = c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID);
                int iSt = c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS);
                int iGot = c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR);
                int iTot = c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES);
                int iRe = c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON);
                while (c.moveToNext()) {
                    DlState s = new DlState();
                    s.status = c.getInt(iSt);
                    s.got = c.getLong(iGot);
                    s.total = c.getLong(iTot);
                    int re = c.getInt(iRe);
                    if (s.status == DownloadManager.STATUS_PAUSED) {
                        if (re == DownloadManager.PAUSED_QUEUED_FOR_WIFI) s.reason = "Waiting for Wi-Fi";
                        else if (re == DownloadManager.PAUSED_WAITING_FOR_NETWORK) s.reason = "Waiting for network";
                        else if (re == DownloadManager.PAUSED_WAITING_TO_RETRY) s.reason = "Retrying...";
                        else s.reason = "Paused";
                    } else if (s.status == DownloadManager.STATUS_FAILED) {
                        if (re == DownloadManager.ERROR_INSUFFICIENT_SPACE) s.reason = "Not enough storage";
                        else if (re == DownloadManager.ERROR_FILE_ALREADY_EXISTS) s.reason = "File already exists";
                        else if (re >= 400 && re < 600) s.reason = "Server error " + re;
                        else s.reason = "Failed";
                    }
                    out.put(c.getLong(iId), s);
                }
            } finally {
                c.close();
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private boolean dlActive(DlState s) {
        return s != null && (s.status == DownloadManager.STATUS_RUNNING || s.status == DownloadManager.STATUS_PENDING
                || s.status == DownloadManager.STATUS_PAUSED);
    }

    private String dlLine(long id, DlState s) {
        if (s == null) return tr("File removed");
        if (s.status == DownloadManager.STATUS_SUCCESSFUL) return fmtSize(s.total);
        if (s.status == DownloadManager.STATUS_FAILED) return s.reason;
        if (s.status == DownloadManager.STATUS_PENDING) return tr("Waiting...");
        String size = fmtSize(s.got) + (s.total > 0 ? " / " + fmtSize(s.total) : "");
        if (s.status == DownloadManager.STATUS_PAUSED) return size + "  ·  " + s.reason;
        long now = System.currentTimeMillis();
        long[] prev = dlSpeed.get(id);
        String speed = "";
        if (prev != null && now > prev[1]) {
            long bps = (s.got - prev[0]) * 1000 / Math.max(1, now - prev[1]);
            if (bps > 0) speed = "  ·  " + fmtSize(bps) + "/s";
            if (bps > 0 && s.total > 0) {
                long left = (s.total - s.got) / bps;
                speed += left < 60 ? "  ·  " + left + "s left" : "  ·  " + (left / 60) + "m left";
            }
            if (now - prev[1] < 600) return null; // keep previous text, too soon
        }
        dlSpeed.put(id, new long[]{s.got, now});
        return size + speed;
    }

    /** Content uri + mime of a finished download (system or in-app). */
    private Uri[] dlUri(long id, String[] mime) {
        try {
            if (id < 0) {
                Grabber.Task g = Grabber.state(this, id);
                if (g.uri == null || g.uri.isEmpty()) return null;
                Uri u = Uri.parse(g.uri);
                mime[0] = g.uri.endsWith(".ts") ? "video/mp2t" : "video/*";
                if ("file".equals(u.getScheme())) {
                    Cursor c = getContentResolver().query(MediaStore.Files.getContentUri("external"),
                            new String[]{MediaStore.MediaColumns._ID}, MediaStore.MediaColumns.DATA + "=?",
                            new String[]{u.getPath()}, null);
                    if (c == null) return null;
                    try {
                        if (!c.moveToFirst()) return null;
                        u = Uri.withAppendedPath(MediaStore.Files.getContentUri("external"), String.valueOf(c.getLong(0)));
                    } finally {
                        c.close();
                    }
                }
                return new Uri[]{u};
            }
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            Uri u = dm.getUriForDownloadedFile(id);
            mime[0] = dm.getMimeTypeForDownloadedFile(id);
            return u == null ? null : new Uri[]{u};
        } catch (Exception e) {
            return null;
        }
    }

    private void openDownloadedFile(long id) {
        try {
            String[] m = new String[1];
            Uri[] u = dlUri(id, m);
            if (u == null) {
                toast(tr("File not found"));
                return;
            }
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u[0], m[0] == null ? "*/*" : m[0]);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(Intent.createChooser(i, tr("Open with")));
        } catch (Exception e) {
            toast(tr("No app found to open this file"));
        }
    }

    private void shareDownloadedFile(long id) {
        try {
            String[] m = new String[1];
            Uri[] u = dlUri(id, m);
            if (u == null) {
                toast(tr("File not found"));
                return;
            }
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType(m[0] == null ? "*/*" : m[0]);
            i.putExtra(Intent.EXTRA_STREAM, u[0]);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(i, tr("Share")));
        } catch (Exception e) {
            toast(tr("Could not share this file"));
        }
    }

    private void removeDownload(long id, boolean deleteFile) {
        if (id < 0) {
            if (deleteFile) {
                Grabber.Task g = Grabber.state(this, id);
                Grabber.cancel(id);
                try {
                    if (g.uri != null && !g.uri.isEmpty()) {
                        Uri u = Uri.parse(g.uri);
                        if ("file".equals(u.getScheme())) new File(u.getPath()).delete();
                        else getContentResolver().delete(u, null, null);
                    }
                } catch (Exception ignored) {
                }
            }
            Grabber.forget(this, id);
        } else if (deleteFile) {
            try {
                ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).remove(id);
            } catch (Exception ignored) {
            }
        }
        List<Store.Item> l = store.list("dl");
        for (int i = l.size() - 1; i >= 0; i--) {
            if (dlId(l.get(i)) == id) store.remove("dl", i);
        }
        dlViews.remove(id);
        dlSpeed.remove(id);
        refreshPanel();
    }

    /** Starts a download again from its saved source (direct file or streaming video). */
    private void redownload(Store.Item it) {
        String src = dlSrc(it);
        if (src.isEmpty()) {
            toast(tr("Link not saved for this file. Download it again from the page."));
            return;
        }
        if (isHls(src)) startStream(src, dlAudio(it), it.title, null);
        else enqueue(src, mobileUa, null, it.title);
    }

    private void downloadActions(final Store.Item it, final long id, final boolean done) {
        LinearLayout c = ucCard(true);
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(0, 0, 0, dp(10));
        View badge = fileBadge(it.title, 46);
        ((LinearLayout.LayoutParams) badge.getLayoutParams()).rightMargin = dp(12);
        head.addView(badge);
        TextView nm = Ui.text(this, it.title, 16, pal.fg, true);
        nm.setMaxLines(2);
        nm.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        head.addView(nm, new LinearLayout.LayoutParams(0, -2, 1));
        c.addView(head);
        final Dialog d = ucShow(c, true);
        if (done) {
            c.addView(sheetRow(R.drawable.ic_sharebox, "Open", () -> {
                d.dismiss();
                openDownloadedFile(id);
            }));
            c.addView(sheetRow(R.drawable.ic_share, "Share", () -> {
                d.dismiss();
                shareDownloadedFile(id);
            }));
        }
        final String src = dlSrc(it);
        if (!src.isEmpty()) {
            c.addView(sheetRow(R.drawable.ic_notes, "Copy download link", () -> {
                d.dismiss();
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("link", src));
                toast(tr("Link copied"));
            }));
            c.addView(sheetRow(R.drawable.ic_refresh, "Download again", () -> {
                d.dismiss();
                removeDownload(id, !done);
                redownload(it);
            }));
        }
        c.addView(sheetRow(R.drawable.ic_close, "Remove from list", () -> {
            d.dismiss();
            removeDownload(id, false);
        }));
        c.addView(sheetRow(R.drawable.ic_trash, done ? "Delete file" : "Cancel download", () -> {
            d.dismiss();
            removeDownload(id, true);
            toast(tr(done ? "File deleted" : "Download cancelled"));
        }));
    }

    private View sheetRow(int icon, String label, final Runnable r) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(6), dp(14), dp(6), dp(14));
        ImageView iv = Ui.icon(this, icon, 22, pal.icon);
        ((LinearLayout.LayoutParams) iv.getLayoutParams()).rightMargin = dp(18);
        row.addView(iv);
        row.addView(Ui.text(this, tr(label), 16.5f, pal.fg, false));
        row.setOnClickListener(v -> r.run());
        return row;
    }

    private void openDownloader() {
        dlViews.clear();
        dlPanel = openPanel(tr("Downloads"), "+ " + tr("Link"), this::promptDownloadLink, this::renderDownloads);
        ui.removeCallbacks(dlTick);
        ui.postDelayed(dlTick, 1000);
    }

    private boolean dlPanelOnTop() {
        return dlPanel != null && !panels.isEmpty() && panels.get(panels.size() - 1) == dlPanel;
    }

    /** Updates progress in place once a second; rebuilds the list only when a download changes state. */
    private final Runnable dlTick = new Runnable() {
        @Override
        public void run() {
            if (dlPanel == null || !panels.contains(dlPanel)) {
                dlPanel = null;
                return;
            }
            if (dlPanelOnTop()) {
                List<Store.Item> l = store.list("dl");
                java.util.Map<Long, DlState> st = dlStates(l);
                boolean rebuild = false;
                for (java.util.Map.Entry<Long, DlHolder> e : dlViews.entrySet()) {
                    DlState s = st.get(e.getKey());
                    int now = s == null ? -1 : s.status;
                    if (now != e.getValue().status) {
                        rebuild = true;
                        break;
                    }
                    if (s != null && dlActive(s)) {
                        DlHolder h = e.getValue();
                        if (s.total > 0) {
                            h.bar.setIndeterminate(false);
                            h.bar.setProgress((int) (s.got * 1000 / s.total));
                        }
                        String line = dlLine(e.getKey(), s);
                        if (line != null) h.info.setText(line);
                    }
                }
                if (rebuild) refreshPanel();
            }
            ui.postDelayed(this, 1000);
        }
    };

    private void renderDownloads(LinearLayout body) {
        dlViews.clear();
        body.setPadding(0, 0, 0, dp(16));
        final List<Store.Item> all = store.list("dl");
        java.util.Map<Long, DlState> st = dlStates(all);
        List<Store.Item> running = new ArrayList<>(), finished = new ArrayList<>();
        for (Store.Item it : all) {
            DlState s = st.get(dlId(it));
            if (s != null && s.status == DownloadManager.STATUS_SUCCESSFUL) finished.add(it);
            else running.add(it);
        }

        // Tabs: Downloading / Downloaded
        LinearLayout tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {tr("Downloading") + " (" + running.size() + ")", tr("Downloaded") + " (" + finished.size() + ")"};
        for (int i = 0; i < 2; i++) {
            final int idx = i;
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setGravity(Gravity.CENTER_HORIZONTAL);
            TextView t = Ui.text(this, names[i], 16, i == dlTab ? pal.fg : pal.muted, i == dlTab);
            t.setPadding(0, dp(8), 0, dp(8));
            c.addView(t);
            View u = new View(this);
            u.setBackground(Ui.round(this, i == dlTab ? pal.accent : Color.TRANSPARENT, 2));
            c.addView(u, new LinearLayout.LayoutParams(dp(36), dp(3)));
            c.setOnClickListener(v -> {
                dlTab = idx;
                refreshPanel();
            });
            tabsRow.addView(c, new LinearLayout.LayoutParams(0, -2, 1));
        }
        body.addView(tabsRow, new LinearLayout.LayoutParams(-1, -2));
        View tl = new View(this);
        tl.setBackgroundColor(pal.line);
        body.addView(tl, new LinearLayout.LayoutParams(-1, dp(1)));

        List<Store.Item> show = new ArrayList<>();
        if (dlTab == 1) {
            // Category chips
            HorizontalScrollView hs = new HorizontalScrollView(this);
            hs.setHorizontalScrollBarEnabled(false);
            LinearLayout chips = new LinearLayout(this);
            chips.setOrientation(LinearLayout.HORIZONTAL);
            chips.setPadding(dp(12), dp(12), dp(12), dp(4));
            for (int i = 0; i < DL_CATS.length; i++) {
                final int ci = i;
                int n = 0;
                for (Store.Item it : finished) if (i == 0 || dlCatOf(it.title) == i) n++;
                if (i != 0 && n == 0 && i != dlCat) continue;
                TextView ch = chip(tr(DL_CATS[i]) + (n > 0 ? " " + n : ""), i == dlCat);
                ch.setOnClickListener(v -> {
                    dlCat = ci;
                    refreshPanel();
                });
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
                cp.rightMargin = dp(8);
                chips.addView(ch, cp);
            }
            hs.addView(chips);
            body.addView(hs, new LinearLayout.LayoutParams(-1, -2));
            for (Store.Item it : finished) if (dlCat == 0 || dlCatOf(it.title) == dlCat) show.add(it);
        } else {
            show = running;
        }

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(dp(14), dp(10), dp(14), 0);
        body.addView(list, new LinearLayout.LayoutParams(-1, -2));

        if (show.isEmpty()) {
            emptyState(list, R.drawable.ic_dl_hex, dlTab == 0
                    ? tr("No active downloads.\nTap + Link or download from any page.")
                    : tr("No downloaded files yet"));
        } else {
            LinearLayout card = card(list);
            for (int i = 0; i < show.size(); i++) {
                if (i > 0) {
                    View d = new View(this);
                    d.setBackgroundColor(pal.line);
                    LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, dp(1));
                    dl.leftMargin = dp(70);
                    card.addView(d, dl);
                }
                card.addView(dlRow(show.get(i), st));
            }
        }

        if (dlTab == 1 && !finished.isEmpty()) {
            TextView clear = Ui.text(this, tr("Clear download list"), 14, pal.accent, true);
            clear.setGravity(Gravity.CENTER);
            clear.setPadding(0, dp(14), 0, dp(6));
            clear.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle(tr("Clear download list"))
                    .setMessage(tr("Files stay on your phone. Only the list is cleared."))
                    .setPositiveButton(tr("Clear"), (dd, w) -> {
                        List<Store.Item> l = store.list("dl");
                        java.util.Map<Long, DlState> s2 = dlStates(l);
                        for (int k = l.size() - 1; k >= 0; k--) {
                            DlState s = s2.get(dlId(l.get(k)));
                            if (s != null && s.status == DownloadManager.STATUS_SUCCESSFUL) store.remove("dl", k);
                        }
                        refreshPanel();
                    }).setNegativeButton(tr("Cancel"), null).show());
            body.addView(clear, new LinearLayout.LayoutParams(-1, -2));
        }

        body.addView(storageBar());
    }

    private View dlRow(final Store.Item it, java.util.Map<Long, DlState> st) {
        final long id = dlId(it);
        final DlState s = st.get(id);
        final boolean done = s != null && s.status == DownloadManager.STATUS_SUCCESSFUL;
        final boolean failed = s == null || s.status == DownloadManager.STATUS_FAILED;

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(12), dp(6), dp(12));
        View badge = fileBadge(it.title, 44);
        ((LinearLayout.LayoutParams) badge.getLayoutParams()).rightMargin = dp(14);
        row.addView(badge);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        TextView nm = Ui.text(this, it.title, 15, pal.fg, true);
        nm.setSingleLine(true);
        nm.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        col.addView(nm);
        DlHolder h = new DlHolder();
        h.status = s == null ? -1 : s.status;
        if (!done && !failed) {
            ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            pb.setMax(1000);
            pb.setProgressTintList(ColorStateList.valueOf(pal.accent));
            pb.setProgressBackgroundTintList(ColorStateList.valueOf(pal.line));
            if (s.total > 0) pb.setProgress((int) (s.got * 1000 / s.total));
            else pb.setIndeterminate(true);
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(4));
            pp.topMargin = dp(8);
            pp.bottomMargin = dp(6);
            col.addView(pb, pp);
            h.bar = pb;
        }
        String line = done ? fmtSize(s.total) + "  ·  " + tr("Completed") : dlLine(id, s);
        if (line == null) line = "";
        TextView info = Ui.text(this, line, 12.5f, failed ? pal.accent : pal.muted, false);
        info.setSingleLine(true);
        if (done || failed) info.setPadding(0, dp(4), 0, 0);
        col.addView(info);
        h.info = info;
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));

        // Trailing action, like UC: cancel while downloading, retry when failed, more when done
        int icon = done ? R.drawable.ic_dots : failed ? R.drawable.ic_refresh : R.drawable.ic_cancel;
        ImageView act = Ui.icon(this, icon, 22, failed ? pal.accent : pal.muted);
        act.setPadding(dp(11), dp(11), dp(11), dp(11));
        act.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        act.setOnClickListener(v -> {
            if (done) downloadActions(it, id, true);
            else if (failed) {
                removeDownload(id, true);
                redownload(it);
            } else {
                removeDownload(id, true);
                toast(tr("Download cancelled"));
            }
        });
        row.addView(act);
        row.setOnClickListener(v -> {
            if (done) openDownloadedFile(id);
            else downloadActions(it, id, false);
        });
        row.setOnLongClickListener(v -> {
            downloadActions(it, id, done);
            return true;
        });
        dlViews.put(id, h);
        return row;
    }

    private View storageBar() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(14), dp(16), dp(14));
        box.setBackground(Ui.round(this, pal.surface, 14));
        try {
            android.os.StatFs fs = new android.os.StatFs(Environment.getExternalStorageDirectory().getPath());
            long total = fs.getTotalBytes(), free = fs.getAvailableBytes();
            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.addView(Ui.text(this, tr("Phone storage"), 14, pal.fg, true), new LinearLayout.LayoutParams(0, -2, 1));
            top.addView(Ui.text(this, fmtSize(free) + " " + tr("free of") + " " + fmtSize(total), 12.5f, pal.muted, false));
            box.addView(top);
            ProgressBar pb = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            pb.setMax(1000);
            pb.setProgress(total > 0 ? (int) ((total - free) * 1000 / total) : 0);
            pb.setProgressTintList(ColorStateList.valueOf(free < total / 10 ? pal.accent : 0xFF3B82F6));
            pb.setProgressBackgroundTintList(ColorStateList.valueOf(pal.line));
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(5));
            pp.topMargin = dp(10);
            box.addView(pb, pp);
            TextView where = Ui.text(this, tr("Saved in: Internal storage / Download"), 12, pal.muted, false);
            where.setPadding(0, dp(8), 0, 0);
            box.addView(where);
        } catch (Exception e) {
            box.addView(Ui.text(this, tr("Saved in: Internal storage / Download"), 13, pal.muted, false));
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(14), dp(16), dp(14), 0);
        box.setLayoutParams(lp);
        return box;
    }

    private void promptDownloadLink() {
        LinearLayout c = ucCard(true);
        c.addView(ucTitle("Download from link"));
        final EditText e = ucInput("https://site.com/file.mp4", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0) {
                CharSequence cs = cm.getPrimaryClip().getItemAt(0).getText();
                if (cs != null && cs.toString().trim().startsWith("http")) e.setText(cs.toString().trim());
            }
        } catch (Exception ignored) {
        }
        c.addView(e);
        final Dialog d = ucShow(c, true);
        c.addView(ucBtn("Download", true, v -> {
            String u = e.getText().toString().trim();
            if (!u.startsWith("http://") && !u.startsWith("https://")) {
                toast(tr("Enter the full link, starting with https://"));
                return;
            }
            d.dismiss();
            startDownload(u, mobileUa, null, null, -1);
        }));
        c.addView(ucBtn("Cancel", false, v -> d.dismiss()));
    }

    /** Small UC style toast bar with an action, shown above the bottom bar. */
    private void snack(String msg, String action, final Runnable r) {
        if (snackView != null) screen.removeView(snackView);
        final TextView s = Ui.text(this, action == null ? msg : msg + "     " + action, 14, Color.WHITE, false);
        s.setSingleLine(true);
        s.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        s.setPadding(dp(18), dp(13), dp(18), dp(13));
        s.setBackground(Ui.round(this, 0xF01C2024, 24));
        s.setElevation(dp(6));
        if (action != null) {
            android.text.SpannableString ss = new android.text.SpannableString(s.getText());
            int st = ss.length() - action.length();
            ss.setSpan(new android.text.style.ForegroundColorSpan(0xFFFF6B6B), st, ss.length(), 0);
            ss.setSpan(new android.text.style.StyleSpan(Typeface.BOLD), st, ss.length(), 0);
            s.setText(ss);
            s.setOnClickListener(v -> {
                screen.removeView(s);
                if (snackView == s) snackView = null;
                r.run();
            });
        }
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        lp.bottomMargin = dp(84);
        lp.leftMargin = dp(16);
        lp.rightMargin = dp(16);
        s.setAlpha(0f);
        s.setTranslationY(dp(20));
        screen.addView(s, lp);
        s.animate().alpha(1f).translationY(0).setDuration(220).start();
        snackView = s;
        ui.postDelayed(() -> {
            if (snackView == s) {
                s.animate().alpha(0f).setDuration(220).withEndAction(() -> {
                    screen.removeView(s);
                    if (snackView == s) snackView = null;
                }).start();
            }
        }, 3500);
    }

    private void dlFinished(final long id, String name, boolean ok) {
        if (ok) {
            if (store.flag("dl_autoopen", false)) openDownloadedFile(id);
            else if (store.flag("justin", true)) snack(tr("Download complete") + ": " + name, tr("OPEN"), () -> openDownloadedFile(id));
        } else if (store.flag("justin", true)) {
            snack(tr("Download failed") + ": " + name, tr("VIEW"), this::openDownloader);
        }
        if (dlPanelOnTop()) refreshPanel();
    }

    private void registerDownloadDone() {
        dlDone = new android.content.BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                final long id = i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                String name = null;
                for (Store.Item it : store.list("dl")) if (dlId(it) == id) name = it.title;
                if (name == null) return;
                List<Store.Item> one = new ArrayList<>();
                one.add(new Store.Item(name, String.valueOf(id)));
                DlState s = dlStates(one).get(id);
                if (s != null) dlFinished(id, name, s.status == DownloadManager.STATUS_SUCCESSFUL);
            }
        };
        Grabber.listener = g -> {
            if (g.status == Grabber.DONE || g.status == Grabber.FAILED) {
                List<Store.Item> l = store.list("dl");
                for (int i = 0; i < l.size(); i++) {
                    Store.Item it = l.get(i);
                    if (dlId(it) == g.id) {
                        if (!it.title.equals(g.name)) store.replace("dl", i, g.name, it.url);
                        dlFinished(g.id, g.name, g.status == Grabber.DONE);
                        break;
                    }
                }
            }
        };
        android.content.IntentFilter f = new android.content.IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        try {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(dlDone, f, Context.RECEIVER_EXPORTED);
            else registerReceiver(dlDone, f);
        } catch (Exception e) {
            dlDone = null;
        }
    }

    /* ---- Notes ---- */

    private void openNotes() {
        openPanel(tr("Notes"), "+ New", () -> editNote(-1), body -> {
            List<Row> rows = new ArrayList<>();
            List<Store.Item> l = store.list("notes");
            for (int i = 0; i < l.size(); i++) {
                final Store.Item it = l.get(i);
                final int idx = i;
                String first = it.title.split("\n")[0];
                rows.add(new Row(first, it.title.length() > first.length() ? it.title.substring(first.length()).trim() : "",
                        R.drawable.ic_notes, () -> editNote(idx), () -> {
                    store.remove("notes", idx);
                    refreshPanel();
                }));
            }
            renderRows(body, rows, "No notes yet. Tap + New.", R.drawable.ic_notes);
        });
    }

    private void editNote(final int idx) {
        final EditText e = new EditText(this);
        e.setHint("Write a note");
        e.setMinLines(4);
        e.setGravity(Gravity.TOP);
        if (idx >= 0) e.setText(store.list("notes").get(idx).title);
        LinearLayout l = new LinearLayout(this);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        l.addView(e, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this).setTitle("Note").setView(l)
                .setPositiveButton("Save", (d, w) -> {
                    String m = e.getText().toString().trim();
                    if (m.isEmpty()) return;
                    if (idx >= 0) store.replace("notes", idx, m, String.valueOf(System.currentTimeMillis()));
                    else store.add("notes", m, String.valueOf(System.currentTimeMillis()), 200, true);
                    refreshPanel();
                }).setNegativeButton("Cancel", null).show();
    }

    /* ---- More tools ---- */

    /* ---- UC style Tools sheet ---- */

    private View toolItem(final Dialog[] dd, int icon, String label, boolean on, boolean off, final Runnable action) {
        View v = menuItem(icon, label, 0, on, off, () -> {
            if (dd[0] != null) dd[0].dismiss();
            if (off) {
                toast("Open a website first");
                return;
            }
            action.run();
        });
        v.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        if (off) v.setAlpha(0.4f);
        return v;
    }

    private void openToolsSheet() {
        closeMenu();
        final Dialog[] dd = new Dialog[1];
        final boolean home = cur.home;
        LinearLayout c = ucCard(true);
        c.setPadding(dp(10), dp(18), dp(10), dp(8));
        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.addView(toolItem(dd, R.drawable.ic_cloud, "Speed Mode", store.dataSaver(), false, () -> {
            store.setDataSaver(!store.dataSaver());
            store.setNum("imgmode", store.dataSaver() ? 1 : 0);
            applyAllWebPrefs();
            if (!cur.home) cur.web.reload();
            toast(store.dataSaver() ? "Speed Mode on" : "Speed Mode off");
        }));
        r1.addView(toolItem(dd, R.drawable.ic_camera, "Screen Shot", false, false, this::takeShot));
        r1.addView(toolItem(dd, R.drawable.ic_notes, "Clipboard", false, false, this::showClipboard));
        r1.addView(toolItem(dd, R.drawable.ic_translate, "AI Translation", false, false, () -> {
            String u = cur.home ? "https://translate.google.com"
                    : "https://translate.google.com/translate?sl=auto&tl=" + (store.num("tr_lang", 0) == 1 ? "en" : "hi") + "&u=" + Uri.encode(cur.url);
            loadIn(cur, u);
        }));
        r1.addView(toolItem(dd, R.drawable.ic_desktop, "Desktop Site", store.desktop(), false, () -> toggleDesktop(!store.desktop())));
        c.addView(r1, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        r2.addView(toolItem(dd, R.drawable.ic_download, "Save Page", false, home, this::savePage));
        r2.addView(toolItem(dd, R.drawable.ic_full, "Full Screen Mode", false, false, () -> {
            fullscreen = true;
            applySystemUi();
        }));
        r2.addView(toolItem(dd, R.drawable.ic_search, "Find in Page", false, home, this::showFind));
        r2.addView(toolItem(dd, R.drawable.ic_wrench, "More", false, false, this::openMoreTools));
        View filler = new View(this);
        r2.addView(filler, new LinearLayout.LayoutParams(0, 1, 1));
        LinearLayout.LayoutParams r2p = new LinearLayout.LayoutParams(-1, -2);
        r2p.topMargin = dp(14);
        c.addView(r2, r2p);
        View line = new View(this);
        line.setBackgroundColor(pal.line);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.topMargin = dp(10);
        c.addView(line, lp);
        TextView cancel = Ui.text(this, tr("Cancel"), 19, pal.fg, true);
        cancel.setGravity(Gravity.CENTER);
        cancel.setPadding(0, dp(14), 0, dp(10));
        c.addView(cancel, new LinearLayout.LayoutParams(-1, -2));
        dd[0] = ucShow(c, true);
        cancel.setOnClickListener(v -> dd[0].dismiss());
    }

    private void takeShot() {
        ui.postDelayed(() -> {
            try {
                final View dv = getWindow().getDecorView();
                final Bitmap b = Bitmap.createBitmap(dv.getWidth(), dv.getHeight(), Bitmap.Config.ARGB_8888);
                if (Build.VERSION.SDK_INT >= 26) {
                    android.view.PixelCopy.request(getWindow(), b, r -> {
                        if (r == android.view.PixelCopy.SUCCESS) saveShot(b);
                        else toast("Could not take screenshot");
                    }, ui);
                } else {
                    dv.draw(new Canvas(b));
                    saveShot(b);
                }
            } catch (Exception e) {
                toast("Could not take screenshot");
            }
        }, 350);
    }

    private void saveShot(Bitmap b) {
        try {
            String name = "SR_" + System.currentTimeMillis() + ".jpg";
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SR Browser");
                Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
                java.io.OutputStream os = getContentResolver().openOutputStream(u);
                b.compress(Bitmap.CompressFormat.JPEG, 92, os);
                os.close();
            } else {
                MediaStore.Images.Media.insertImage(getContentResolver(), b, name, null);
            }
            toast("Screenshot saved to gallery");
        } catch (Exception e) {
            toast("Could not save screenshot");
        }
    }

    private void showClipboard() {
        CharSequence tx = null;
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0)
                tx = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
        } catch (Exception ignored) {
        }
        final String text = tx == null ? "" : tx.toString().trim();
        LinearLayout c = ucCard(false);
        c.addView(ucTitle("Clipboard"));
        TextView t = Ui.text(this, text.isEmpty() ? tr("Clipboard is empty") : text, 16, text.isEmpty() ? pal.muted : pal.fg, false);
        t.setMaxLines(6);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setGravity(Gravity.CENTER);
        c.addView(t);
        final Dialog d = ucShow(c, false);
        if (!text.isEmpty()) {
            c.addView(ucBtn("Open / Search", true, v -> {
                d.dismiss();
                loadIn(cur, toUrl(text));
            }));
        }
        c.addView(ucBtn("Close", false, v -> d.dismiss()));
    }

    private void savePage() {
        try {
            File dir = new File(getExternalFilesDir(null), "pages");
            dir.mkdirs();
            File f = new File(dir, host(cur.url).replace('.', '_') + "_" + System.currentTimeMillis() + ".mht");
            cur.web.saveWebArchive(f.getAbsolutePath());
            toast("Page saved");
        } catch (Exception e) {
            toast("Could not save page");
        }
    }

    private void showFind() {
        final WebView w = cur.web;
        LinearLayout c = ucCard(true);
        final EditText q = ucInput("Find in page", InputType.TYPE_CLASS_TEXT);
        c.addView(q);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        final Dialog d = ucShow(c, true);
        View prev = ucBtn("Prev", false, v -> w.findNext(false));
        View next = ucBtn("Next", true, v -> w.findNext(true));
        View close = ucBtn("Close", false, v -> d.dismiss());
        LinearLayout.LayoutParams a = new LinearLayout.LayoutParams(0, dp(50), 1);
        a.rightMargin = dp(8);
        LinearLayout.LayoutParams b = new LinearLayout.LayoutParams(0, dp(50), 1);
        b.rightMargin = dp(8);
        row.addView(prev, a);
        row.addView(next, b);
        row.addView(close, new LinearLayout.LayoutParams(0, dp(50), 1));
        c.addView(row);
        q.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int st, int co, int af) {
            }

            @Override
            public void onTextChanged(CharSequence s, int st, int be, int co) {
                w.findAllAsync(s.toString());
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {
            }
        });
        d.setOnDismissListener(x -> w.clearMatches());
        if (d.getWindow() != null) {
            d.getWindow().setDimAmount(0f);
            d.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
                    | android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        q.requestFocus();
    }

    private void openMoreTools() {
        openPanel(tr("More Tools"), null, null, body -> {
            body.setPadding(0, 0, 0, dp(24));
            flatRow(body, "Desktop Site", "Show the desktop version of sites", null, sw(store.desktop(), this::toggleDesktop), null);
            flatRow(body, "Full Screen", null, null, null, () -> {
                closeAllPanels();
                fullscreen = true;
                applySystemUi();
            });
            flatRow(body, "Add-ons", null, null, chev(), this::openAddons);
            flatRow(body, "My Videos", null, null, chev(), this::openVideos);
            flatRow(body, "Font Size", null, store.num("zoom", 100) + "%", chev(), this::openFontSize);
            flatRow(body, "Clear Cache", null, null, null, () -> {
                for (Tab t : tabs) t.web.clearCache(true);
                toast("Cache cleared");
            });
        });
    }

    private void openVideos() {
        openPanel("My Videos", "+ This page", () -> {
            if (cur.home) {
                toast("Open a video page first");
                return;
            }
            String t = cur.title == null || cur.title.isEmpty() ? host(cur.url) : cur.title;
            store.add("vid", t, cur.url, 200, true);
            refreshPanel();
            toast("Video saved");
        }, body -> {
            List<Row> rows = new ArrayList<>();
            List<Store.Item> l = store.list("vid");
            for (int i = 0; i < l.size(); i++) {
                final Store.Item it = l.get(i);
                final int idx = i;
                rows.add(new Row(it.title, host(it.url), R.drawable.ic_video, () -> {
                    closeAllPanels();
                    loadIn(cur, it.url);
                }, () -> {
                    store.remove("vid", idx);
                    refreshPanel();
                }));
            }
            renderRows(body, rows, "Open a video page, then tap \"+ This page\" here.", R.drawable.ic_video);
        });
    }

    private void openAddons() {
        openPanel("Add-ons", null, null, body -> {
            String[][] a = {
                    {"Google Translate", "Translate any language", "https://translate.google.com", "ic_translate"},
                    {"Maps", "Find places and directions", "https://maps.google.com", "ic_map"},
                    {"News", "Latest news", "https://news.google.com", "ic_news"},
                    {"Weather", "Today's weather", "https://www.google.com/search?q=weather", "ic_sun"},
                    {"Cricket score", "Live score", "https://www.google.com/search?q=cricket+score", "ic_ball"}
            };
            List<Row> rows = new ArrayList<>();
            for (final String[] x : a) {
                int res = getResources().getIdentifier(x[3], "drawable", getPackageName());
                rows.add(new Row(x[0], x[1], res, () -> {
                    closeAllPanels();
                    loadIn(cur, x[2]);
                }, null));
            }
            renderRows(body, rows, "", 0);
        });
    }

    /* ---- Theme zone ---- */

    private boolean hasWallpaper() {
        return new File(getFilesDir(), "wall.jpg").exists();
    }

    private void openThemes() {
        openPanel(tr("Theme Zone"), null, null, body -> {
            int sw = getResources().getDisplayMetrics().widthPixels;
            int cw = (sw - dp(28) - dp(16)) / 3;
            int ch = (int) (cw * 1.45f);
            List<View> cards = new ArrayList<>();
            for (int i = 0; i < THEME_COLORS.length; i++) {
                final int idx = i;
                FrameLayout c = new FrameLayout(this);
                if (i == 0) {
                    GradientDrawable g = Ui.round(this, 0xFFFFFFFF, 8);
                    g.setStroke(dp(1), pal.line);
                    c.setBackground(g);
                    ImageView li = new ImageView(this);
                    li.setImageResource(R.drawable.logo);
                    li.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    li.setPadding(dp(10), dp(10), dp(10), dp(10));
                    c.addView(li, new FrameLayout.LayoutParams(-1, -1));
                } else {
                    GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, THEME_COLORS[i]);
                    g.setCornerRadius(dp(8));
                    c.setBackground(g);
                    TextView nm = Ui.text(this, THEME_NAMES[i], 12, 0xFFFFFFFF, true);
                    nm.setGravity(Gravity.CENTER);
                    c.addView(nm, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
                    nm.setPadding(0, 0, 0, dp(10));
                }
                if (store.theme() == i) addCheck(c);
                c.setOnClickListener(v -> {
                    store.setTheme(idx);
                    refreshHome();
                    refreshPanel();
                });
                cards.add(c);
            }
            if (hasWallpaper()) {
                FrameLayout c = new FrameLayout(this);
                File f = new File(getFilesDir(), "wall.jpg");
                Bitmap b = BitmapFactory.decodeFile(f.getPath());
                ImageView iv = new ImageView(this);
                if (b != null) iv.setImageBitmap(b);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setBackground(Ui.round(this, pal.surface2, 8));
                iv.setClipToOutline(true);
                c.addView(iv, new FrameLayout.LayoutParams(-1, -1));
                if (store.theme() == 5) addCheck(c);
                c.setOnClickListener(v -> {
                    store.setTheme(5);
                    refreshHome();
                    refreshPanel();
                });
                cards.add(c);
            }
            FrameLayout add = new FrameLayout(this);
            add.setBackground(Ui.round(this, pal.surface2, 8));
            add.addView(Ui.icon(this, R.drawable.ic_plus, 34, pal.muted), new FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER));
            add.setOnClickListener(v -> {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("image/*");
                try {
                    startActivityForResult(i, REQ_PHOTO);
                } catch (Exception e) {
                    toast("No gallery app found");
                }
            });
            cards.add(add);

            for (int i = 0; i < cards.size(); i += 3) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                for (int j = 0; j < 3; j++) {
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(cw, ch);
                    lp.rightMargin = dp(8);
                    lp.bottomMargin = dp(8);
                    if (i + j < cards.size()) row.addView(cards.get(i + j), lp);
                    else row.addView(new View(this), lp);
                }
                body.addView(row, new LinearLayout.LayoutParams(-1, -2));
            }
            TextView lp = Ui.text(this, tr("Local Photos"), 16, pal.fg, false);
            lp.setPadding(dp(4), dp(18), 0, 0);
            body.addView(lp);
        });
    }

    private void addCheck(FrameLayout c) {
        FrameLayout badge = new FrameLayout(this);
        badge.setBackground(oval(pal.accent));
        badge.addView(Ui.icon(this, R.drawable.ic_check, 16, 0xFFFFFFFF), new FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.BOTTOM | Gravity.END);
        bp.rightMargin = dp(6);
        bp.bottomMargin = dp(6);
        c.addView(badge, bp);
    }

    private void saveWallpaper(Uri uri) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, o);
            }
            int sw = getResources().getDisplayMetrics().widthPixels;
            int sh = getResources().getDisplayMetrics().heightPixels;
            int sample = 1;
            while (o.outWidth / (sample * 2) >= sw && o.outHeight / (sample * 2) >= sh) sample *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            Bitmap b;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                b = BitmapFactory.decodeStream(in, null, o);
            }
            if (b == null) {
                toast("Could not open the photo");
                return;
            }
            // Crop to the screen shape so it fills the home screen without stretching
            float target = sw / (float) sh;
            int cw = b.getWidth(), chh = b.getHeight();
            int nw = cw, nh = chh;
            if (cw / (float) chh > target) nw = Math.round(chh * target);
            else nh = Math.round(cw / target);
            Bitmap out = Bitmap.createBitmap(b, (cw - nw) / 2, (chh - nh) / 2, nw, nh);
            try (FileOutputStream fo = new FileOutputStream(new File(getFilesDir(), "wall.jpg"))) {
                out.compress(Bitmap.CompressFormat.JPEG, 88, fo);
            }
            store.setTheme(5);
            refreshHome();
            refreshPanel();
            toast("Wallpaper applied");
        } catch (Exception e) {
            toast("Could not set the photo");
        }
    }

    /* ------------------------------------------------------------------ */
    /* Settings (UC style list)                                           */
    /* ------------------------------------------------------------------ */

    private View chev() {
        return Ui.icon(this, R.drawable.ic_chev_right, 22, pal.muted);
    }

    private Switch sw(boolean on, final BoolCb cb) {
        Switch s = new Switch(this);
        s.setChecked(on);
        s.setOnCheckedChangeListener((b, v) -> cb.on(v));
        return s;
    }

    private void flatRow(LinearLayout body, String title, String sub, String right, View trailing, final Runnable click) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(22), dp(18), dp(20), dp(18));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(Ui.text(this, tr(title), 17, pal.fg, false));
        if (sub != null) {
            TextView s = Ui.text(this, sub, 12.5f, pal.muted, false);
            s.setPadding(0, dp(3), 0, 0);
            col.addView(s);
        }
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        if (right != null) {
            TextView r = Ui.text(this, right, 14.5f, pal.muted, false);
            r.setPadding(dp(8), 0, dp(6), 0);
            row.addView(r);
        }
        if (trailing != null) row.addView(trailing);
        if (click != null) row.setOnClickListener(v -> click.run());
        body.addView(row, new LinearLayout.LayoutParams(-1, -2));
        View d = new View(this);
        d.setBackgroundColor(pal.line);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, dp(1));
        dl.leftMargin = dp(22);
        dl.rightMargin = dp(22);
        body.addView(d, dl);
    }

    private boolean isDefaultBrowser() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
                return rm != null && rm.isRoleHeld(RoleManager.ROLE_BROWSER);
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private void openDefaultSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));
        } catch (Exception e) {
            toast("Go to phone Settings > Apps > Default apps");
        }
    }

    private void openSettings() {
        openPanel(tr("Settings"), null, null, this::renderSettings);
    }

    private void setHead(LinearLayout b, String title) {
        TextView t = Ui.text(this, tr(title), 13, pal.accent, true);
        t.setPadding(dp(22), dp(22), dp(22), dp(6));
        b.addView(t);
    }

    /** UC style "•••" marker for rows that open a choice. */
    private View dots() {
        return Ui.icon(this, R.drawable.ic_dots, 22, pal.muted);
    }

    /** A switch row bound to a stored flag. */
    private void flagRow(LinearLayout b, String title, String sub, final String key, boolean def, final BoolCb after) {
        flatRow(b, title, sub == null ? null : tr(sub), null, sw(store.flag(key, def), v -> {
            store.setFlag(key, v);
            if (after != null) after.on(v);
        }), null);
    }

    /** A single-choice row bound to a stored number (UC shows the value and •••). */
    private void choiceRow(LinearLayout b, final String title, final String key, final int def, final String[] items, final Runnable after) {
        choiceRow(b, title, null, key, def, items, after);
    }

    private void choiceRow(LinearLayout b, final String title, String sub, final String key, final int def, final String[] items, final Runnable after) {
        final int curV = Math.max(0, Math.min(items.length - 1, store.num(key, def)));
        flatRow(b, title, sub == null ? null : tr(sub), tr(items[curV]), dots(), () -> {
            String[] tri = new String[items.length];
            for (int i = 0; i < items.length; i++) tri[i] = tr(items[i]);
            new AlertDialog.Builder(this).setTitle(tr(title))
                    .setSingleChoiceItems(tri, Math.max(0, Math.min(items.length - 1, store.num(key, def))), (d, which) -> {
                        store.setNum(key, which);
                        d.dismiss();
                        if (after != null) after.run();
                        refreshPanel();
                    }).setNegativeButton(tr("Cancel"), null).show();
        });
    }

    private void infoDialog(String title, String msg) {
        new AlertDialog.Builder(this).setTitle(tr(title)).setMessage(tr(msg)).setPositiveButton(tr("OK"), null).show();
    }

    /* ---- Main settings, same order as UC ---- */

    private void renderSettings(LinearLayout b) {
        b.setPadding(0, 0, 0, dp(24));
        final boolean def = isDefaultBrowser();
        flatRow(b, "Set as Default Browser", null, null, sw(def, v -> openDefaultSettings()), null);
        flatRow(b, "Ads Block Setting", null, null, chev(), this::openAdSettings);
        flatRow(b, "Browsing Settings", null, null, chev(), this::openBrowsingSettings);
        flatRow(b, "Download Settings", null, null, chev(), this::openDownloadSettings);
        flatRow(b, "Notification Settings", null, null, chev(), this::openNotifySettings);
        flatRow(b, "Search Settings", null, null, chev(), this::openSearchSettings);
        flatRow(b, "Social Media Downloader Settings", null, null, chev(), this::openSocialSettings);
        flatRow(b, "Themes", null, null, chev(), this::openThemes);
        flatRow(b, "Homepage Settings", null, null, chev(), this::openHomeSettings);
        flatRow(b, "Night Mode", null, null, sw(store.night(), this::switchNight), null);
        flatRow(b, "Video Settings", null, null, chev(), this::openVideoSettings);
        flatRow(b, "Privacy and Security", null, null, chev(), this::openPrivacySettings);
        choiceRow(b, "Cloud Boost", "Loads saved pages from cache first for faster browsing", "cloudboost", 0, new String[]{"ON", "OFF"}, this::applyAllWebPrefs);
        flatRow(b, "Language", null, "hi".equals(store.lang()) ? "हिन्दी" : "English", chev(), () ->
                new AlertDialog.Builder(this).setTitle(tr("Language"))
                        .setSingleChoiceItems(new String[]{"English", "हिन्दी"}, "hi".equals(store.lang()) ? 1 : 0, (d, which) -> {
                            store.setLang(which == 1 ? "hi" : "en");
                            d.dismiss();
                            recreate();
                        }).show());
        flatRow(b, "Clear Records", null, null, dots(), this::clearRecords);
        flatRow(b, "Account", null, null, chev(), this::showSignIn);
        flatRow(b, "About SR", null, APP_VER, chev(), this::openAbout);

        TextView rs = Ui.text(this, tr("Reset to Default"), 17, pal.fg, false);
        rs.setGravity(Gravity.CENTER);
        rs.setPadding(0, dp(26), 0, dp(26));
        rs.setOnClickListener(v -> confirmReset());
        b.addView(rs, new LinearLayout.LayoutParams(-1, -2));
    }

    /* ---- Ads Block Setting ---- */

    private void openAdSettings() {
        openPanel(tr("Ads Block Setting"), null, null, b -> {
            flatRow(b, "Ad Blocker", null, null, sw(store.adblock(), store::setAdblock), null);
            flagRow(b, "Powerful Ad Blocker", "Block sticky Ads", "ad_power", false, null);
            flagRow(b, "Acceptable Ads", "Non-annoying ads stay visible", "ad_accept", true, null);
            TextView note = Ui.text(this, tr("Acceptable ads are non-annoying ads that follow a strict standard. They help content creators and do not get in the way of what you are viewing. Turn it off to block them too."), 13, pal.muted, false);
            note.setPadding(dp(22), dp(12), dp(22), dp(10));
            b.addView(note);
            flatRow(b, "Ads blocked", null, String.valueOf(store.lng("adcount", 0) + adBlocked), null, null);
            flagRow(b, "Block pop-ups", null, "popup", true, null);
            flagRow(b, "Ad block notice", "Show a short message when an ad redirect is blocked", "ad_toast", true, null);
        });
    }

    /* ---- Browsing Settings ---- */

    private void openBrowsingSettings() {
        openPanel(tr("Browsing Settings"), null, null, b -> {
            flatRow(b, "Font & Layout", null, store.num("zoom", 100) + "%" + (store.num("zoom", 100) == 100 ? "(" + tr("Standard") + ")" : ""), chev(), this::openFontSize);
            choiceRow(b, "Preload Page", "Opens the next page in the background so it loads faster", "preload", 1, new String[]{"Off", "WAP Pages", "All Pages"}, null);
            choiceRow(b, "Tab View", "tabview", 0, new String[]{"Card View", "List View"}, null);
            choiceRow(b, "Image Quality", "imgq", 1, new String[]{"High", "Medium", "Low (no images on mobile data)", "No Image"}, () -> {
                int q = store.num("imgq", 1);
                store.setNum("imgmode", q == 3 ? 1 : q == 2 ? 2 : 0);
                applyAllWebPrefs();
            });
            flagRow(b, "Swipe Forward&Backward", null, "swipe_nav", true, null);
            flagRow(b, "Reopen Tabs on Startup", null, "restore_tabs", true, null);
            choiceRow(b, "Forms and Passwords", "forms_mode", 0, new String[]{"Always ask", "Always save", "Never save"}, () -> {
                store.setFlag("forms", store.num("forms_mode", 0) != 2);
                applyAllWebPrefs();
            });
            flatRow(b, "Scroll Options", null, null, dots(), this::openScrollOptions);
            flatRow(b, "Brightness", null, store.num("bright", -1) < 0 ? tr("Auto") : store.num("bright", -1) + "%", dots(), this::openBrightness);
            flagRow(b, "Animation", null, "anim", true, null);
            flatRow(b, "Show Status Bar", tr("Turn off for full screen browsing"), null, sw(!store.flag("full", false), v -> {
                store.setFlag("full", !v);
                fullscreen = !v;
                applySystemUi();
                applyBars();
            }), null);
            flagRow(b, "Typing Assistant", "Quick keys like www. and .com while typing a link", "typing_assist", true, null);
            flagRow(b, "Change Link Color If Clicked", null, "link_visited", false, null);
            choiceRow(b, "Website Preferences (UA)", "ua", 0, new String[]{"Android (Mobile)", "Desktop (PC)", "iPhone"}, () -> {
                store.setDesktop(store.num("ua", 0) == 1);
                applyAllWebPrefs();
                if (cur != null && !cur.home) cur.web.reload();
            });
            choiceRow(b, "Address bar shows", "bar_text", 0, new String[]{"Page title", "Web address"}, this::updateUrlBar);
            flagRow(b, "Force enable zoom", "Zoom in on any site, even if it blocks zoom", "force_zoom", false, null);
            flagRow(b, "Dark web pages in Night Mode", null, "night_pages", true, null);
            choiceRow(b, "Screen Rotation", "rotate", 0, new String[]{"Auto rotate", "Portrait", "Landscape"}, this::applyWindowPrefs);
            flagRow(b, "Keep screen on", null, "keep_on", false, v -> applyWindowPrefs());
            flagRow(b, "Open new tabs in background", null, "open_bg", false, null);
            flatRow(b, "JavaScript", null, null, sw(store.js(), v -> {
                store.setJs(v);
                applyAllWebPrefs();
            }), null);
            flatRow(b, "Ask before exit", null, null, sw(!store.noAskExit(), v -> store.setNoAskExit(!v)), null);
        });
    }

    private void openScrollOptions() {
        LinearLayout c = ucCard(true);
        c.addView(ucTitle("Scroll Options"));
        final CheckBox vol = ucCheck("Volume keys to scroll page", store.flag("vol_page", false));
        final CheckBox hide = ucCheck("Hide toolbar while scrolling", store.flag("autohide", false));
        final CheckBox top = ucCheck("Show 'back to top' button", store.flag("scroll_top", true));
        c.addView(vol);
        c.addView(hide);
        c.addView(top);
        final Dialog d = ucShow(c, true);
        c.addView(ucBtn("OK", true, v -> {
            store.setFlag("vol_page", vol.isChecked());
            store.setFlag("autohide", hide.isChecked());
            store.setFlag("scroll_top", top.isChecked());
            showBars(true);
            d.dismiss();
            refreshPanel();
        }));
        c.addView(ucBtn("Cancel", false, v -> d.dismiss()));
    }

    /** UC style brightness dialog: slider from moon to sun, Auto, OK / Cancel. */
    private void openBrightness() {
        final int old = store.num("bright", -1);
        LinearLayout c = ucCard(false);
        c.addView(ucTitle("Brightness"));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(Ui.icon(this, R.drawable.ic_moon, 22, pal.icon));
        final android.widget.SeekBar sb = new android.widget.SeekBar(this);
        sb.setMax(100);
        sb.setProgress(old < 0 ? 50 : old);
        sb.setProgressTintList(ColorStateList.valueOf(pal.accent));
        sb.setThumbTintList(ColorStateList.valueOf(pal.accent));
        row.addView(sb, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(Ui.icon(this, R.drawable.ic_sun, 22, pal.icon));
        c.addView(row, new LinearLayout.LayoutParams(-1, dp(56)));
        final CheckBox auto = ucCheck("Auto", old < 0);
        c.addView(auto);
        sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar s, int p, boolean user) {
                if (user) auto.setChecked(false);
                setBrightness(auto.isChecked() ? -1 : Math.max(3, p));
            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar s) {
            }
        });
        auto.setOnCheckedChangeListener((x, on) -> setBrightness(on ? -1 : Math.max(3, sb.getProgress())));
        final Dialog d = ucShow(c, false);
        final boolean[] saved = {false};
        c.addView(ucBtn("OK", true, v -> {
            saved[0] = true;
            store.setNum("bright", auto.isChecked() ? -1 : Math.max(3, sb.getProgress()));
            d.dismiss();
            refreshPanel();
        }));
        c.addView(ucBtn("Cancel", false, v -> d.dismiss()));
        d.setOnDismissListener(x -> {
            if (!saved[0]) setBrightness(old);
        });
    }

    private void setBrightness(int pct) {
        android.view.WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = pct < 0 ? android.view.WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE : pct / 100f;
        getWindow().setAttributes(lp);
    }

    /* ---- Download Settings ---- */

    private void openDownloadSettings() {
        openPanel(tr("Download Settings"), null, null, b -> {
            choiceRow(b, "Default Path", "dl_path", 0, new String[]{"/sdcard/Download", "/sdcard/Download/SRDownloads"}, this::applyDownloadPrefs);
            choiceRow(b, "Max Downloads", "dl_threads", 2, new String[]{"1", "2", "3", "5"}, null);
            flatRow(b, "New Task", null, store.askDownload() ? tr("Always Ask") : tr("Download directly"), dots(), () ->
                    new AlertDialog.Builder(this).setTitle(tr("New Task"))
                            .setSingleChoiceItems(new String[]{tr("Always Ask"), tr("Download directly")}, store.askDownload() ? 0 : 1, (d, w) -> {
                                store.setAskDownload(w == 0);
                                d.dismiss();
                                refreshPanel();
                            }).show());
            flagRow(b, "Auto Reconnect", "Retry when the network drops", "dl_reconnect", true, v -> applyDownloadPrefs());
            flagRow(b, "Notification", "Pulse Light and Notification Sound", "dl_sound", false, v -> applyDownloadPrefs());
            flatRow(b, "Download on Wi-Fi only", null, null, sw(store.wifiOnly(), store::setWifiOnly), null);
            flagRow(b, "Open file when done", null, "dl_autoopen", false, null);
            choiceRow(b, "Default video quality", "vq", 0, new String[]{"Highest", "720P", "480P", "Lowest"}, null);
            flatRow(b, "Open Downloads", null, null, chev(), this::openDownloader);
        });
    }

    private String dlSubDir() {
        return store.num("dl_path", 0) == 1 ? "SRDownloads" : "";
    }

    private void applyDownloadPrefs() {
        Grabber.subDir = dlSubDir();
        Grabber.reconnect = store.flag("dl_reconnect", true);
        Grabber.sound = store.flag("dl_sound", false);
    }

    private int maxDownloads() {
        int[] n = {1, 2, 3, 5};
        return n[Math.max(0, Math.min(3, store.num("dl_threads", 2)))];
    }

    /* ---- Notification Settings ---- */

    private void openNotifySettings() {
        openPanel(tr("Notification Settings"), null, null, b -> {
            flatRow(b, "Push Notification", tr("System Notification Bar"), null, sw(store.dlNotify(), store::setDlNotify), null);
            flagRow(b, "\"Just In\" Notification", "Get alert when surfing", "justin", true, null);
            flatRow(b, "Site Notification", null, null, chev(), () -> infoDialog("Site Notification",
                    "Websites can't send you notifications in S.R Browser, so no site can spam you."));
            flagRow(b, "Quick Access", "Search and Downloads from the notification bar", "quick_access", false, v -> quickAccess(v));
            flatRow(b, "System notification settings", null, null, chev(), () -> {
                try {
                    Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                    i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                    startActivity(i);
                } catch (Exception e) {
                    toast(tr("Could not open notification settings"));
                }
            });
        });
    }

    /** UC style quick search bar in the notification shade. */
    private void quickAccess(boolean on) {
        android.app.NotificationManager nm = (android.app.NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if (!on) {
            nm.cancel(4343);
            return;
        }
        int fl = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent search = PendingIntent.getActivity(this, 41, new Intent(this, MainActivity.class).setAction("sr.SEARCH").addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), fl);
        PendingIntent dls = PendingIntent.getActivity(this, 42, new Intent(this, MainActivity.class).setAction("sr.OPEN_DOWNLOADS").addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), fl);
        android.app.Notification n = Grabber.builder(this)
                .setSmallIcon(android.R.drawable.ic_menu_search)
                .setContentTitle("S.R Browser")
                .setContentText(tr("Tap to search"))
                .setContentIntent(search)
                .setOngoing(true)
                .addAction(new android.app.Notification.Action.Builder(null, tr("Search"), search).build())
                .addAction(new android.app.Notification.Action.Builder(null, tr("Downloads"), dls).build())
                .build();
        nm.notify(4343, n);
    }

    /* ---- Search, social, homepage, video, privacy ---- */

    private void openSearchSettings() {
        openPanel(tr("Search Settings"), null, null, b -> {
            flatRow(b, "Search engine", null, engineName(), chev(), this::pickEngine);
            flatRow(b, "Default search type", null, tr(new String[]{"Web", "Videos", "Images"}[mode]), dots(), () ->
                    new AlertDialog.Builder(this).setTitle(tr("Default search type"))
                            .setSingleChoiceItems(new String[]{tr("Web"), tr("Videos"), tr("Images")}, mode, (d, which) -> {
                                mode = which;
                                store.setSearchMode(which);
                                d.dismiss();
                                refreshHome();
                                refreshPanel();
                            }).show());
            choiceRow(b, "Translate pages to", "tr_lang", 0, new String[]{"Hindi", "English"}, null);
        });
    }

    private void openSocialSettings() {
        openPanel(tr("Social Media Downloader Settings"), null, null, b -> {
            flagRow(b, "Clipboard Link Recognition", null, "clip_suggest", true, null);
            flatRow(b, "Web Page Recognition", null, null, sw(store.detectVideo(), v -> {
                store.setDetectVideo(v);
                updateVideoFab();
            }), null);
        });
    }

    private void openHomeSettings() {
        openPanel(tr("Homepage Settings"), null, null, b -> {
            flatRow(b, "Homepage Colour", tr("Change the colour of the whole homepage"), null, chev(), this::openHomeColors);
            flatRow(b, "Themes and Wallpapers", null, null, chev(), this::openThemes);
            choiceRow(b, "Homepage title", "home_title", 0, new String[]{"Logo", "Name (S.R Browser)", "Logo and Name"}, this::refreshHome);
            flatRow(b, "Quick buttons on home", tr("Downloader, Notes, History, Bookmark"), null,
                    sw(store.showQuick(), v -> {
                        store.setShowQuick(v);
                        refreshHome();
                    }), null);
            flagRow(b, "Web / Videos / Images buttons", null, "home_chips", true, v -> refreshHome());
            flatRow(b, "Show 'Made in India' line", null, null, sw(store.showIndia(), v -> {
                store.setShowIndia(v);
                refreshHome();
            }), null);
            flatRow(b, "Home message", store.homeNote().isEmpty() ? tr("Add your own text under the logo") : store.homeNote(), null, chev(), () -> {
                final EditText e = new EditText(this);
                e.setText(store.homeNote());
                e.setSingleLine(true);
                LinearLayout l = new LinearLayout(this);
                l.setPadding(dp(20), dp(8), dp(20), 0);
                l.addView(e, new LinearLayout.LayoutParams(-1, -2));
                new AlertDialog.Builder(this).setTitle(tr("Home message")).setView(l)
                        .setPositiveButton(tr("Save"), (d, w) -> {
                            store.setHomeNote(e.getText().toString().trim());
                            refreshHome();
                            refreshPanel();
                        }).setNegativeButton(tr("Cancel"), null).show();
            });
            choiceRow(b, "New tab opens", "newtab", 0, new String[]{"Homepage", "Search page"}, null);
        });
    }

    private void openVideoSettings() {
        openPanel(tr("Video Settings"), null, null, b -> {
            flagRow(b, "Background play", "Keep playing sound when you leave the app", "bg_play", false, null);
            flagRow(b, "Small window (PiP)", "Video keeps playing in a small window when you press Home", "pip", true, null);
            flagRow(b, "Autoplay videos", null, "autoplay", true, v -> applyAllWebPrefs());
            flatRow(b, "Web Page Recognition", tr("Show a download button on videos"), null, sw(store.detectVideo(), v -> {
                store.setDetectVideo(v);
                updateVideoFab();
            }), null);
            choiceRow(b, "Default video quality", "vq", 0, new String[]{"Highest", "720P", "480P", "Lowest"}, null);
        });
    }

    private void openPrivacySettings() {
        openPanel(tr("Privacy and Security"), null, null, b -> {
            flatRow(b, "Incognito mode", tr("History is not saved"), null, sw(store.incognito(), v -> {
                store.setIncognito(v);
                updateTabBtn();
            }), null);
            flagRow(b, "Do Not Track", null, "dnt", false, null);
            flagRow(b, "Accept cookies", null, "cookies", true, v -> applyAllWebPrefs());
            flagRow(b, "Third-party cookies", null, "cookies3", true, v -> applyAllWebPrefs());
            choiceRow(b, "Location", "perm_loc", 0, new String[]{"Ask first", "Block"}, null);
            choiceRow(b, "Camera and microphone", "perm_cam", 0, new String[]{"Ask first", "Block"}, null);
            flagRow(b, "Safe Browsing", null, "safe", true, v -> applyAllWebPrefs());
            flagRow(b, "Clear records on exit", null, "clear_exit", false, null);
            flatRow(b, "Clear Records", null, null, dots(), this::clearRecords);
        });
    }

    /* ---- Font & Layout ---- */

    private void openFontSize() {
        LinearLayout c = ucCard(true);
        c.addView(ucTitle("Font & Layout"));
        final TextView prev = Ui.text(this, tr("This is how text on web pages will look."), 16, pal.fg, false);
        prev.setGravity(Gravity.CENTER);
        prev.setPadding(dp(10), dp(10), dp(10), dp(18));
        c.addView(prev);
        final TextView val = Ui.text(this, store.num("zoom", 100) + "%", 15, pal.accent, true);
        val.setGravity(Gravity.CENTER);
        c.addView(val);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(Ui.text(this, "A", 13, pal.muted, true));
        final android.widget.SeekBar sb = new android.widget.SeekBar(this);
        sb.setMax(15);
        sb.setProgress((store.num("zoom", 100) - 50) / 10);
        sb.setProgressTintList(ColorStateList.valueOf(pal.accent));
        sb.setThumbTintList(ColorStateList.valueOf(pal.accent));
        row.addView(sb, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(Ui.text(this, "A", 22, pal.muted, true));
        c.addView(row, new LinearLayout.LayoutParams(-1, dp(48)));
        prev.setTextSize(16f * store.num("zoom", 100) / 100f);
        sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(android.widget.SeekBar s, int p, boolean u) {
                int z = 50 + p * 10;
                val.setText(z + "%");
                prev.setTextSize(16f * z / 100f);
            }

            @Override
            public void onStartTrackingTouch(android.widget.SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(android.widget.SeekBar s) {
                store.setNum("zoom", 50 + s.getProgress() * 10);
                applyAllWebPrefs();
            }
        });
        final CheckBox fit = ucCheck("Auto-fit pages to screen width", store.flag("autofit", true));
        c.addView(fit);
        final Dialog d = ucShow(c, true);
        d.setOnDismissListener(x -> refreshPanel());
        c.addView(ucBtn("Done", true, v -> {
            store.setFlag("autofit", fit.isChecked());
            applyAllWebPrefs();
            d.dismiss();
        }));
        c.addView(ucBtn("Reset", false, v -> {
            sb.setProgress(5);
            store.setNum("zoom", 100);
            applyAllWebPrefs();
        }));
    }

    /* ---- Night mode with UC style day/night city animation ---- */

    private void switchNight(boolean on) {
        if (on == store.night()) return;
        final DayNight dn = new DayNight(this, on);
        dn.setAlpha(0f);
        screen.addView(dn, new FrameLayout.LayoutParams(-1, -1));
        dn.animate().alpha(1f).setDuration(200).start();
        dn.play(store.flag("anim", true) ? 1500 : 300, () -> {
            store.setNight(on);
            store.setFlag("dn_fade", true);
            recreate();
        });
    }

    /** After the screen restarts in the new mode, the city picture fades away. */
    private void finishNightSwitch() {
        if (!store.flag("dn_fade", false)) return;
        store.setFlag("dn_fade", false);
        final DayNight dn = new DayNight(this, store.night());
        dn.at(1f);
        screen.addView(dn, new FrameLayout.LayoutParams(-1, -1));
        dn.animate().alpha(0f).setStartDelay(250).setDuration(450).withEndAction(() -> screen.removeView(dn)).start();
    }

    /* ---- Homepage colour (whole homepage) ---- */

    private static final int[][] HOME_PRESETS = {
            {0xFFFFFFFF, 0xFFFFE9DF}, {0xFF111317, 0xFF3A2410}, {0xFF0F2027, 0xFF2C5364}, {0xFF232526, 0xFF414345},
            {0xFFFF512F, 0xFFDD2476}, {0xFF1D2B64, 0xFFF8CDDA}, {0xFF02AAB0, 0xFF00CDAC}, {0xFF5433FF, 0xFF20BDFF},
            {0xFFFDFC47, 0xFF24FE41}, {0xFFFF9966, 0xFFFF5E62}, {0xFF7F00FF, 0xFFE100FF}, {0xFF000000, 0xFF434343},
            {0xFFE0EAFC, 0xFFCFDEF3}, {0xFFFFEFBA, 0xFFFFFFFF}, {0xFF134E5E, 0xFF71B280}, {0xFFDA4453, 0xFF89216B},
    };

    private static final int[] SWATCHES = {0xFFFFFFFF, 0xFFF5F5F5, 0xFFFFE9DF, 0xFFFFF3C4, 0xFFE3F2FD, 0xFFE8F5E9, 0xFFFCE4EC,
            0xFFE5121B, 0xFFFF6D00, 0xFFFFC107, 0xFF43A047, 0xFF00897B, 0xFF1E88E5, 0xFF3949AB, 0xFF8E24AA, 0xFFD81B60,
            0xFF6D4C41, 0xFF546E7A, 0xFF263238, 0xFF111317, 0xFF000000};

    private void openHomeColors() {
        openPanel(tr("Homepage Colour"), null, null, b -> {
            // live preview
            final FrameLayout prev = new FrameLayout(this);
            prev.setBackground(homeBgDrawable());
            TextView pt = Ui.text(this, "S.R Browser", 26, homeFg(), false);
            pt.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
            prev.addView(pt, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
            prev.setClipToOutline(true);
            prev.setOutlineProvider(android.view.ViewOutlineProvider.BACKGROUND);
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(150));
            pp.setMargins(dp(8), dp(10), dp(8), dp(6));
            b.addView(prev, pp);

            setHead(b, "Ready colours");
            addColorGrid(b, HOME_PRESETS.length, i -> {
                View v = new View(this);
                GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, HOME_PRESETS[i]);
                g.setCornerRadius(dp(12));
                g.setStroke(dp(1), pal.line);
                v.setBackground(g);
                return v;
            }, i -> {
                store.setNum("home_c1", HOME_PRESETS[i][0]);
                store.setNum("home_c2", HOME_PRESETS[i][1]);
                store.setTheme(6);
            });

            setHead(b, "Top colour");
            addColorGrid(b, SWATCHES.length, i -> swatch(SWATCHES[i], store.theme() == 6 && store.num("home_c1", 0) == SWATCHES[i]),
                    i -> {
                        if (store.theme() != 6) store.setNum("home_c2", SWATCHES[i]);
                        store.setNum("home_c1", SWATCHES[i]);
                        store.setTheme(6);
                    });
            setHead(b, "Bottom colour");
            addColorGrid(b, SWATCHES.length, i -> swatch(SWATCHES[i], store.theme() == 6 && store.num("home_c2", 0) == SWATCHES[i]),
                    i -> {
                        if (store.theme() != 6) store.setNum("home_c1", SWATCHES[i]);
                        store.setNum("home_c2", SWATCHES[i]);
                        store.setTheme(6);
                    });
            setHead(b, "Text and icons");
            choiceRow(b, "Text colour", "home_text", 0, new String[]{"Automatic", "White", "Dark"}, this::refreshHome);
            choiceRow(b, "Search box", "home_box", 0, new String[]{"White", "See-through", "Dark"}, this::refreshHome);
            flagRow(b, "Wave pattern", "Soft glowing waves at the bottom, like UC", "home_wave", false, v -> refreshHome());
            flatRow(b, "Back to default colours", null, null, chev(), () -> {
                store.setTheme(0);
                store.setNum("home_text", 0);
                store.setNum("home_box", 0);
                refreshHome();
                refreshPanel();
            });
        });
    }

    interface ViewMaker {
        View make(int i);
    }

    interface IntCb {
        void on(int i);
    }

    private View swatch(int color, boolean on) {
        FrameLayout f = new FrameLayout(this);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        g.setStroke(dp(on ? 3 : 1), on ? pal.accent : pal.line);
        f.setBackground(g);
        if (on) {
            int lum = (Color.red(color) * 3 + Color.green(color) * 6 + Color.blue(color)) / 10;
            f.addView(Ui.icon(this, R.drawable.ic_check, 18, lum > 150 ? 0xFF1A1D23 : Color.WHITE),
                    new FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER));
        }
        return f;
    }

    private void addColorGrid(LinearLayout b, int n, ViewMaker mk, final IntCb pick) {
        int cols = 7;
        for (int i = 0; i < n; i += cols) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(dp(14), 0, dp(14), 0);
            for (int j = 0; j < cols; j++) {
                FrameLayout cell = new FrameLayout(this);
                if (i + j < n) {
                    final int idx = i + j;
                    View v = mk.make(idx);
                    cell.addView(v, new FrameLayout.LayoutParams(dp(36), dp(36), Gravity.CENTER));
                    cell.setOnClickListener(x -> {
                        pick.on(idx);
                        refreshHome();
                        refreshPanel();
                    });
                }
                row.addView(cell, new LinearLayout.LayoutParams(0, dp(48), 1));
            }
            b.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
    }


    private void clearRecords() {
        LinearLayout c = ucCard(false);
        FrameLayout head = new FrameLayout(this);
        TextView t = ucTitle("Clear Records");
        head.addView(t, new FrameLayout.LayoutParams(-1, -2));
        final CheckBox cCookies = ucCheck("Cookies", false);
        final CheckBox cForms = ucCheck("Forms", false);
        final CheckBox cHist = ucCheck("History", true);
        final CheckBox cCache = ucCheck("Cache", true);
        c.addView(head);
        c.addView(cCookies);
        c.addView(cForms);
        c.addView(cHist);
        c.addView(cCache);
        final Dialog d = ucShow(c, false);
        ImageView x = Ui.icon(this, R.drawable.ic_close, 22, pal.muted);
        x.setPadding(dp(2), dp(2), dp(2), dp(2));
        x.setOnClickListener(v -> d.dismiss());
        FrameLayout.LayoutParams xp = new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.TOP | Gravity.END);
        head.addView(x, xp);
        c.addView(ucBtn("Clear", true, v -> {
            if (cCookies.isChecked()) CookieManager.getInstance().removeAllCookies(null);
            if (cForms.isChecked()) WebViewDatabase.getInstance(this).clearFormData();
            if (cHist.isChecked()) {
                store.clear("hist");
                store.clear("vhist");
            }
            if (cCache.isChecked()) for (Tab tb : tabs) tb.web.clearCache(true);
            d.dismiss();
            toast("Cleared");
            refreshPanel();
        }));
        c.addView(ucBtn("Cancel", false, v -> d.dismiss()));
    }

    /**
     * Sign in with Google / Facebook: the real Google or Facebook login page opens inside the browser,
     * so you stay signed in on those sites. When the login finishes, the account shows in User Center.
     */
    private void showSignIn() {
        String acct = store.str("acct", "");
        LinearLayout c = ucCard(true);
        if (!acct.isEmpty()) {
            c.addView(ucTitle("Account"));
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.addView(avatarView(52));
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setPadding(dp(14), 0, 0, 0);
            col.addView(Ui.text(this, accountName(), 17, pal.fg, true));
            col.addView(Ui.text(this, tr("Signed in with") + " " + ("google".equals(acct) ? "Google" : "Facebook"), 13, pal.muted, false));
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
            c.addView(row, new LinearLayout.LayoutParams(-1, -2));
            final Dialog d = ucShow(c, true);
            c.addView(ucBtn("google".equals(acct) ? "Open Google Account" : "Open Facebook", true, v -> {
                d.dismiss();
                closeAllPanels();
                loadIn(newTab(), "google".equals(acct) ? "https://myaccount.google.com/" : "https://m.facebook.com/me");
            }));
            c.addView(ucBtn("Edit name", false, v -> {
                d.dismiss();
                final EditText e = new EditText(this);
                e.setText(accountName());
                LinearLayout l = new LinearLayout(this);
                l.setPadding(dp(20), dp(8), dp(20), 0);
                l.addView(e, new LinearLayout.LayoutParams(-1, -2));
                new AlertDialog.Builder(this).setTitle(tr("Your name")).setView(l)
                        .setPositiveButton(tr("Save"), (x, w) -> store.setStr("acct_name", e.getText().toString().trim()))
                        .setNegativeButton(tr("Cancel"), null).show();
            }));
            c.addView(ucBtn("Sign out", false, v -> {
                d.dismiss();
                signOut();
            }));
            return;
        }
        c.addView(ucTitle("Sign in"));
        final Dialog d = ucShow(c, true);
        c.addView(loginBtn("Sign in with Facebook", 0xFF1877F2, "f", () -> {
            d.dismiss();
            startLogin("facebook", "https://m.facebook.com/login.php?next=https%3A%2F%2Fm.facebook.com%2Fme");
        }));
        c.addView(loginBtn("Sign in with Google", 0xFFFFFFFF, "G", () -> {
            d.dismiss();
            startLogin("google", "https://accounts.google.com/ServiceLogin?continue=https%3A%2F%2Fmyaccount.google.com%2F");
        }));
        TextView note = Ui.text(this, tr("By signing in, you agree with our Privacy Policy and Terms of Use"), 12.5f, pal.muted, false);
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, dp(18), 0, dp(6));
        c.addView(note);
    }

    private View loginBtn(String label, int color, String letter, final Runnable r) {
        LinearLayout b = new LinearLayout(this);
        b.setOrientation(LinearLayout.HORIZONTAL);
        b.setGravity(Gravity.CENTER);
        boolean white = color == 0xFFFFFFFF;
        GradientDrawable g = Ui.round(this, color, 28);
        if (white) g.setStroke(dp(1), pal.line);
        b.setBackground(g);
        TextView ic = Ui.text(this, letter, 18, white ? 0xFF4285F4 : Color.WHITE, true);
        ic.setGravity(Gravity.CENTER);
        ic.setBackground(oval(white ? 0xFFF1F3F4 : 0x33FFFFFF));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(30), dp(30));
        ip.rightMargin = dp(12);
        b.addView(ic, ip);
        b.addView(Ui.text(this, tr(label), 16.5f, white ? 0xFF1A1D23 : Color.WHITE, true));
        b.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(54));
        lp.topMargin = dp(12);
        b.setLayoutParams(lp);
        return b;
    }

    private String pendingLogin = "";
    private volatile long blobAsked = 0;

    private void startLogin(String which, String url) {
        if (store.incognito()) {
            toast(tr("Turn off incognito mode to sign in"));
            return;
        }
        pendingLogin = which;
        closeAllPanels();
        Tab nt = newTab();
        loadIn(nt, url);
        toast(tr("Sign in on this page"));
    }

    /** Called when a page finishes: completes a pending Google / Facebook sign-in. */
    private void checkLogin(final Tab t, String url) {
        if (pendingLogin.isEmpty() || url == null) return;
        String h = Uri.parse(url).getHost();
        if (h == null) return;
        if ("google".equals(pendingLogin) && h.equals("myaccount.google.com")) {
            pendingLogin = "";
            t.web.evaluateJavascript("(function(){var m=(document.body?document.body.innerText:'').match(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[a-z]{2,}/);return m?m[0]:''})()", v -> {
                String email = v == null ? "" : v.replace("\"", "").trim();
                finishLogin("google", email);
            });
        } else if ("facebook".equals(pendingLogin) && h.endsWith("facebook.com")) {
            String ck = CookieManager.getInstance().getCookie("https://m.facebook.com");
            if (ck != null && ck.contains("c_user=") && !url.contains("login")) {
                pendingLogin = "";
                String name = t.title == null ? "" : t.title.replace("| Facebook", "").replace("Facebook", "").trim();
                finishLogin("facebook", name);
            }
        }
    }

    private void finishLogin(String which, String name) {
        CookieManager.getInstance().flush();
        store.setStr("acct", which);
        store.setStr("acct_name", name == null || name.isEmpty() || name.equals("null") ? ("google".equals(which) ? "Google User" : "Facebook User") : name);
        snack(tr("Signed in") + ": " + accountName(), null, null);
    }

    private String accountName() {
        String n = store.str("acct_name", "");
        return n.isEmpty() ? tr("User Center") : n;
    }

    private void signOut() {
        String acct = store.str("acct", "");
        store.setStr("acct", "");
        store.setStr("acct_name", "");
        new AlertDialog.Builder(this).setTitle(tr("Signed out"))
                .setMessage(tr("Also sign out of the website itself? This removes its saved login on this phone."))
                .setPositiveButton(tr("Yes"), (d, w) -> {
                    CookieManager cm = CookieManager.getInstance();
                    String[] urls = "google".equals(acct)
                            ? new String[]{"https://accounts.google.com", "https://www.google.com", "https://myaccount.google.com", "https://google.com"}
                            : new String[]{"https://m.facebook.com", "https://www.facebook.com", "https://facebook.com"};
                    for (String u : urls) {
                        String ck = cm.getCookie(u);
                        if (ck == null) continue;
                        for (String part : ck.split(";")) {
                            String k = part.split("=")[0].trim();
                            String dom = Uri.parse(u).getHost();
                            cm.setCookie(u, k + "=; Expires=Thu, 01 Jan 1970 00:00:00 GMT");
                            if (dom != null) cm.setCookie(u, k + "=; Domain=." + dom.replaceFirst("^(www|m|accounts|myaccount)\\.", "") + "; Expires=Thu, 01 Jan 1970 00:00:00 GMT");
                        }
                    }
                    cm.flush();
                    toast(tr("Signed out"));
                }).setNegativeButton(tr("No"), null).show();
    }

    private View avatarView(int sizeDp) {
        FrameLayout av = new FrameLayout(this);
        String acct = store.str("acct", "");
        if (acct.isEmpty()) {
            av.setBackground(Ui.round(this, 0xFFFFFFFF, 14));
            av.setPadding(dp(5), dp(5), dp(5), dp(5));
            ImageView ai = new ImageView(this);
            ai.setImageResource(R.drawable.logo);
            ai.setScaleType(ImageView.ScaleType.FIT_CENTER);
            av.addView(ai, new FrameLayout.LayoutParams(-1, -1));
        } else {
            av.setBackground(oval("google".equals(acct) ? 0xFF4285F4 : 0xFF1877F2));
            String n = accountName();
            TextView l = Ui.text(this, n.isEmpty() ? "?" : n.substring(0, 1).toUpperCase(), sizeDp * 0.42f, Color.WHITE, true);
            l.setGravity(Gravity.CENTER);
            av.addView(l, new FrameLayout.LayoutParams(-1, -1));
        }
        av.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        return av;
    }

    private void openAbout() {
        openPanel(tr("About SR"), null, null, b -> {
            LinearLayout head = new LinearLayout(this);
            head.setOrientation(LinearLayout.VERTICAL);
            head.setGravity(Gravity.CENTER_HORIZONTAL);
            head.setPadding(dp(24), dp(28), dp(24), dp(8));
            ImageView lg = new ImageView(this);
            lg.setImageResource(R.drawable.intro_logo);
            lg.setScaleType(ImageView.ScaleType.FIT_CENTER);
            head.addView(lg, new LinearLayout.LayoutParams(dp(130), dp(130)));
            TextView nm = Ui.text(this, "S.R Browser", 24, pal.fg, true);
            nm.setPadding(0, dp(10), 0, 0);
            head.addView(nm);
            TextView ver = Ui.text(this, "Version " + APP_VER.substring(1), 14, pal.muted, false);
            ver.setPadding(0, dp(2), 0, dp(10));
            head.addView(ver);
            TextView tg = Ui.text(this, "Fast. Simple. Made in India.", 15, pal.accent, true);
            tg.setGravity(Gravity.CENTER);
            head.addView(tg);

            // Founder card
            LinearLayout fcard = new LinearLayout(this);
            fcard.setOrientation(LinearLayout.HORIZONTAL);
            fcard.setGravity(Gravity.CENTER_VERTICAL);
            fcard.setPadding(dp(16), dp(14), dp(18), dp(14));
            GradientDrawable fg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xFFFF4B2B, 0xFFE5121B});
            fg.setCornerRadius(dp(18));
            fcard.setBackground(fg);
            fcard.setElevation(dp(3));
            FrameLayout fa = new FrameLayout(this);
            fa.setBackground(oval(0x33FFFFFF));
            TextView fl = Ui.text(this, "AY", 18, Color.WHITE, true);
            fl.setGravity(Gravity.CENTER);
            fa.addView(fl, new FrameLayout.LayoutParams(-1, -1));
            LinearLayout.LayoutParams fap = new LinearLayout.LayoutParams(dp(50), dp(50));
            fap.rightMargin = dp(14);
            fcard.addView(fa, fap);
            LinearLayout fcol = new LinearLayout(this);
            fcol.setOrientation(LinearLayout.VERTICAL);
            fcol.addView(Ui.text(this, tr("Founder & Developer"), 12.5f, 0xDDFFFFFF, false));
            fcol.addView(Ui.text(this, "Anil Yadav", 21, Color.WHITE, true));
            fcol.addView(Ui.text(this, "S.R Mobile Shop, Thane", 12.5f, 0xDDFFFFFF, false));
            fcard.addView(fcol, new LinearLayout.LayoutParams(0, -2, 1));
            TextView flag = Ui.text(this, "\uD83C\uDDEE\uD83C\uDDF3", 26, Color.WHITE, false);
            fcard.addView(flag);
            LinearLayout.LayoutParams fcp = new LinearLayout.LayoutParams(-1, -2);
            fcp.topMargin = dp(18);
            head.addView(fcard, fcp);
            TextView ds = Ui.text(this, "A fast, light and private browser for everyday use. Search, watch, download and shop without ads getting in your way.", 15, pal.muted, false);
            ds.setGravity(Gravity.CENTER);
            ds.setPadding(0, dp(14), 0, 0);
            head.addView(ds);
            b.addView(head);

            b.addView(sectionTitle("What you get"));
            String[] feats = {
                    "Ad and pop-up blocker",
                    "Video detector and downloader",
                    "Multiple tabs and incognito mode",
                    "Night mode, themes and wallpapers",
                    "Bookmarks, history and notes",
                    "Speed Mode, screenshot and find in page",
                    "Desktop site and full screen mode"
            };
            LinearLayout fc = new LinearLayout(this);
            fc.setOrientation(LinearLayout.VERTICAL);
            fc.setPadding(dp(16), dp(10), dp(16), dp(10));
            fc.setBackground(Ui.round(this, pal.surface2, 16));
            for (String f : feats) {
                TextView t = Ui.text(this, "\u2713  " + f, 15, pal.fg, false);
                t.setPadding(0, dp(5), 0, dp(5));
                fc.addView(t);
            }
            LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
            fp.setMargins(dp(20), 0, dp(20), dp(10));
            b.addView(fc, fp);

            flatRow(b, "Feedback", null, null, chev(), this::feedback);
            flatRow(b, "Check Update", null, APP_VER, null, () -> toast("You're using the latest version"));
            flatRow(b, "Join UX Improvement Program", null, null, sw(store.ux(), store::setUx), null);

            TextView ft = Ui.text(this, "Made with \u2665 in India by Anil Yadav\n\u00a9 2026 S.R Browser. All rights reserved.", 13, pal.muted, false);
            ft.setGravity(Gravity.CENTER);
            ft.setPadding(0, dp(24), 0, dp(32));
            b.addView(ft, new LinearLayout.LayoutParams(-1, -2));
        });
    }

    private void confirmReset() {
        LinearLayout c = ucCard(false);
        c.addView(ucTitle("Reset to Default"));
        TextView n = Ui.text(this, "All settings will go back to default. Bookmarks, history and notes are kept.", 15, pal.muted, false);
        n.setGravity(Gravity.CENTER);
        c.addView(n);
        final Dialog d = ucShow(c, false);
        c.addView(ucBtn("Reset", true, v -> {
            d.dismiss();
            store.resetSettings();
            recreate();
        }));
        c.addView(ucBtn("Cancel", false, v -> d.dismiss()));
    }
}
