package com.sr.browser;

/** Colour palette: light (default, like UC) or night. Accent red comes from the SR logo. */
final class Pal {
    static final int RED = 0xFFE5121B;

    final boolean night;
    final int bg, bar, surface, surface2, line, fg, muted, accent, onAccent, sheet, icon;

    final boolean incognito;

    Pal(boolean night) {
        this(night, false);
    }

    /** Incognito uses a deep purple theme, like UC. */
    Pal(boolean night, boolean incognito) {
        this.incognito = incognito;
        this.night = night || incognito;
        accent = incognito ? 0xFF8B6CFF : RED;
        onAccent = 0xFFFFFFFF;
        if (incognito) {
            bg = 0xFF110E1C;
            bar = 0xFF181326;
            surface = 0xFF211A33;
            surface2 = 0xFF2B2340;
            line = 0xFF372E50;
            fg = 0xFFEEEAF8;
            muted = 0xFF9D94B8;
            sheet = 0xFF1D172C;
            icon = 0xFFD8D2EA;
        } else if (night) {
            bg = 0xFF0F1115;
            bar = 0xFF171A20;
            surface = 0xFF1B1F27;
            surface2 = 0xFF252A34;
            line = 0xFF2E3440;
            fg = 0xFFF2F4F8;
            muted = 0xFF8E96A6;
            sheet = 0xFF1A1D24;
            icon = 0xFFD3D8E2;
        } else {
            bg = 0xFFF7F9FC;
            bar = 0xFFFFFFFF;
            surface = 0xFFFFFFFF;
            surface2 = 0xFFF0F2F6;
            line = 0xFFE4E7EE;
            fg = 0xFF1A1D23;
            muted = 0xFF8A90A0;
            sheet = 0xFFF6F7FA;
            icon = 0xFF3B4150;
        }
    }
}
