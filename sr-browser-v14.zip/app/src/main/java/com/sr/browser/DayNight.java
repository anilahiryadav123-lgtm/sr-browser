package com.sr.browser;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

import java.util.Random;

/**
 * UC style night mode switch: a city skyline where the sky turns from day (sun glow, birds)
 * to night (stars, shooting star), or the other way round. Drawn fully in code.
 */
final class DayNight extends View {

    interface End {
        void done();
    }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path back = new Path(), front = new Path();
    private final float[][] stars = new float[38][3];
    private final boolean toNight;
    private float t; // 0 = start, 1 = end
    private final float dens;

    DayNight(Context c, boolean toNight) {
        super(c);
        this.toNight = toNight;
        dens = c.getResources().getDisplayMetrics().density;
        Random r = new Random(7);
        for (float[] s : stars) {
            s[0] = r.nextFloat();
            s[1] = r.nextFloat() * 0.5f;
            s[2] = 0.8f + r.nextFloat() * 1.8f;
        }
    }

    void at(float v) {
        t = v;
        invalidate();
    }

    void play(long ms, final End end) {
        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(ms);
        a.setInterpolator(new AccelerateDecelerateInterpolator());
        a.addUpdateListener(x -> {
            t = (float) x.getAnimatedValue();
            invalidate();
        });
        a.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(android.animation.Animator an) {
                if (end != null) end.done();
            }
        });
        a.start();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        float base = h * 0.54f;
        skyline(back, w, base, new float[]{.05f, .4f, .09f, .55f, .16f, .3f, .24f, .62f, .33f, .7f, .45f, .5f, .5f, .66f, .6f, .48f, .7f, .42f, .82f, .52f, .92f, .38f, 1f, .3f}, h);
        skyline(front, w, base + h * 0.04f, new float[]{.03f, .22f, .1f, .35f, .13f, .2f, .22f, .48f, .27f, .18f, .36f, .26f, .46f, .3f, .55f, .2f, .62f, .32f, .7f, .24f, .8f, .36f, .88f, .22f, 1f, .28f}, h);
    }

    /** Builds a blocky city outline from pairs of (x end, building height). */
    private void skyline(Path path, float w, float base, float[] b, float h) {
        path.reset();
        path.moveTo(0, h);
        path.lineTo(0, base);
        float x = 0;
        for (int i = 0; i < b.length; i += 2) {
            float nx = b[i] * w, top = base - b[i + 1] * h * 0.16f;
            path.lineTo(x, top);
            path.lineTo(nx, top);
            path.lineTo(nx, base);
            x = nx;
        }
        path.lineTo(w, base);
        path.lineTo(w, h);
        path.close();
    }

    private static int mix(int a, int b, float f) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return Color.rgb((int) (ar + (br - ar) * f), (int) (ag + (bg - ag) * f), (int) (ab + (bb - ab) * f));
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        if (w == 0) return;
        float n = toNight ? t : 1f - t; // how "night" it is
        float base = h * 0.54f;

        // Sky
        int top = mix(0xFFA9DCD3, 0xFF141821, n), mid = mix(0xFFE9F3CF, 0xFF26405F, n), low = mix(0xFFFFF7D0, 0xFF3E6BA0, n);
        p.setShader(new LinearGradient(0, 0, 0, base, new int[]{top, mid, low}, new float[]{0f, 0.65f, 1f}, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, w, base + 2, p);
        p.setShader(null);

        // Sun glow (day)
        if (n < 0.9f) {
            float a = 1f - n;
            float gy = base - h * 0.03f + n * h * 0.1f;
            p.setShader(new RadialGradient(w * 0.5f, gy, w * 0.45f, Color.argb((int) (190 * a), 255, 252, 220), 0x00FFFCDC, Shader.TileMode.CLAMP));
            cv.drawCircle(w * 0.5f, gy, w * 0.45f, p);
            p.setShader(null);
            // birds
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(1.4f * dens);
            p.setColor(Color.argb((int) (150 * a), 120, 130, 120));
            float[][] birds = {{0.6f, 0.45f, 1.4f}, {0.68f, 0.43f, 1f}, {0.53f, 0.475f, 0.8f}, {0.72f, 0.5f, 0.8f}};
            for (float[] bd : birds) {
                float bx = bd[0] * w, by = bd[1] * h, s = 9 * dens * bd[2];
                cv.drawLine(bx - s, by - s * 0.3f, bx, by, p);
                cv.drawLine(bx, by, bx + s, by - s * 0.4f, p);
            }
            p.setStyle(Paint.Style.FILL);
        }

        // Stars + shooting star (night)
        if (n > 0.15f) {
            float a = (n - 0.15f) / 0.85f;
            p.setColor(Color.argb((int) (230 * a), 255, 255, 255));
            for (float[] s : stars) cv.drawCircle(s[0] * w, s[1] * h, s[2] * dens, p);
            float sx = w * 0.62f - w * 0.22f * a, sy = h * 0.3f + h * 0.04f * a;
            p.setStrokeWidth(2f * dens);
            p.setShader(new LinearGradient(sx, sy, sx + w * 0.18f, sy - h * 0.035f, Color.argb((int) (255 * a), 255, 255, 255), 0x00FFFFFF, Shader.TileMode.CLAMP));
            cv.drawLine(sx, sy, sx + w * 0.18f, sy - h * 0.035f, p);
            p.setShader(null);
        }

        // City
        p.setColor(mix(0xFFD9CE96, 0xFF1F3260, n));
        cv.drawPath(back, p);
        p.setColor(mix(0xFF323739, 0xFF1C1D20, n));
        cv.drawPath(front, p);
    }
}
