package com.sr.browser;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Settings and small lists (history, bookmarks, videos, downloads, notes). */
final class Store {
    static final class Item {
        final String title;
        final String url;
        final long time;

        Item(String t, String u) {
            this(t, u, 0);
        }

        Item(String t, String u, long time) {
            title = t;
            url = u;
            this.time = time;
        }
    }

    private final SharedPreferences p;

    Store(Context c) {
        p = c.getSharedPreferences("sr", Context.MODE_PRIVATE);
    }

    private boolean b(String k, boolean d) { return p.getBoolean(k, d); }
    private void put(String k, boolean v) { p.edit().putBoolean(k, v).apply(); }

    String engine() { return p.getString("engine", "google"); }
    void setEngine(String v) { p.edit().putString("engine", v).apply(); }

    boolean night() { return b("night2", false); }
    void setNight(boolean v) { put("night2", v); }

    boolean incognito() { return b("incog", false); }
    void setIncognito(boolean v) { put("incog", v); }

    boolean desktop() { return b("desktop", false); }
    void setDesktop(boolean v) { put("desktop", v); }

    boolean welcomed() { return b("welcomed", false); }
    void setWelcomed(boolean v) { put("welcomed", v); }

    boolean adblock() { return b("adblock", true); }
    void setAdblock(boolean v) { put("adblock", v); }

    boolean popupBlock() { return b("popup", true); }
    void setPopupBlock(boolean v) { put("popup", v); }

    boolean dataSaver() { return b("saver", false); }
    void setDataSaver(boolean v) { put("saver", v); }

    boolean js() { return b("js", true); }
    void setJs(boolean v) { put("js", v); }

    boolean askDownload() { return b("askdl", true); }
    void setAskDownload(boolean v) { put("askdl", v); }

    boolean wifiOnly() { return b("wifionly", false); }
    void setWifiOnly(boolean v) { put("wifionly", v); }

    boolean dlNotify() { return b("dlnotify", true); }
    void setDlNotify(boolean v) { put("dlnotify", v); }

    boolean detectVideo() { return b("vdetect", true); }
    void setDetectVideo(boolean v) { put("vdetect", v); }

    boolean showQuick() { return b("quick", true); }
    void setShowQuick(boolean v) { put("quick", v); }

    boolean showIndia() { return b("india", true); }
    void setShowIndia(boolean v) { put("india", v); }

    int textSize() { return p.getInt("size", 1); }
    void setTextSize(int v) { p.edit().putInt("size", v).apply(); }

    int theme() { return p.getInt("theme", 0); }
    void setTheme(int v) { p.edit().putInt("theme", v).apply(); }

    int searchMode() { return p.getInt("smode", 0); }
    void setSearchMode(int v) { p.edit().putInt("smode", v).apply(); }

    String lang() { return p.getString("lang", "en"); }
    void setLang(String v) { p.edit().putString("lang", v).apply(); }

    String homeNote() { return p.getString("note", ""); }
    void setHomeNote(String v) { p.edit().putString("note", v).apply(); }

    List<Item> list(String key) {
        List<Item> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p.getString(key, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Item(o.optString("t"), o.optString("u"), o.optLong("d", 0)));
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private void save(String key, List<Item> l) {
        JSONArray a = new JSONArray();
        for (Item it : l) {
            try {
                JSONObject o = new JSONObject();
                o.put("t", it.title);
                o.put("u", it.url);
                if (it.time > 0) o.put("d", it.time);
                a.put(o);
            } catch (Exception ignored) {
            }
        }
        p.edit().putString(key, a.toString()).apply();
    }

    void add(String key, String title, String url, int max, boolean front) {
        List<Item> l = list(key);
        for (int i = l.size() - 1; i >= 0; i--) {
            if (l.get(i).url.equals(url)) l.remove(i);
        }
        long now = System.currentTimeMillis();
        if (front) l.add(0, new Item(title, url, now));
        else l.add(new Item(title, url, now));
        while (l.size() > max) l.remove(front ? l.size() - 1 : 0);
        save(key, l);
    }

    void replace(String key, int idx, String title, String url) {
        List<Item> l = list(key);
        if (idx >= 0 && idx < l.size()) {
            l.set(idx, new Item(title, url, l.get(idx).time));
            save(key, l);
        }
    }

    void remove(String key, int idx) {
        List<Item> l = list(key);
        if (idx >= 0 && idx < l.size()) {
            l.remove(idx);
            save(key, l);
        }
    }

    void clear(String key) {
        p.edit().remove(key).apply();
    }

    boolean splashDone() { return b("splashdone", false); }
    void setSplashDone(boolean v) { put("splashdone", v); }

    boolean noAskExit() { return b("noexit", false); }
    void setNoAskExit(boolean v) { put("noexit", v); }

    boolean ux() { return b("ux", true); }
    void setUx(boolean v) { put("ux", v); }

    /* Generic settings used by the UC style settings screens. */
    boolean flag(String k, boolean d) { return p.getBoolean(k, d); }
    void setFlag(String k, boolean v) { put(k, v); }
    int num(String k, int d) { return p.getInt(k, d); }
    void setNum(String k, int v) { p.edit().putInt(k, v).apply(); }
    long lng(String k, long d) { return p.getLong(k, d); }
    void setLng(String k, long v) { p.edit().putLong(k, v).apply(); }
    String str(String k, String d) { return p.getString(k, d); }
    void setStr(String k, String v) { p.edit().putString(k, v).apply(); }

    private static final java.util.Set<String> KEEP = new java.util.HashSet<>(java.util.Arrays.asList(
            "bm", "hist", "vhist", "dl", "wl", "notes", "vid", "welcomed", "splashdone", "dlseq", "adcount", "savedtabs"));

    /** Back to default settings; bookmarks, history, downloads and notes stay. */
    void resetSettings() {
        SharedPreferences.Editor e = p.edit();
        for (String k : p.getAll().keySet()) if (!KEEP.contains(k)) e.remove(k);
        e.putBoolean("welcomed", true);
        e.apply();
    }

    void resetAll() {
        p.edit().clear().apply();
    }
}
