# S.R Browser

UC Browser jaisa mobile browser home: Enter URL bar, Search, top sites grid, 2-page menu
(Bookmarks, History, Refresh, Full Screen, Add-ons, My Videos, Downloads, Exit, Settings, Night Mode,
Incognito, Text Size, Clear Records, Share, Add Site, About) aur Settings screen.

## Phone par chalana (GitHub Pages)

1. GitHub par naya repository banao (jaise `sr-browser`).
2. Is zip ki saari files repository mein upload karo (`index.html` root mein rahe).
3. Repository > Settings > Pages > Source: `Deploy from a branch` > `main` / `/ (root)` > Save.
4. 1-2 minute baad `https://<aapka-username>.github.io/sr-browser/` khulega.
5. Phone ke Chrome mein kholo > menu > **Add to Home screen**. Ab ye S.R Browser app ki tarah khulega.

## Asli logo lagana

Google ya kisi site ke official logo yahan rakho, code badalne ki zarurat nahi:

- Home ke upar ka logo: `assets/engines/google.png` (aur `bing.png`, `ddg.png`, `yahoo.png`)
- Site tile ke icon: `assets/icons/<id>.png` (square, 192x192 theek hai)

Tile ids: `yt` YouTube, `fb` Facebook, `ig` Instagram, `wa` WhatsApp, `tg` Telegram,
`wk` Wikipedia, `am` Amazon, `fk` Flipkart, `gg` Google.

Agar file nahi milti to app apne bane hue simple icons dikhata hai.

## Files

- `index.html`, `style.css`, `app.js`: poora app
- `manifest.json`, `sw.js`: install karne aur offline chalne ke liye
- `assets/`: S.R logo aur icons

## Limits

Ye browser web page hai, isliye sites phone ke browser ke naye tab mein khulti hain. Video
ya download usi browser mein hota hai. App ke andar apna tab engine, video player ya ad block
chahiye to Android project (WebView) alag se banana padega.
