// Small offline cache so S.R Browser opens fast and works without network (home screen, menu, settings).
var CACHE = 'sr-browser-v1';
var FILES = ['./', 'index.html', 'style.css', 'app.js', 'manifest.json', 'assets/icon-192.png', 'assets/icon-512.png'];
self.addEventListener('install', function (e) { e.waitUntil(caches.open(CACHE).then(function (c) { return c.addAll(FILES); })); self.skipWaiting(); });
self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (keys) { return Promise.all(keys.filter(function (k) { return k !== CACHE; }).map(function (k) { return caches.delete(k); })); }));
});
self.addEventListener('fetch', function (e) {
  if (e.request.method !== 'GET' || new URL(e.request.url).origin !== location.origin) return;
  e.respondWith(fetch(e.request).then(function (r) { var c = r.clone(); caches.open(CACHE).then(function (ch) { ch.put(e.request, c); }); return r; }).catch(function () { return caches.match(e.request); }));
});
