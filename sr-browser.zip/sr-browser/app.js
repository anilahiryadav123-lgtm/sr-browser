(function () {
  'use strict';

  /* ---------- Icons (line style, like UC's menu) ---------- */
  function svg(p) { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>'; }
  var ICON = {
    star: svg('<path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.9-5.2-2.8-5.2 2.8 1-5.9-4.3-4.1 5.9-.8z"/>'),
    starplus: svg('<path d="M11 4l2 4.2 4.6.7-3.3 3.2.8 4.6L11 14.5l-4.1 2.2.8-4.6L4.4 8.9 9 8.2z"/><path d="M19 15v6M16 18h6"/>'),
    clock: svg('<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>'),
    refresh: svg('<path d="M20 12a8 8 0 1 1-2.6-5.9"/><path d="M20 4v5h-5"/>'),
    full: svg('<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5M4.5 4.5L10 10M19.5 4.5L14 10M4.5 19.5L10 14M19.5 19.5L14 14"/>'),
    addons: svg('<rect x="4" y="4" width="6.5" height="6.5" rx="1"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1"/><rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1"/><path d="M16.75 4v6.5M13.5 7.25H20"/>'),
    video: svg('<rect x="3.5" y="4.5" width="17" height="15" rx="2"/><path d="M10 9l5 3-5 3z"/>'),
    download: svg('<rect x="3.5" y="4" width="17" height="16" rx="2"/><path d="M12 8v7M8.8 12.2L12 15.4l3.2-3.2"/>'),
    power: svg('<path d="M12 3.5v8"/><path d="M7 6.3a8 8 0 1 0 10 0"/>'),
    gear: svg('<circle cx="12" cy="12" r="3"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M5.6 18.4l1.8-1.8M16.6 7.4l1.8-1.8"/>'),
    moon: svg('<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>'),
    mask: svg('<circle cx="7.5" cy="14.5" r="3.2"/><circle cx="16.5" cy="14.5" r="3.2"/><path d="M10.7 14.5h2.6M4.3 14.5L6 7h12l1.7 7.5"/>'),
    aa: '<svg viewBox="0 0 24 24" aria-hidden="true"><text x="1.5" y="18" font-size="15" font-weight="600" fill="currentColor" font-family="system-ui,sans-serif">Aa</text></svg>',
    trash: svg('<path d="M5 7h14M10 7V4.5h4V7M7 7l1 12.5h8L17 7"/>'),
    info: svg('<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.8v.2"/>'),
    share: svg('<circle cx="6" cy="12" r="2.3"/><circle cx="17.5" cy="6" r="2.3"/><circle cx="17.5" cy="18" r="2.3"/><path d="M8 11l7.5-4M8 13l7.5 4"/>'),
    chevron: svg('<path d="M5 9l7 7 7-7"/>'),
    back: svg('<path d="M15 5l-7 7 7 7"/>'),
    search: svg('<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>'),
    plus: svg('<path d="M12 5v14M5 12h14"/>'),
    globe: svg('<circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.5 2.5 3.5 5.3 3.5 8.5s-1 6-3.5 8.5c-2.5-2.5-3.5-5.3-3.5-8.5s1-6 3.5-8.5z"/>'),
    translate: svg('<path d="M4 6h9M8.5 4v2M6 6c.6 3 2.4 5.2 5 6.5M12 6c-.7 3-3 5.5-6.5 7M12.5 20l4-9 4 9M13.8 17h5.4"/>'),
    map: svg('<path d="M12 21s6.5-5.6 6.5-11a6.5 6.5 0 1 0-13 0C5.5 15.4 12 21 12 21z"/><circle cx="12" cy="10" r="2.3"/>'),
    news: svg('<rect x="4" y="4.5" width="16" height="15" rx="2"/><path d="M8 9h8M8 12.5h8M8 16h5"/>'),
    sun: svg('<circle cx="12" cy="12" r="3.8"/><path d="M12 3.5v2M12 18.5v2M3.5 12h2M18.5 12h2M6 6l1.4 1.4M16.6 16.6L18 18M6 18l1.4-1.4M16.6 7.4L18 6"/>'),
    ball: svg('<circle cx="12" cy="12" r="8.5"/><path d="M5.5 7.5c3 1.5 5 4 6.5 9M18.5 7.5c-3 1.5-5 4-6.5 9"/>')
  };
  function paintIcons(root) {
    (root || document).querySelectorAll('[data-i]').forEach(function (el) { el.innerHTML = ICON[el.dataset.i] || ''; });
  }

  /* ---------- Site tiles: own simple glyphs, optional real logos from assets/icons/<id>.png ---------- */
  function g(p, fill) { return '<svg viewBox="0 0 24 24" fill="' + (fill || 'none') + '" stroke="' + (fill ? 'none' : 'currentColor') + '" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + p + '</svg>'; }
  var DEFAULT_SITES = [
    { id: 'yt', n: 'YouTube', u: 'https://m.youtube.com', bg: '#e62117', h: g('<rect x="2.5" y="5.5" width="19" height="13" rx="4" fill="#fff" stroke="none"/><path d="M10 9.3v5.4l4.8-2.7z" fill="#e62117" stroke="none"/>') },
    { id: 'fb', n: 'Facebook', u: 'https://m.facebook.com', bg: '#1877f2', h: '<span class="glyph-t" style="font-size:2.2rem;margin-top:6px">f</span>' },
    { id: 'ig', n: 'Instagram', u: 'https://www.instagram.com', bg: 'linear-gradient(45deg,#fdb53c,#f0443d 45%,#c32aa3 75%,#6a3de8)', h: g('<rect x="4" y="4" width="16" height="16" rx="5"/><circle cx="12" cy="12" r="3.7"/><circle cx="16.8" cy="7.2" r=".7" fill="currentColor"/>') },
    { id: 'wa', n: 'WhatsApp', u: 'https://web.whatsapp.com', bg: '#25b45a', h: g('<path d="M4.5 19.5l1.2-4A8 8 0 1 1 8.7 18.5z"/><path d="M9.4 8.6c0 3.2 2.3 5.6 5.5 5.6l1-1.4-1.9-.9-.7.7a3.6 3.6 0 0 1-2-2l.7-.7-.9-1.9z"/>') },
    { id: 'tg', n: 'Telegram', u: 'https://web.telegram.org', bg: '#2a9bd8', h: g('<path d="M20.6 4.2L3.4 10.8c-.8.3-.8 1.4 0 1.6l4.3 1.4 1.7 5.3c.2.7 1.1.9 1.6.4l2.4-2.3 4.4 3.2c.6.4 1.4.1 1.6-.6l2.9-14c.2-.9-.7-1.6-1.7-1.6zM9 13.4l8.2-5.1-6.4 6.3-.3 2.6z"/>', '#fff') },
    { id: 'wk', n: 'Wikipedia', u: 'https://www.wikipedia.org', bg: '#f3f3f1', h: '<span class="glyph-t" style="color:#111;font-family:Georgia,serif;font-size:2rem">W</span>' },
    { id: 'am', n: 'Amazon', u: 'https://www.amazon.in', bg: '#232f3e', h: g('<path d="M3 4.5h2.6l2 10h9.8l2-7.5H6.6" stroke="#fff"/><circle cx="9.6" cy="18.6" r="1.4" fill="#fff" stroke="none"/><circle cx="16.4" cy="18.6" r="1.4" fill="#fff" stroke="none"/><path d="M8 21.2c3 1.2 6.2 1.2 9 0" stroke="#ff9900"/>') },
    { id: 'fk', n: 'Flipkart', u: 'https://www.flipkart.com', bg: '#2874f0', h: g('<path d="M5.5 8h13l-1 12h-11z" fill="#f9c900" stroke="none"/><path d="M9 10V7a3 3 0 0 1 6 0v3" stroke="#f9c900"/><text x="12" y="17.5" text-anchor="middle" font-size="9" font-weight="800" fill="#2874f0" stroke="none" font-family="sans-serif">f</text>') },
    { id: 'gg', n: 'Google', u: 'https://www.google.com', bg: '#ffffff', h: '<span style="width:30px;height:30px;color:#4285f4">' + g('<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>') + '</span>' }
  ];

  var ENGINES = {
    google: { n: 'Google', u: 'https://www.google.com/search?q=', home: 'https://www.google.com' },
    bing: { n: 'Bing', u: 'https://www.bing.com/search?q=', home: 'https://www.bing.com' },
    ddg: { n: 'DuckDuckGo', u: 'https://duckduckgo.com/?q=', home: 'https://duckduckgo.com' },
    yahoo: { n: 'Yahoo', u: 'https://search.yahoo.com/search?p=', home: 'https://search.yahoo.com' }
  };
  var ADDONS = [
    { n: 'Google Translate', s: 'Kisi bhi bhasha ka anuvaad', u: 'https://translate.google.com', i: 'translate' },
    { n: 'Maps', s: 'Raste aur jagah dhundho', u: 'https://maps.google.com', i: 'map' },
    { n: 'News', s: 'Taaza khabrein', u: 'https://news.google.com', i: 'news' },
    { n: 'Weather', s: 'Aaj ka mausam', u: 'https://www.google.com/search?q=weather', i: 'sun' },
    { n: 'Cricket score', s: 'Live score', u: 'https://www.google.com/search?q=cricket+score', i: 'ball' }
  ];
  var SIZES = [['Small', 0.92], ['Medium', 1], ['Large', 1.12]];
  var VIEWS = ['home', 'bookmarks', 'history', 'videos', 'downloads', 'addons', 'settings'];
  var DEFAULTS = { engine: 'google', night: true, size: 1, cols: 4, incog: false };

  var $ = function (id) { return document.getElementById(id); };
  function load(k, d) { try { var v = localStorage.getItem('sr_' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  function save(k, v) { try { localStorage.setItem('sr_' + k, JSON.stringify(v)); } catch (e) {} }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function host(u) { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return u; } }
  function normUrl(s) {
    s = (s || '').trim();
    if (/^https?:\/\//i.test(s)) return s;
    if (/^[\w-]+(\.[\w-]+)+(:\d+)?(\/\S*)?$/.test(s)) return 'https://' + s;
    return null;
  }
  function fmt(ts) {
    var d = new Date(ts), n = new Date(), t = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return d.toDateString() === n.toDateString() ? 'Today, ' + t : d.toLocaleDateString([], { day: 'numeric', month: 'short' }) + ', ' + t;
  }

  var st = {
    s: Object.assign({}, DEFAULTS, load('settings', {})),
    history: load('history', []), sites: load('sites', []), vids: load('vids', []), dls: load('dls', []),
    mode: 'web', view: 'home', nav: 0
  };

  var toastT;
  function toast(m) { var t = $('toast'); t.textContent = m; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(function () { t.hidden = true; }, 1900); }

  /* ---------- Opening links ---------- */
  function openUrl(url, title) {
    if (!st.s.incog) {
      st.history.unshift({ t: title || host(url), u: url, at: Date.now() });
      st.history = st.history.slice(0, 150); save('history', st.history); renderHistory();
    }
    var a = document.createElement('a');
    a.href = url; a.target = '_blank'; a.rel = 'noopener noreferrer';
    document.body.appendChild(a); a.click(); a.remove();
  }
  function searchUrl(q) {
    var e = ENGINES[st.s.engine] || ENGINES.google, u = e.u + encodeURIComponent(q), m = st.mode;
    if (st.s.engine === 'google') { if (m === 'vid') u += '&tbm=vid'; if (m === 'img') u += '&tbm=isch'; }
    else if (st.s.engine === 'bing') { if (m === 'vid') u = 'https://www.bing.com/videos/search?q=' + encodeURIComponent(q); if (m === 'img') u = 'https://www.bing.com/images/search?q=' + encodeURIComponent(q); }
    else if (st.s.engine === 'ddg') { if (m === 'vid') u += '&iax=videos&ia=videos'; if (m === 'img') u += '&iax=images&ia=images'; }
    return u;
  }

  /* ---------- Home ---------- */
  function allSites() {
    return DEFAULT_SITES.concat(st.sites.map(function (s) {
      return { id: '', n: s.n, u: s.u, bg: 'var(--surface2)', h: '<span class="glyph-t" style="color:var(--gold)">' + esc(s.n.charAt(0).toUpperCase()) + '</span>' };
    }));
  }
  function renderGrid() {
    document.documentElement.style.setProperty('--cols', st.s.cols);
    $('grid').innerHTML = allSites().map(function (s) {
      var real = s.id ? '<img class="real" src="assets/icons/' + s.id + '.png" alt="" onerror="this.remove()">' : '';
      return '<a class="tile" href="' + esc(s.u) + '" target="_blank" rel="noopener" data-name="' + esc(s.n) + '"><div class="ico" style="background:' + s.bg + '">' + s.h + real + '</div><span class="n">' + esc(s.n) + '</span></a>';
    }).join('') + '<a class="tile add" href="#bookmarks"><div class="ico">' + ICON.plus + '</div><span class="n">Add</span></a>';
  }
  function renderEngine() {
    var e = ENGINES[st.s.engine] || ENGINES.google;
    $('engineText').textContent = e.n; $('engineText').hidden = false;
    var img = $('engineImg'); img.hidden = true;
    var probe = new Image();
    probe.onload = function () { img.src = probe.src; img.alt = e.n; img.hidden = false; $('engineText').hidden = true; };
    probe.src = 'assets/engines/' + st.s.engine + '.png';
    $('engineSub').textContent = 'Search with ' + e.n;
    $('url').placeholder = 'Enter URL';
  }

  /* ---------- Lists ---------- */
  function rowHtml(ico, title, sub, extra) {
    return '<div class="row"><div class="mini">' + ico + '</div><div class="grow"><span class="t">' + esc(title) + '</span><span class="s">' + esc(sub) + '</span></div>' + (extra || '') + '</div>';
  }
  function renderHistory() {
    $('histList').innerHTML = st.history.length ? st.history.map(function (h, i) {
      return '<a class="row" href="' + esc(h.u) + '" target="_blank" rel="noopener"><div class="mini">' + esc((host(h.u).charAt(0) || '?').toUpperCase()) + '</div><div class="grow"><span class="t">' + esc(h.t) + '</span><span class="s">' + esc(host(h.u)) + ' · ' + fmt(h.at) + '</span></div></a>';
    }).join('') : '<div class="empty">History khaali hai. Jo sites aur searches aap khologe yahan dikhengi.</div>';
  }
  function renderBm() {
    $('bmList').innerHTML = st.sites.length ? st.sites.map(function (s, i) {
      return rowHtml(esc(s.n.charAt(0).toUpperCase()), s.n, host(s.u), '<button class="mini-btn danger" data-rm="bm:' + i + '">Remove</button>');
    }).join('') : '<div class="empty">Koi bhi website add karo, wo home screen par dikhegi.</div>';
  }
  function renderVids() {
    $('vidList').innerHTML = st.vids.length ? st.vids.map(function (v, i) {
      return rowHtml(ICON.video, v.t, host(v.u), '<a class="mini-btn" href="' + esc(v.u) + '" target="_blank" rel="noopener">Play</a><button class="mini-btn danger" data-rm="vid:' + i + '" aria-label="Remove">&#10005;</button>');
    }).join('') : '<div class="empty">Apni pasandida videos ke link yahan save karo.</div>';
  }
  function renderDls() {
    $('dlList').innerHTML = st.dls.length ? st.dls.map(function (d, i) {
      var name = d.u.split('?')[0].split('/').pop() || host(d.u);
      try { name = decodeURIComponent(name); } catch (e) {}
      return rowHtml(ICON.download, name, host(d.u) + ' · ' + fmt(d.at), '<a class="mini-btn" href="' + esc(d.u) + '" target="_blank" rel="noopener">Open</a><button class="mini-btn danger" data-rm="dl:' + i + '" aria-label="Remove">&#10005;</button>');
    }).join('') : '<div class="empty">Abhi koi download nahi. Upar direct file link daalo.</div>';
  }
  function renderAddons() {
    $('addonList').innerHTML = ADDONS.map(function (a) {
      return '<a class="row" href="' + esc(a.u) + '" target="_blank" rel="noopener" data-name="' + esc(a.n) + '"><div class="mini">' + ICON[a.i] + '</div><div class="grow"><span class="t">' + esc(a.n) + '</span><span class="s">' + esc(a.s) + '</span></div></a>';
    }).join('');
  }
  function seg(id, items, cur, attr) {
    $(id).innerHTML = items.map(function (it) { return '<button class="chip" data-' + attr + '="' + it[0] + '" aria-pressed="' + (String(it[0]) === String(cur)) + '">' + it[1] + '</button>'; }).join('');
  }
  function renderSettings() {
    seg('engineSeg', Object.keys(ENGINES).map(function (k) { return [k, ENGINES[k].n]; }), st.s.engine, 'engine');
    seg('sizeSeg', SIZES.map(function (z) { return [z[1], z[0]]; }), st.s.size, 'size');
    seg('colSeg', [[3, '3'], [4, '4'], [5, '5']], st.s.cols, 'cols');
    $('swNight').setAttribute('aria-checked', st.s.night);
    $('swIncog').setAttribute('aria-checked', st.s.incog);
    $('swFull').setAttribute('aria-checked', !!document.fullscreenElement);
  }
  function applySettings() {
    document.documentElement.dataset.theme = st.s.night ? 'dark' : 'light';
    document.documentElement.style.setProperty('--fs', st.s.size);
    var m = document.querySelector('meta[name="theme-color"]'); if (m) m.content = st.s.night ? '#0a0907' : '#ffffff';
    save('settings', st.s);
    renderSettings(); renderGrid(); renderEngine(); renderMenu();
  }

  /* ---------- Views (hash routing so the phone back button works) ---------- */
  function show() {
    var v = (location.hash || '').replace('#', '');
    if (VIEWS.indexOf(v) < 0) v = 'home';
    st.view = v;
    VIEWS.forEach(function (n) { $('v-' + n).hidden = n !== v; });
    $('btnRefresh').disabled = v === 'home';
    closeMenu(); window.scrollTo(0, 0); renderMenu();
    if (v === 'settings') renderSettings();
  }
  function go(v) { st.nav++; location.hash = v === 'home' ? '' : v; if (v === 'home' && !location.hash) show(); }
  function goBack() { if (st.nav > 0) { st.nav--; history.back(); } else { location.hash = ''; show(); } }

  /* ---------- Menu sheet (2 pages like UC) ---------- */
  function menuItems() {
    return [[
      { k: 'bookmarks', l: 'Bookmarks', i: 'star' },
      { k: 'history', l: 'History', i: 'clock' },
      { k: 'refresh', l: 'Refresh', i: 'refresh', off: st.view === 'home' },
      { k: 'full', l: 'Full Screen', i: 'full', on: !!document.fullscreenElement },
      { k: 'addons', l: 'Add-ons', i: 'addons' },
      { k: 'videos', l: 'My Videos', i: 'video' },
      { k: 'downloads', l: 'Downloads', i: 'download' },
      { k: 'exit', l: 'Exit', i: 'power' }
    ], [
      { k: 'settings', l: 'Settings', i: 'gear' },
      { k: 'night', l: 'Night Mode', i: 'moon', on: st.s.night },
      { k: 'incog', l: 'Incognito', i: 'mask', on: st.s.incog },
      { k: 'size', l: 'Text Size', i: 'aa' },
      { k: 'clear', l: 'Clear Records', i: 'trash' },
      { k: 'share', l: 'Share', i: 'share' },
      { k: 'addsite', l: 'Add Site', i: 'plus' },
      { k: 'about', l: 'About', i: 'info' }
    ]];
  }
  function renderMenu() {
    $('pages').innerHTML = menuItems().map(function (pg) {
      return '<div class="page">' + pg.map(function (it) {
        return '<button class="mi' + (it.on ? ' on' : '') + (it.off ? ' off' : '') + '" data-m="' + it.k + '"><span class="mic">' + ICON[it.i] + '</span><span class="l">' + it.l + '</span></button>';
      }).join('') + '</div>';
    }).join('');
  }
  function openMenu() { renderMenu(); $('sheet').hidden = false; $('scrim').hidden = false; $('btnMenu').setAttribute('aria-expanded', 'true'); $('pages').scrollLeft = 0; setDots(0); }
  function closeMenu() { $('sheet').hidden = true; $('scrim').hidden = true; $('btnMenu').setAttribute('aria-expanded', 'false'); }
  function setDots(i) { var d = $('dots').children; for (var n = 0; n < d.length; n++) d[n].className = n === i ? 'on' : ''; }
  function clearHistory() { st.history = []; save('history', st.history); renderHistory(); toast('History saaf ho gayi'); }
  function doShare() {
    var data = { title: 'S.R Browser', url: location.href.split('#')[0] };
    if (navigator.share) { navigator.share(data).catch(function () {}); return; }
    try { navigator.clipboard.writeText(data.url).then(function () { toast('Link copy ho gaya'); }, function () { toast(data.url); }); } catch (e) { toast(data.url); }
  }
  function toggleFull() {
    try {
      if (document.fullscreenElement) document.exitFullscreen();
      else document.documentElement.requestFullscreen().catch(function () { toast('Full screen yahan allowed nahi'); });
    } catch (e) { toast('Full screen yahan allowed nahi'); }
  }
  function menuAction(k) {
    switch (k) {
      case 'bookmarks': case 'history': case 'addons': case 'videos': case 'downloads': case 'settings': go(k); break;
      case 'refresh': location.reload(); break;
      case 'full': closeMenu(); toggleFull(); break;
      case 'exit': closeMenu(); $('exitModal').hidden = false; break;
      case 'night': st.s.night = !st.s.night; applySettings(); break;
      case 'incog': st.s.incog = !st.s.incog; applySettings(); toast(st.s.incog ? 'Incognito on' : 'Incognito off'); break;
      case 'size': var idx = SIZES.map(function (z) { return z[1]; }).indexOf(st.s.size); st.s.size = SIZES[(idx + 1) % SIZES.length][1]; applySettings(); toast('Text size: ' + SIZES[(idx + 1) % SIZES.length][0]); break;
      case 'clear': closeMenu(); clearHistory(); break;
      case 'share': closeMenu(); doShare(); break;
      case 'addsite': go('bookmarks'); setTimeout(function () { $('bmName').focus(); }, 60); break;
      case 'about': go('settings'); setTimeout(function () { window.scrollTo(0, document.body.scrollHeight); }, 60); break;
    }
  }

  /* ---------- Events ---------- */
  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-m],[data-back],[data-mode],[data-engine],[data-size],[data-cols],[data-rm],a[data-name]');
    if (!t) return;
    if (t.dataset.m) { menuAction(t.dataset.m); return; }
    if ('back' in t.dataset) { goBack(); return; }
    if (t.dataset.mode) { st.mode = t.dataset.mode; document.querySelectorAll('[data-mode]').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.mode === st.mode); }); return; }
    if (t.dataset.engine) { st.s.engine = t.dataset.engine; applySettings(); toast('Search engine: ' + ENGINES[st.s.engine].n); return; }
    if (t.dataset.size) { st.s.size = parseFloat(t.dataset.size); applySettings(); return; }
    if (t.dataset.cols) { st.s.cols = parseInt(t.dataset.cols, 10); applySettings(); return; }
    if (t.dataset.rm) {
      var p = t.dataset.rm.split(':'), i = +p[1];
      if (p[0] === 'bm') { st.sites.splice(i, 1); save('sites', st.sites); renderBm(); renderGrid(); }
      if (p[0] === 'vid') { st.vids.splice(i, 1); save('vids', st.vids); renderVids(); }
      if (p[0] === 'dl') { st.dls.splice(i, 1); save('dls', st.dls); renderDls(); }
      return;
    }
    if (t.dataset.name && !st.s.incog) {
      st.history.unshift({ t: t.dataset.name, u: t.href, at: Date.now() }); st.history = st.history.slice(0, 150); save('history', st.history); renderHistory();
    }
  });
  $('pages').addEventListener('scroll', function () { setDots(Math.round(this.scrollLeft / Math.max(1, this.clientWidth))); });
  $('scrim').addEventListener('click', closeMenu);
  $('btnMenu').addEventListener('click', function () { $('sheet').hidden ? openMenu() : closeMenu(); });
  $('btnShare').addEventListener('click', doShare);
  $('btnAdd').addEventListener('click', function () { go('bookmarks'); setTimeout(function () { $('bmName').focus(); }, 60); });
  $('btnRefresh').addEventListener('click', function () { location.reload(); });
  window.addEventListener('hashchange', show);
  document.addEventListener('fullscreenchange', function () { renderSettings(); renderMenu(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeMenu(); });

  $('urlForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var q = $('url').value.trim();
    if (!q) { $('url').focus(); return; }
    var u = normUrl(q);
    if (u) openUrl(u, host(u)); else openUrl(searchUrl(q), q);
  });

  $('swNight').addEventListener('click', function () { st.s.night = !st.s.night; applySettings(); });
  $('swIncog').addEventListener('click', function () { st.s.incog = !st.s.incog; applySettings(); toast(st.s.incog ? 'Incognito on' : 'Incognito off'); });
  $('swFull').addEventListener('click', toggleFull);
  $('clearHist').addEventListener('click', clearHistory);
  $('setClearHist').addEventListener('click', clearHistory);
  $('clearVid').addEventListener('click', function () { st.vids = []; save('vids', st.vids); renderVids(); });
  $('clearDl').addEventListener('click', function () { st.dls = []; save('dls', st.dls); renderDls(); });
  $('setClearFiles').addEventListener('click', function () { st.dls = []; st.vids = []; save('dls', []); save('vids', []); renderDls(); renderVids(); toast('Downloads aur videos saaf'); });
  $('resetAll').addEventListener('click', function () {
    st.s = Object.assign({}, DEFAULTS); st.history = []; st.sites = []; st.vids = []; st.dls = [];
    ['history', 'sites', 'vids', 'dls'].forEach(function (k) { save(k, []); });
    applySettings(); renderHistory(); renderBm(); renderVids(); renderDls(); toast('S.R Browser reset ho gaya');
  });

  $('bmForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var n = $('bmName').value.trim(), u = normUrl($('bmUrl').value);
    if (!n || !u) { toast('Naam aur poora address daalo'); return; }
    st.sites.push({ n: n, u: u }); save('sites', st.sites); $('bmName').value = ''; $('bmUrl').value = '';
    renderBm(); renderGrid(); toast(n + ' home par add ho gaya');
  });
  $('vidForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var u = normUrl($('vidUrl').value), t = $('vidTitle').value.trim();
    if (!u) { toast('Poora video link daalo'); return; }
    st.vids.unshift({ t: t || host(u), u: u, at: Date.now() }); save('vids', st.vids); $('vidTitle').value = ''; $('vidUrl').value = '';
    renderVids(); toast('Video save ho gaya');
  });
  $('dlForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var u = normUrl($('dlUrl').value);
    if (!u) { toast('Poora link daalo, jaise https://site.com/file.mp4'); return; }
    st.dls.unshift({ u: u, at: Date.now() }); save('dls', st.dls); $('dlUrl').value = ''; renderDls(); toast('Download list mein add');
  });

  $('exitNo').addEventListener('click', function () { $('exitModal').hidden = true; });
  $('exitYes').addEventListener('click', function () {
    try { window.close(); } catch (e) {}
    $('exitMsg').textContent = 'Browser tab band karne ke liye apne phone ka back ya close button use karo.';
    $('exitYes').hidden = true;
  });

  if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) { navigator.serviceWorker.register('sw.js').catch(function () {}); }

  paintIcons();
  applySettings(); renderHistory(); renderBm(); renderVids(); renderDls(); renderAddons(); show();
})();
