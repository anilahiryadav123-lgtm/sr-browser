# S.R Browser (Android)
WebView based browser: tabs, UC style menu + settings, downloads, history, bookmarks.
Official logos: put PNGs in app/src/main/assets/engines/google.png and app/src/main/assets/icons/yt.png etc.
