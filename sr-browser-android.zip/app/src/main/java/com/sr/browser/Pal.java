package com.sr.browser;

/** Colour palette: black + gold (night) or warm white + gold (day). */
final class Pal {
    final int bg, bar, surface, surface2, line, fg, muted, gold, onGold, sheet, icon;

    Pal(boolean night) {
        if (night) {
            bg = 0xFF0A0907;
            bar = 0xFF14110B;
            surface = 0xFF17140D;
            surface2 = 0xFF211C10;
            line = 0xFF30281A;
            fg = 0xFFF5F2E9;
            muted = 0xFFA8A088;
            gold = 0xFFF0B429;
            onGold = 0xFF1A1405;
            sheet = 0xFF141109;
            icon = 0xFFC9C2AD;
        } else {
            bg = 0xFFF5F2E8;
            bar = 0xFFFFFFFF;
            surface = 0xFFFFFFFF;
            surface2 = 0xFFEFEADB;
            line = 0xFFDDD5BD;
            fg = 0xFF1B1708;
            muted = 0xFF6D6548;
            gold = 0xFFC58A00;
            onGold = 0xFFFFFFFF;
            sheet = 0xFFFFFFFF;
            icon = 0xFF5A6073;
        }
    }
}
