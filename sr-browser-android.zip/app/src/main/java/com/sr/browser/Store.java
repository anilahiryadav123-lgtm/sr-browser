package com.sr.browser;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Small settings + list storage (history, bookmarks, saved videos). */
final class Store {
    static final class Item {
        final String title;
        final String url;

        Item(String t, String u) {
            title = t;
            url = u;
        }
    }

    private final SharedPreferences p;

    Store(Context c) {
        p = c.getSharedPreferences("sr", Context.MODE_PRIVATE);
    }

    String engine() { return p.getString("engine", "google"); }
    void setEngine(String v) { p.edit().putString("engine", v).apply(); }

    boolean night() { return p.getBoolean("night", true); }
    void setNight(boolean v) { p.edit().putBoolean("night", v).apply(); }

    boolean incognito() { return p.getBoolean("incog", false); }
    void setIncognito(boolean v) { p.edit().putBoolean("incog", v).apply(); }

    boolean desktop() { return p.getBoolean("desktop", false); }
    void setDesktop(boolean v) { p.edit().putBoolean("desktop", v).apply(); }

    int textSize() { return p.getInt("size", 1); }
    void setTextSize(int v) { p.edit().putInt("size", v).apply(); }

    List<Item> list(String key) {
        List<Item> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p.getString(key, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Item(o.optString("t"), o.optString("u")));
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private void save(String key, List<Item> l) {
        JSONArray a = new JSONArray();
        for (Item it : l) {
            try {
                JSONObject o = new JSONObject();
                o.put("t", it.title);
                o.put("u", it.url);
                a.put(o);
            } catch (Exception ignored) {
            }
        }
        p.edit().putString(key, a.toString()).apply();
    }

    void add(String key, String title, String url, int max, boolean front) {
        List<Item> l = list(key);
        for (int i = l.size() - 1; i >= 0; i--) {
            if (l.get(i).url.equals(url)) l.remove(i);
        }
        if (front) l.add(0, new Item(title, url));
        else l.add(new Item(title, url));
        while (l.size() > max) l.remove(front ? l.size() - 1 : 0);
        save(key, l);
    }

    void remove(String key, int idx) {
        List<Item> l = list(key);
        if (idx >= 0 && idx < l.size()) {
            l.remove(idx);
            save(key, l);
        }
    }

    void clear(String key) {
        p.edit().remove(key).apply();
    }
}
