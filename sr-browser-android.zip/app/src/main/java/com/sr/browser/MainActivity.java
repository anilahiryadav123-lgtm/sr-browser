package com.sr.browser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.role.RoleManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/** S.R Browser: a UC style browser built on Android WebView. Made in India. */
public class MainActivity extends Activity {

    interface Renderer {
        void render(LinearLayout body);
    }

    interface BoolCb {
        void on(boolean v);
    }

    static final class Row {
        final String title, sub;
        final int icon;
        final Runnable click, delete;

        Row(String title, String sub, int icon, Runnable click, Runnable delete) {
            this.title = title;
            this.sub = sub;
            this.icon = icon;
            this.click = click;
            this.delete = delete;
        }
    }

    static final class Tab {
        WebView web;
        String title = "";
        String url = "";
        boolean home = true;
        Bitmap thumb;
    }

    static final class PanelState {
        LinearLayout view;
        LinearLayout body;
        Renderer renderer;
        String id = "";
    }

    private static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    private static final int REQ_FILE = 11;
    private static final int REQ_PHOTO = 12;
    private static final int PURPLE = 0xFF7C5CF0;

    private static final String[][] SITES = {
            {"gg", "Google", "https://www.google.com"},
            {"yt", "YouTube", "https://m.youtube.com"},
            {"fb", "Facebook", "https://m.facebook.com"},
            {"ig", "Instagram", "https://www.instagram.com"},
            {"wa", "WhatsApp", "https://web.whatsapp.com"},
            {"tg", "Telegram", "https://web.telegram.org"},
            {"wk", "Wikipedia", "https://www.wikipedia.org"},
            {"am", "Amazon", "https://www.amazon.in"},
            {"fk", "Flipkart", "https://www.flipkart.com"}
    };
    private static final int[] SITE_BG = {
            0xFFFFFFFF, 0xFFE62117, 0xFF1877F2, 0xFFC32AA3, 0xFF25B45A,
            0xFF2A9BD8, 0xFFF3F3F1, 0xFF232F3E, 0xFF2874F0
    };
    private static final String[][] ENGINES = {
            {"google", "Google", "G"}, {"bing", "Bing", "B"}, {"ddg", "DuckDuckGo", "D"}, {"yahoo", "Yahoo", "Y"}
    };
    private static final int[] ENGINE_COLOR = {0xFF4285F4, 0xFF008373, 0xFFDE5833, 0xFF6001D2};
    private static final String[] SIZE_NAMES = {"Small", "Medium", "Large"};
    private static final int[] SIZE_ZOOM = {90, 100, 115};
    private static final String[] AD_HOSTS = {
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google",
            "adnxs.com", "taboola.com", "outbrain.com", "popads.net", "propellerads.com",
            "exoclick.com", "mgid.com", "adsterra.com", "pubmatic.com", "rubiconproject.com",
            "criteo.com", "moatads.com", "amazon-adsystem.com", "adcolony.com", "unityads.unity3d.com"
    };
    private static final String[] THEME_NAMES = {"SR", "Night Sky", "Ocean", "Aurora", "Sunset"};
    private static final int[][] THEME_COLORS = {
            {0xFFFFFFFF, 0xFFFFFFFF},
            {0xFF1B1730, 0xFF3A2A4A},
            {0xFF0B1E4A, 0xFF27A3D8},
            {0xFF0A2A6B, 0xFF18C2D0},
            {0xFFFF8A4C, 0xFFE5121B}
    };

    private final Handler ui = new Handler(Looper.getMainLooper());

    private Store store;
    private Pal pal;
    private String mobileUa;

    private FrameLayout screen;
    private LinearLayout root, topBar, bottomBar;
    private EditText urlEdit, homeEdit;
    private ImageView btnRefresh, tabsIcon;
    private ProgressBar progress;
    private FrameLayout webHolder;
    private ScrollView homeView;
    private LinearLayout homeBox;
    private TextView tabCount, videoFab;
    private View btnBack, btnFwd;

    private View scrim;
    private LinearLayout sheetBox;
    private View tabsView;
    private View welcome;

    private final List<PanelState> panels = new ArrayList<>();
    private final List<Tab> tabs = new ArrayList<>();
    private final List<String> closedUrls = new ArrayList<>();
    private Tab cur;
    private int mode = 0;
    private int histTab = 0;
    private boolean fullscreen = false;
    private boolean loading = false;
    private String videoUrl = null;

    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private ValueCallback<Uri[]> fileCb;

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private String tr(String s) {
        return Strings.tr(store.lang(), s);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private GradientDrawable oval(int color) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(color);
        return g;
    }

    /* ------------------------------------------------------------------ */
    /* Lifecycle                                                          */
    /* ------------------------------------------------------------------ */

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        store = new Store(this);
        mode = store.searchMode();
        pal = new Pal(store.night());
        mobileUa = WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace("Version/4.0 ", "");
        CookieManager.getInstance().setAcceptCookie(true);
        getWindow().setStatusBarColor(pal.bg);
        getWindow().setNavigationBarColor(pal.bar);

        buildUi();
        buildSheet();
        setContentView(screen);
        applySystemUi();

        ArrayList<String> saveTabs = saved == null ? null : saved.getStringArrayList("tabs");
        if (saveTabs != null && !saveTabs.isEmpty()) {
            for (String s : saveTabs) {
                Tab t = newTab();
                if (!s.isEmpty()) loadIn(t, s);
            }
            int ci = saved.getInt("cur", 0);
            if (ci >= 0 && ci < tabs.size()) switchTo(tabs.get(ci));
        } else {
            handleIntent(getIntent());
        }
        if (tabs.isEmpty()) newTab();

        if (!store.welcomed()) showWelcome();
        else ensurePerms();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        ArrayList<String> u = new ArrayList<>();
        for (Tab t : tabs) u.add(t.home ? "" : t.url);
        out.putStringArrayList("tabs", u);
        out.putInt("cur", tabs.indexOf(cur));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent i) {
        if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) {
            Tab t = newTab();
            loadIn(t, i.getData().toString());
        } else if (tabs.isEmpty()) {
            newTab();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (cur != null) cur.web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (cur != null) cur.web.onResume();
        refreshPanel();
    }

    @Override
    protected void onDestroy() {
        ui.removeCallbacksAndMessages(null);
        for (Tab t : tabs) {
            try {
                webHolder.removeView(t.web);
                t.web.destroy();
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        } else if (req == REQ_PHOTO) {
            if (res == RESULT_OK && data != null && data.getData() != null) saveWallpaper(data.getData());
        } else {
            super.onActivityResult(req, res, data);
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustom();
        } else if (tabsView != null) {
            closeTabsView();
        } else if (!panels.isEmpty()) {
            closePanel();
        } else if (scrim.getVisibility() == View.VISIBLE) {
            closeMenu();
        } else if (welcome != null) {
            finish();
        } else if (fullscreen) {
            fullscreen = false;
            applySystemUi();
        } else {
            goBack();
        }
    }

    private void ensurePerms() {
        try {
            if (Build.VERSION.SDK_INT >= 33
                    && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 2);
            } else if (Build.VERSION.SDK_INT < 29
                    && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            }
        } catch (Exception ignored) {
        }
    }

    private void applySystemUi() {
        int f = 0;
        if (fullscreen || customView != null) {
            f = View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        } else if (!pal.night) {
            if (Build.VERSION.SDK_INT >= 23) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) f |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(f);
        applyBars();
    }

    private void applyBars() {
        boolean web = cur != null && !cur.home;
        topBar.setVisibility(!fullscreen && web ? View.VISIBLE : View.GONE);
        bottomBar.setVisibility(fullscreen ? View.GONE : View.VISIBLE);
    }

    /* ------------------------------------------------------------------ */
    /* Main UI                                                            */
    /* ------------------------------------------------------------------ */

    private void buildUi() {
        screen = new FrameLayout(this);
        screen.setBackgroundColor(pal.bg);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        screen.addView(root, new FrameLayout.LayoutParams(-1, -1));

        // Page top bar (shown on web pages): mark | Enter URL + Search | refresh
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(pal.bar);
        topBar.setPadding(dp(10), dp(8), dp(6), dp(8));

        ImageView mark = new ImageView(this);
        mark.setImageResource(R.drawable.logo);
        mark.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(dp(34), dp(30));
        ml.rightMargin = dp(8);
        topBar.addView(mark, ml);

        LinearLayout urlBox = new LinearLayout(this);
        urlBox.setOrientation(LinearLayout.HORIZONTAL);
        urlBox.setGravity(Gravity.CENTER_VERTICAL);
        urlBox.setBackground(Ui.round(this, pal.surface2, 19));
        topBar.addView(urlBox, new LinearLayout.LayoutParams(0, dp(38), 1));

        urlEdit = new EditText(this);
        urlEdit.setHint(tr("Enter URL"));
        urlEdit.setHintTextColor(pal.muted);
        urlEdit.setTextColor(pal.fg);
        urlEdit.setTextSize(14);
        urlEdit.setSingleLine(true);
        urlEdit.setBackground(null);
        urlEdit.setSelectAllOnFocus(true);
        urlEdit.setPadding(dp(14), 0, dp(8), 0);
        urlEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlEdit.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlEdit.setOnEditorActionListener((v, actionId, ev) -> {
            submitFrom(urlEdit);
            return true;
        });
        urlBox.addView(urlEdit, new LinearLayout.LayoutParams(0, -1, 1));

        View div = new View(this);
        div.setBackgroundColor(pal.line);
        urlBox.addView(div, new LinearLayout.LayoutParams(dp(1), dp(20)));

        LinearLayout searchBtn = new LinearLayout(this);
        searchBtn.setOrientation(LinearLayout.HORIZONTAL);
        searchBtn.setGravity(Gravity.CENTER_VERTICAL);
        searchBtn.setPadding(dp(10), 0, dp(14), 0);
        searchBtn.addView(Ui.icon(this, R.drawable.ic_search, 17, pal.accent));
        TextView st = Ui.text(this, tr("Search"), 13.5f, pal.fg, true);
        st.setPadding(dp(5), 0, 0, 0);
        searchBtn.addView(st);
        searchBtn.setOnClickListener(v -> submitFrom(urlEdit));
        urlBox.addView(searchBtn, new LinearLayout.LayoutParams(-2, -1));

        btnRefresh = Ui.icon(this, R.drawable.ic_refresh, 24, pal.icon);
        btnRefresh.setPadding(dp(5), dp(5), dp(5), dp(5));
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(dp(38), dp(38));
        rl.leftMargin = dp(4);
        btnRefresh.setLayoutParams(rl);
        btnRefresh.setOnClickListener(v -> {
            if (cur.home) return;
            if (loading) cur.web.stopLoading();
            else cur.web.reload();
        });
        topBar.addView(btnRefresh);
        root.addView(topBar, new LinearLayout.LayoutParams(-1, -2));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(pal.accent));
        progress.setVisibility(View.INVISIBLE);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(2)));

        // Content: home screen or web pages
        FrameLayout content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        homeView = new ScrollView(this);
        homeView.setFillViewport(true);
        homeView.setVerticalScrollBarEnabled(false);
        homeBox = new LinearLayout(this);
        homeBox.setOrientation(LinearLayout.VERTICAL);
        homeBox.setPadding(dp(16), dp(24), dp(16), dp(28));
        homeView.addView(homeBox, new ViewGroup.LayoutParams(-1, -2));
        content.addView(homeView, new FrameLayout.LayoutParams(-1, -1));

        webHolder = new FrameLayout(this);
        content.addView(webHolder, new FrameLayout.LayoutParams(-1, -1));

        // Floating "download video" button
        videoFab = Ui.text(this, "  Download video  ", 13.5f, Color.WHITE, true);
        videoFab.setGravity(Gravity.CENTER);
        videoFab.setBackground(Ui.round(this, pal.accent, 24));
        videoFab.setElevation(dp(6));
        videoFab.setPadding(dp(16), dp(11), dp(16), dp(11));
        videoFab.setVisibility(View.GONE);
        videoFab.setOnClickListener(v -> {
            if (videoUrl != null) startDownload(videoUrl, mobileUa, null, null);
            videoFab.setVisibility(View.GONE);
        });
        FrameLayout.LayoutParams vf = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        vf.rightMargin = dp(14);
        vf.bottomMargin = dp(14);
        content.addView(videoFab, vf);

        // Bottom bar: back | forward | menu | tabs | home
        View line = new View(this);
        line.setBackgroundColor(pal.line);
        root.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));

        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setBackgroundColor(pal.bar);
        btnBack = barBtn(R.drawable.ic_back, this::goBack);
        btnFwd = barBtn(R.drawable.ic_forward, () -> {
            if (!cur.home && cur.web.canGoForward()) cur.web.goForward();
        });
        View btnMenu = barBtn(R.drawable.ic_menu, this::openMenu);
        FrameLayout tabsBtn = new FrameLayout(this);
        tabsIcon = Ui.icon(this, R.drawable.ic_tabs, 26, pal.icon);
        tabsBtn.addView(tabsIcon, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        tabCount = Ui.text(this, "1", 11, pal.icon, true);
        tabCount.setGravity(Gravity.CENTER);
        tabsBtn.addView(tabCount, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        tabsBtn.setOnClickListener(v -> openTabs());
        View btnHome = barBtn(R.drawable.ic_home, () -> {
            cur.home = true;
            showCurrent();
        });
        bottomBar.addView(btnBack, new LinearLayout.LayoutParams(0, dp(52), 1));
        bottomBar.addView(btnFwd, new LinearLayout.LayoutParams(0, dp(52), 1));
        bottomBar.addView(btnMenu, new LinearLayout.LayoutParams(0, dp(52), 1));
        bottomBar.addView(tabsBtn, new LinearLayout.LayoutParams(0, dp(52), 1));
        bottomBar.addView(btnHome, new LinearLayout.LayoutParams(0, dp(52), 1));
        root.addView(bottomBar, new LinearLayout.LayoutParams(-1, -2));

        refreshHome();
    }

    private View barBtn(int res, Runnable r) {
        FrameLayout f = new FrameLayout(this);
        f.addView(Ui.icon(this, res, 25, pal.icon), new FrameLayout.LayoutParams(dp(25), dp(25), Gravity.CENTER));
        f.setOnClickListener(v -> r.run());
        return f;
    }

    private void updateTabBtn() {
        boolean inc = store.incognito();
        tabsIcon.setImageResource(inc ? R.drawable.ic_ghost : R.drawable.ic_tabs);
        tabsIcon.setColorFilter(inc ? PURPLE : pal.icon, android.graphics.PorterDuff.Mode.SRC_IN);
        tabCount.setText(inc ? "" : String.valueOf(tabs.size()));
    }

    /* ------------------------------------------------------------------ */
    /* Welcome screen                                                     */
    /* ------------------------------------------------------------------ */

    private LinearLayout indiaLine(int textColor, float sp) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER);
        LinearLayout flag = new LinearLayout(this);
        flag.setOrientation(LinearLayout.VERTICAL);
        int[] cs = {0xFFFF9933, 0xFFFFFFFF, 0xFF138808};
        for (int c : cs) {
            View s = new View(this);
            s.setBackgroundColor(c);
            flag.addView(s, new LinearLayout.LayoutParams(dp(20), dp(4)));
        }
        flag.setBackground(Ui.round(this, 0xFFDDDDDD, 2));
        flag.setPadding(dp(1), dp(1), dp(1), dp(1));
        l.addView(flag, new LinearLayout.LayoutParams(-2, -2));
        TextView t = Ui.text(this, tr("Made in India"), sp, textColor, true);
        t.setPadding(dp(8), 0, 0, 0);
        l.addView(t);
        return l;
    }

    private void showWelcome() {
        FrameLayout w = new FrameLayout(this);
        w.setBackgroundColor(Color.WHITE);
        w.setClickable(true);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(28), dp(0), dp(28), dp(0));

        View spacerTop = new View(this);
        col.addView(spacerTop, new LinearLayout.LayoutParams(-1, 0, 1.1f));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        col.addView(logo, new LinearLayout.LayoutParams(dp(250), dp(212)));

        TextView tag = Ui.text(this, tr("Fast. Simple. Made in India."), 15, 0xFF5B6070, false);
        tag.setGravity(Gravity.CENTER);
        tag.setPadding(0, dp(22), 0, dp(14));
        col.addView(tag);
        col.addView(indiaLine(0xFF1A1D23, 14));

        View spacerMid = new View(this);
        col.addView(spacerMid, new LinearLayout.LayoutParams(-1, 0, 1.2f));

        TextView terms = Ui.text(this, "By continuing you agree to use S.R Browser responsibly.", 13, 0xFF5B6070, false);
        terms.setGravity(Gravity.CENTER);
        col.addView(terms);

        TextView btn = Ui.text(this, tr("Agree and Enter"), 17, Color.WHITE, true);
        btn.setGravity(Gravity.CENTER);
        btn.setBackground(Ui.round(this, Pal.RED, 14));
        btn.setOnClickListener(v -> {
            store.setWelcomed(true);
            screen.removeView(w);
            welcome = null;
            ensurePerms();
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(54));
        bp.topMargin = dp(16);
        bp.bottomMargin = dp(36);
        col.addView(btn, bp);

        w.addView(col, new FrameLayout.LayoutParams(-1, -1));
        welcome = w;
        screen.addView(w, new FrameLayout.LayoutParams(-1, -1));
    }

    /* ------------------------------------------------------------------ */
    /* Home screen                                                        */
    /* ------------------------------------------------------------------ */

    private boolean homeDark() {
        return store.theme() == 0 ? pal.night : true;
    }

    private int homeFg() {
        return homeDark() ? 0xFFFFFFFF : pal.fg;
    }

    private int homeSub() {
        return homeDark() ? 0xCCFFFFFF : pal.muted;
    }

    private void applyHomeBackground() {
        int t = store.theme();
        if (t == 5) {
            File f = new File(getFilesDir(), "wall.jpg");
            Bitmap b = f.exists() ? BitmapFactory.decodeFile(f.getPath()) : null;
            if (b != null) {
                android.graphics.drawable.BitmapDrawable bd = new android.graphics.drawable.BitmapDrawable(getResources(), b);
                bd.setGravity(Gravity.FILL);
                homeView.setBackground(bd);
                return;
            }
            t = 0;
            store.setTheme(0);
        }
        int[] c;
        if (t == 0) c = pal.night ? new int[]{pal.bg, 0xFF2A1518} : new int[]{pal.bg, 0xFFFFE9DF};
        else c = THEME_COLORS[Math.max(0, Math.min(THEME_COLORS.length - 1, t))];
        homeView.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, c));
    }

    private Bitmap assetBitmap(String path) {
        try (InputStream in = getAssets().open(path)) {
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            return null;
        }
    }

    private String engineName() {
        for (String[] e : ENGINES) if (e[0].equals(store.engine())) return e[1];
        return "Google";
    }

    private View engineBadge(int sizeDp) {
        FrameLayout f = new FrameLayout(this);
        int idx = 0;
        for (int i = 0; i < ENGINES.length; i++) if (ENGINES[i][0].equals(store.engine())) idx = i;
        Bitmap real = assetBitmap("engines/" + store.engine() + ".png");
        if (real != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(real);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        } else {
            f.setBackground(oval(0xFFFFFFFF));
            TextView t = Ui.text(this, ENGINES[idx][2], sizeDp * 0.5f, ENGINE_COLOR[idx], true);
            t.setGravity(Gravity.CENTER);
            f.addView(t, new FrameLayout.LayoutParams(-1, -1));
        }
        f.setLayoutParams(new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        return f;
    }

    private void refreshHome() {
        String keep = homeEdit == null ? "" : homeEdit.getText().toString();
        homeBox.removeAllViews();
        homeBox.setGravity(Gravity.CENTER_HORIZONTAL);
        applyHomeBackground();
        int fg = homeFg();

        // Logo, fixed size
        View logo;
        ImageView li = new ImageView(this);
        li.setImageResource(R.drawable.logo);
        li.setScaleType(ImageView.ScaleType.FIT_CENTER);
        if (homeDark()) {
            FrameLayout plate = new FrameLayout(this);
            plate.setBackground(Ui.round(this, 0xFFFFFFFF, 22));
            plate.setPadding(dp(14), dp(12), dp(14), dp(12));
            plate.addView(li, new FrameLayout.LayoutParams(-1, -1));
            logo = plate;
        } else {
            logo = li;
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(210), dp(178));
        lp.topMargin = dp(36);
        homeBox.addView(logo, lp);

        if (!store.homeNote().isEmpty()) {
            TextView n = Ui.text(this, store.homeNote(), 13.5f, homeSub(), false);
            n.setGravity(Gravity.CENTER);
            n.setPadding(0, dp(10), 0, 0);
            homeBox.addView(n);
        }

        // Search pill
        LinearLayout pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setBackground(Ui.round(this, pal.surface, 30));
        pill.setElevation(dp(5));
        pill.setPadding(dp(14), 0, dp(10), 0);
        LinearLayout eng = new LinearLayout(this);
        eng.setOrientation(LinearLayout.HORIZONTAL);
        eng.setGravity(Gravity.CENTER_VERTICAL);
        eng.addView(engineBadge(32));
        TextView tri = Ui.text(this, "▾", 12, pal.muted, false);
        tri.setPadding(dp(4), 0, dp(4), 0);
        eng.addView(tri);
        eng.setOnClickListener(v -> pickEngine());
        pill.addView(eng);

        homeEdit = new EditText(this);
        homeEdit.setHint(tr("Search or Enter URL"));
        homeEdit.setHintTextColor(pal.muted);
        homeEdit.setTextColor(pal.fg);
        homeEdit.setTextSize(16);
        homeEdit.setSingleLine(true);
        homeEdit.setBackground(null);
        homeEdit.setPadding(dp(8), 0, dp(8), 0);
        homeEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        homeEdit.setImeOptions(EditorInfo.IME_ACTION_GO);
        homeEdit.setText(keep);
        homeEdit.setOnEditorActionListener((v, actionId, ev) -> {
            submitFrom(homeEdit);
            return true;
        });
        pill.addView(homeEdit, new LinearLayout.LayoutParams(0, -1, 1));
        ImageView go = Ui.icon(this, R.drawable.ic_search, 22, pal.accent);
        go.setPadding(dp(4), dp(4), dp(4), dp(4));
        go.setLayoutParams(new LinearLayout.LayoutParams(dp(32), dp(32)));
        go.setOnClickListener(v -> submitFrom(homeEdit));
        pill.addView(go);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1, dp(56));
        pp.topMargin = dp(26);
        pp.leftMargin = dp(4);
        pp.rightMargin = dp(4);
        homeBox.addView(pill, pp);

        // Web / Videos / Images
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setGravity(Gravity.CENTER);
        String[] names = {"Web", "Videos", "Images"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView c = Ui.text(this, tr(names[i]), 13, i == mode ? Color.WHITE : homeSub(), true);
            c.setPadding(dp(16), dp(7), dp(16), dp(7));
            c.setBackground(Ui.round(this, i == mode ? pal.accent : (homeDark() ? 0x33FFFFFF : pal.surface), 20));
            c.setOnClickListener(v -> {
                mode = idx;
                store.setSearchMode(idx);
                refreshHome();
            });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
            cp.leftMargin = dp(4);
            cp.rightMargin = dp(4);
            chips.addView(c, cp);
        }
        LinearLayout.LayoutParams chp = new LinearLayout.LayoutParams(-2, -2);
        chp.topMargin = dp(16);
        homeBox.addView(chips, chp);

        // Quick row
        if (store.showQuick()) {
            LinearLayout q = new LinearLayout(this);
            q.setOrientation(LinearLayout.HORIZONTAL);
            q.addView(quick(R.drawable.ic_dl_hex, "Downloader", this::openDownloader), new LinearLayout.LayoutParams(0, -2, 1));
            q.addView(quick(R.drawable.ic_notes, "Notes", this::openNotes), new LinearLayout.LayoutParams(0, -2, 1));
            q.addView(quick(R.drawable.ic_clock, "History", this::openHistory), new LinearLayout.LayoutParams(0, -2, 1));
            q.addView(quick(R.drawable.ic_bookmark_o, "Bookmark", this::openBookmarks), new LinearLayout.LayoutParams(0, -2, 1));
            LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(-1, -2);
            qp.topMargin = dp(30);
            homeBox.addView(q, qp);
        }

        // Sites
        List<View> tiles = new ArrayList<>();
        for (int i = 0; i < SITES.length; i++) {
            final String url = SITES[i][2];
            GradientDrawable bg;
            if (SITES[i][0].equals("ig")) {
                bg = new GradientDrawable(GradientDrawable.Orientation.BL_TR,
                        new int[]{0xFFFDB53C, 0xFFF0443D, 0xFFC32AA3, 0xFF6A3DE8});
                bg.setShape(GradientDrawable.OVAL);
            } else {
                bg = oval(SITE_BG[i]);
            }
            int res = getResources().getIdentifier("t_" + SITES[i][0], "drawable", getPackageName());
            tiles.add(tile(SITES[i][1], bg, res, null, "icons/" + SITES[i][0] + ".png",
                    () -> loadIn(cur, url), null, fg));
        }
        List<Store.Item> bms = store.list("bm");
        for (int i = 0; i < bms.size(); i++) {
            final Store.Item b = bms.get(i);
            final int idx = i;
            String letter = b.title.isEmpty() ? "?" : b.title.substring(0, 1).toUpperCase();
            tiles.add(tile(b.title, oval(pal.surface), 0, letter, null,
                    () -> loadIn(cur, b.url),
                    () -> new AlertDialog.Builder(this).setTitle("Remove " + b.title + "?")
                            .setPositiveButton("Remove", (d, which) -> {
                                store.remove("bm", idx);
                                refreshHome();
                            }).setNegativeButton("Cancel", null).show(), fg));
        }
        GradientDrawable addBg = oval(homeDark() ? 0x22FFFFFF : pal.surface);
        addBg.setStroke(dp(1), pal.accent);
        tiles.add(tile("Add", addBg, R.drawable.ic_plus, null, null, this::promptAddSite, null, fg));

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < tiles.size(); i += 5) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int j = 0; j < 5; j++) {
                View v = i + j < tiles.size() ? tiles.get(i + j) : new View(this);
                row.addView(v, new LinearLayout.LayoutParams(0, -2, 1));
            }
            grid.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2);
        gp.topMargin = dp(26);
        homeBox.addView(grid, gp);

        if (store.showIndia()) {
            LinearLayout in = indiaLine(homeSub(), 13);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-2, -2);
            ip.topMargin = dp(34);
            homeBox.addView(in, ip);
        }
    }

    private View quick(int res, String label, final Runnable r) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER_HORIZONTAL);
        v.setPadding(0, dp(6), 0, dp(6));
        v.addView(Ui.icon(this, res, 30, homeFg()));
        TextView t = Ui.oneLine(Ui.text(this, tr(label), 13, homeFg(), false));
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(8), 0, 0);
        v.addView(t, new LinearLayout.LayoutParams(-1, -2));
        v.setOnClickListener(x -> r.run());
        return v;
    }

    private View tile(String name, GradientDrawable bg, int iconRes, String letter, String assetPath,
                      final Runnable click, final Runnable longClick, int labelColor) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setPadding(dp(2), dp(9), dp(2), dp(9));

        FrameLayout box = new FrameLayout(this);
        box.setBackground(bg);
        box.setElevation(dp(2));
        Bitmap real = assetPath == null ? null : assetBitmap(assetPath);
        if (real != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(real);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(bg);
            iv.setClipToOutline(true);
            box.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        } else if (letter != null) {
            TextView l = Ui.text(this, letter, 22, pal.accent, true);
            l.setGravity(Gravity.CENTER);
            box.addView(l, new FrameLayout.LayoutParams(-1, -1));
        } else if (iconRes != 0) {
            int tint = iconRes == R.drawable.ic_plus ? pal.accent : 0;
            ImageView ic = Ui.icon(this, iconRes, 28, tint);
            box.addView(ic, new FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER));
        }
        t.addView(box, new LinearLayout.LayoutParams(dp(52), dp(52)));

        TextView n = Ui.oneLine(Ui.text(this, name, 12, labelColor, false));
        n.setGravity(Gravity.CENTER);
        n.setPadding(0, dp(6), 0, 0);
        t.addView(n, new LinearLayout.LayoutParams(-1, -2));

        t.setOnClickListener(v -> click.run());
        if (longClick != null) {
            t.setOnLongClickListener(v -> {
                longClick.run();
                return true;
            });
        }
        return t;
    }

    private void promptAddSite() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText name = new EditText(this);
        name.setHint("Name (jaise Hotstar)");
        name.setSingleLine(true);
        final EditText addr = new EditText(this);
        addr.setHint("https://example.com");
        addr.setSingleLine(true);
        addr.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        l.addView(name);
        l.addView(addr);
        new AlertDialog.Builder(this).setTitle("Add to home").setView(l)
                .setPositiveButton("Add", (d, which) -> {
                    String nm = name.getText().toString().trim();
                    String ad = addr.getText().toString().trim();
                    if (ad.isEmpty()) {
                        toast("Address daalo");
                        return;
                    }
                    String url = toUrl(ad);
                    if (nm.isEmpty()) nm = host(url);
                    store.add("bm", nm, url, 100, false);
                    refreshHome();
                    refreshPanel();
                    toast(nm + " home par add ho gaya");
                }).setNegativeButton("Cancel", null).show();
    }

    private void addBookmark() {
        if (cur.home) {
            promptAddSite();
        } else {
            String t = cur.title == null || cur.title.isEmpty() ? host(cur.url) : cur.title;
            store.add("bm", t, cur.url, 100, false);
            refreshHome();
            toast("Bookmark save ho gaya");
        }
    }

    /* ------------------------------------------------------------------ */
    /* Tabs and WebView                                                   */
    /* ------------------------------------------------------------------ */

    private Tab newTab() {
        Tab t = new Tab();
        t.web = makeWeb(t);
        webHolder.addView(t.web, new FrameLayout.LayoutParams(-1, -1));
        tabs.add(t);
        switchTo(t);
        return t;
    }

    private void switchTo(Tab t) {
        if (cur != null && cur != t) {
            captureThumb(cur);
            cur.web.onPause();
        }
        cur = t;
        t.web.onResume();
        showCurrent();
    }

    private void showCurrent() {
        for (Tab t : tabs) t.web.setVisibility(t == cur && !t.home ? View.VISIBLE : View.GONE);
        homeView.setVisibility(cur.home ? View.VISIBLE : View.GONE);
        webHolder.setVisibility(cur.home ? View.GONE : View.VISIBLE);
        urlEdit.setText(cur.home ? "" : cur.url);
        urlEdit.clearFocus();
        updateTabBtn();
        loading = false;
        progress.setVisibility(View.INVISIBLE);
        btnRefresh.setImageResource(R.drawable.ic_refresh);
        videoFab.setVisibility(View.GONE);
        videoUrl = null;
        applyBars();
        updateNav();
    }

    private void updateNav() {
        btnBack.setAlpha(cur.home && tabs.size() < 2 ? 0.35f : 1f);
        btnFwd.setAlpha(!cur.home && cur.web.canGoForward() ? 1f : 0.35f);
    }

    private void loadIn(Tab t, String url) {
        t.home = false;
        t.url = url;
        if (t == cur) showCurrent();
        t.web.loadUrl(url);
    }

    private void closeTab(Tab t) {
        int idx = tabs.indexOf(t);
        closedUrls.add(t.home ? "" : t.url);
        tabs.remove(t);
        webHolder.removeView(t.web);
        t.web.destroy();
        if (tabs.isEmpty()) {
            newTab();
        } else if (cur == t) {
            switchTo(tabs.get(Math.max(0, idx - 1)));
        } else {
            showCurrent();
        }
    }

    private void goBack() {
        if (!cur.home) {
            if (cur.web.canGoBack()) {
                cur.web.goBack();
            } else {
                cur.home = true;
                showCurrent();
            }
        } else if (tabs.size() > 1) {
            closeTab(cur);
        } else {
            confirmExit();
        }
    }

    private void confirmExit() {
        new AlertDialog.Builder(this).setTitle("Exit S.R Browser?")
                .setPositiveButton("Exit", (d, w) -> finishAffinity())
                .setNegativeButton("Stay", null).show();
    }

    private void applyWebPrefs(WebView w) {
        WebSettings s = w.getSettings();
        s.setTextZoom(SIZE_ZOOM[Math.max(0, Math.min(2, store.textSize()))]);
        s.setUserAgentString(store.desktop() ? DESKTOP_UA : mobileUa);
        s.setJavaScriptEnabled(store.js());
        s.setBlockNetworkImage(store.dataSaver());
    }

    private void applyAllWebPrefs() {
        for (Tab t : tabs) applyWebPrefs(t.web);
    }

    private boolean isAdHost(String h) {
        if (h == null) return false;
        for (String a : AD_HOSTS) if (h.equals(a) || h.endsWith("." + a)) return true;
        return false;
    }

    private boolean isVideoPage(String url) {
        if (url == null) return false;
        String u = url.toLowerCase();
        return u.contains("youtube.com/watch") || u.contains("youtu.be/") || u.contains("vimeo.com/")
                || u.contains("dailymotion.com/video") || u.contains(".mp4") || u.contains(".m3u8")
                || u.contains(".webm") || u.contains("/reel") || u.contains("/shorts/");
    }

    private WebView makeWeb(final Tab t) {
        final WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        applyWebPrefs(w);
        w.setBackgroundColor(Color.WHITE);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);

        w.setDownloadListener((url, ua, cd, mime, len) -> startDownload(url, ua, cd, mime));

        w.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (store.adblock() && isAdHost(r.getUrl().getHost())) {
                    return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String sc = r.getUrl().getScheme();
                if (sc == null) return false;
                if (sc.equals("http") || sc.equals("https") || sc.equals("about")
                        || sc.equals("data") || sc.equals("blob") || sc.equals("javascript")) {
                    return false;
                }
                if (sc.equals("file")) return true;
                try {
                    Intent in;
                    if (sc.equals("intent")) in = Intent.parseUri(r.getUrl().toString(), Intent.URI_INTENT_SCHEME);
                    else in = new Intent(Intent.ACTION_VIEW, r.getUrl());
                    in.addCategory(Intent.CATEGORY_BROWSABLE);
                    in.setComponent(null);
                    in.setSelector(null);
                    startActivity(in);
                } catch (Exception e) {
                    toast("Is link ke liye app nahi mili");
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap fav) {
                t.url = url;
                if (t == cur) {
                    videoFab.setVisibility(View.GONE);
                    videoUrl = null;
                    if (!urlEdit.hasFocus()) urlEdit.setText(url);
                }
            }

            @Override
            public void onPageFinished(final WebView v, String url) {
                t.url = url;
                String title = v.getTitle();
                t.title = title == null || title.isEmpty() ? host(url) : title;
                if (t == cur && !urlEdit.hasFocus()) urlEdit.setText(url);
                if (!store.incognito() && url != null && url.startsWith("http")) {
                    store.add("hist", t.title, url, 200, true);
                    if (isVideoPage(url)) store.add("vhist", t.title, url, 200, true);
                }
                if (t == cur) {
                    updateNav();
                    if (store.detectVideo()) {
                        detectVideo(t);
                        ui.postDelayed(() -> detectVideo(t), 2500);
                        ui.postDelayed(() -> detectVideo(t), 6000);
                    }
                }
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) {
                    String u = r.getUrl().toString();
                    String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                            + "<body style='font-family:sans-serif;text-align:center;padding:56px 18px;color:#555'>"
                            + "<h2>Page nahi khul paya</h2><p>" + TextUtils.htmlEncode(String.valueOf(e.getDescription()))
                            + "</p><p><a href='" + TextUtils.htmlEncode(u) + "'>Dobara try karo</a></p></body></html>";
                    v.loadDataWithBaseURL(u, html, "text/html", "utf-8", u);
                }
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (t != cur) return;
                loading = p < 100;
                progress.setProgress(p);
                progress.setVisibility(loading ? View.VISIBLE : View.INVISIBLE);
                btnRefresh.setImageResource(loading ? R.drawable.ic_close : R.drawable.ic_refresh);
            }

            @Override
            public void onReceivedTitle(WebView v, String title) {
                if (title != null && !title.isEmpty()) t.title = title;
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean dialog, boolean gesture, Message msg) {
                if (store.popupBlock() && !gesture) return false;
                Tab nt = newTab();
                nt.home = false;
                showCurrent();
                WebView.WebViewTransport tr = (WebView.WebViewTransport) msg.obj;
                tr.setWebView(nt.web);
                msg.sendToTarget();
                return true;
            }

            @Override
            public void onShowCustomView(View v, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = v;
                customCb = cb;
                v.setBackgroundColor(Color.BLACK);
                screen.addView(v, new FrameLayout.LayoutParams(-1, -1));
                root.setVisibility(View.GONE);
                applySystemUi();
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    toast("File chunne ke liye app nahi mili");
                    return false;
                }
                return true;
            }
        });

        w.setOnLongClickListener(v -> {
            WebView.HitTestResult hr = w.getHitTestResult();
            String extra = hr.getExtra();
            int type = hr.getType();
            if (extra == null) return false;
            if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                linkMenu(extra, false);
                return true;
            }
            if (type == WebView.HitTestResult.IMAGE_TYPE) {
                linkMenu(extra, true);
                return true;
            }
            return false;
        });
        return w;
    }

    /** Looks for a direct video file on the page and shows the Download video button. */
    private void detectVideo(final Tab t) {
        if (t != cur || t.home) return;
        String js = "(function(){var v=document.querySelector('video');if(!v)return '';"
                + "var s=v.currentSrc||v.src||'';if(!s){var o=v.querySelector('source');if(o)s=o.src;}return s||'';})()";
        t.web.evaluateJavascript(js, value -> {
            if (t != cur || value == null) return;
            String s = value.replace("\"", "").replace("\\u0026", "&").replace("\\/", "/");
            if (s.startsWith("http")) {
                videoUrl = s;
                videoFab.setVisibility(View.VISIBLE);
            }
        });
    }

    private void hideCustom() {
        if (customView == null) return;
        screen.removeView(customView);
        customView = null;
        root.setVisibility(View.VISIBLE);
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        applySystemUi();
    }

    private void linkMenu(final String url, boolean image) {
        final String[] items = image
                ? new String[]{"Image naye tab mein kholo", "Image download karo", "Link copy karo"}
                : new String[]{"Naye tab mein kholo", "Link copy karo"};
        new AlertDialog.Builder(this).setItems(items, (d, which) -> {
            String pick = items[which];
            if (pick.startsWith("Link")) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("link", url));
                toast("Link copy ho gaya");
            } else if (pick.startsWith("Image download")) {
                startDownload(url, mobileUa, null, null);
            } else {
                Tab nt = newTab();
                loadIn(nt, url);
            }
        }).show();
    }

    private void startDownload(final String url, final String ua, final String cd, final String mime) {
        final String name = URLUtil.guessFileName(url, cd, mime);
        if (store.askDownload()) {
            new AlertDialog.Builder(this).setTitle("Download karein?").setMessage(name)
                    .setPositiveButton("Download", (d, w) -> enqueue(url, ua, mime, name))
                    .setNegativeButton("Cancel", null).show();
        } else {
            enqueue(url, ua, mime, name);
        }
    }

    private void enqueue(String url, String ua, String mime, String name) {
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (mime != null && !mime.isEmpty()) r.setMimeType(mime);
            if (ua != null) r.addRequestHeader("User-Agent", ua);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) r.addRequestHeader("Cookie", cookie);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            long id = dm.enqueue(r);
            store.add("dl", name, String.valueOf(id), 300, true);
            toast("Download shuru: " + name);
        } catch (Exception e) {
            toast("Download nahi ho paya");
        }
    }

    /* ------------------------------------------------------------------ */
    /* Address bar                                                        */
    /* ------------------------------------------------------------------ */

    private void hideKb(View v) {
        InputMethodManager m = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (m != null) m.hideSoftInputFromWindow(v.getWindowToken(), 0);
    }

    private void submitFrom(EditText e) {
        String q = e.getText().toString().trim();
        if (q.isEmpty()) return;
        hideKb(e);
        e.clearFocus();
        loadIn(cur, toUrl(q));
        if (e == homeEdit) e.setText("");
    }

    private String toUrl(String q) {
        if (q.startsWith("http://") || q.startsWith("https://")) return q;
        if (!q.contains(" ") && q.contains(".") && Patterns.WEB_URL.matcher(q).matches()) return "https://" + q;
        return searchUrl(q);
    }

    private String searchUrl(String q) {
        String e = store.engine();
        String en = Uri.encode(q);
        switch (e) {
            case "bing":
                if (mode == 1) return "https://www.bing.com/videos/search?q=" + en;
                if (mode == 2) return "https://www.bing.com/images/search?q=" + en;
                return "https://www.bing.com/search?q=" + en;
            case "ddg":
                if (mode == 1) return "https://duckduckgo.com/?q=" + en + "&iax=videos&ia=videos";
                if (mode == 2) return "https://duckduckgo.com/?q=" + en + "&iax=images&ia=images";
                return "https://duckduckgo.com/?q=" + en;
            case "yahoo":
                return "https://search.yahoo.com/search?p=" + en;
            default:
                if (mode == 1) return "https://www.google.com/search?q=" + en + "&tbm=vid";
                if (mode == 2) return "https://www.google.com/search?q=" + en + "&tbm=isch";
                return "https://www.google.com/search?q=" + en;
        }
    }

    private String host(String url) {
        try {
            String h = Uri.parse(url).getHost();
            return h == null ? url : h.replaceFirst("^www\\.", "");
        } catch (Exception e) {
            return url;
        }
    }

    private void pickEngine() {
        String[] names = new String[ENGINES.length];
        int sel = 0;
        for (int i = 0; i < ENGINES.length; i++) {
            names[i] = ENGINES[i][1];
            if (ENGINES[i][0].equals(store.engine())) sel = i;
        }
        new AlertDialog.Builder(this).setTitle("Search engine")
                .setSingleChoiceItems(names, sel, (d, which) -> {
                    store.setEngine(ENGINES[which][0]);
                    d.dismiss();
                    refreshHome();
                    refreshPanel();
                }).show();
    }

    /* ------------------------------------------------------------------ */
    /* Menu sheet (UC style)                                              */
    /* ------------------------------------------------------------------ */

    private void buildSheet() {
        scrim = new View(this);
        scrim.setBackgroundColor(0x99000000);
        scrim.setVisibility(View.GONE);
        scrim.setOnClickListener(v -> closeMenu());
        screen.addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        sheetBox = new LinearLayout(this);
        sheetBox.setOrientation(LinearLayout.VERTICAL);
        sheetBox.setBackground(Ui.roundTop(this, pal.sheet, 26));
        sheetBox.setVisibility(View.GONE);
        sheetBox.setClickable(true);
        sheetBox.setPadding(dp(18), dp(20), dp(18), dp(4));
        screen.addView(sheetBox, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
    }

    private void openMenu() {
        if (sheetBox.getVisibility() == View.VISIBLE) {
            closeMenu();
            return;
        }
        fillMenu();
        scrim.setVisibility(View.VISIBLE);
        sheetBox.setVisibility(View.VISIBLE);
    }

    private void closeMenu() {
        scrim.setVisibility(View.GONE);
        sheetBox.setVisibility(View.GONE);
    }

    private void fillMenu() {
        sheetBox.removeAllViews();

        // Header: logo avatar, SR Center, Made in India, incognito pill
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        FrameLayout av = new FrameLayout(this);
        av.setBackground(Ui.round(this, 0xFFFFFFFF, 14));
        av.setPadding(dp(5), dp(5), dp(5), dp(5));
        ImageView ai = new ImageView(this);
        ai.setImageResource(R.drawable.logo);
        ai.setScaleType(ImageView.ScaleType.FIT_CENTER);
        av.addView(ai, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams avp = new LinearLayout.LayoutParams(dp(50), dp(50));
        avp.rightMargin = dp(12);
        head.addView(av, avp);
        LinearLayout hc = new LinearLayout(this);
        hc.setOrientation(LinearLayout.VERTICAL);
        hc.addView(Ui.text(this, tr("SR Center"), 18, pal.fg, true));
        LinearLayout in = indiaLine(pal.muted, 12.5f);
        in.setGravity(Gravity.START);
        in.setPadding(0, dp(3), 0, 0);
        hc.addView(in);
        head.addView(hc, new LinearLayout.LayoutParams(0, -2, 1));

        boolean inc = store.incognito();
        FrameLayout ghost = new FrameLayout(this);
        ghost.setBackground(Ui.round(this, inc ? PURPLE : pal.surface, 24));
        ghost.addView(Ui.icon(this, R.drawable.ic_ghost, 26, inc ? 0xFFFFFFFF : pal.fg),
                new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        ghost.setOnClickListener(v -> {
            store.setIncognito(!store.incognito());
            updateTabBtn();
            toast(store.incognito() ? "Incognito on" : "Incognito off");
            fillMenu();
        });
        head.addView(ghost, new LinearLayout.LayoutParams(dp(92), dp(46)));
        sheetBox.addView(head, new LinearLayout.LayoutParams(-1, -2));

        // Row 1: colour circles
        LinearLayout r1 = new LinearLayout(this);
        r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.addView(menuItem(R.drawable.ic_bookmark_o, "Bookmarks", 0xFF19C9A6, false, false, this::openBookmarks), new LinearLayout.LayoutParams(0, -2, 1));
        r1.addView(menuItem(R.drawable.ic_clock, "History", 0xFFFFB400, false, false, this::openHistory), new LinearLayout.LayoutParams(0, -2, 1));
        r1.addView(menuItem(R.drawable.ic_download, "Downloads", 0xFF3B82F6, false, false, this::openDownloader), new LinearLayout.LayoutParams(0, -2, 1));
        r1.addView(menuItem(R.drawable.ic_tshirt, "Themes", 0xFFF0508A, false, false, this::openThemes), new LinearLayout.LayoutParams(0, -2, 1));
        r1.addView(menuItem(R.drawable.ic_wrench, "More Tools", 0xFF8B5CF6, false, false, this::openMoreTools), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams r1p = new LinearLayout.LayoutParams(-1, -2);
        r1p.topMargin = dp(24);
        sheetBox.addView(r1, r1p);

        // Row 2: plain icons
        LinearLayout r2 = new LinearLayout(this);
        r2.setOrientation(LinearLayout.HORIZONTAL);
        r2.addView(menuItem(R.drawable.ic_star, "Add to Bookmarks", 0, false, cur.home, this::addBookmark), new LinearLayout.LayoutParams(0, -2, 1));
        r2.addView(menuItem(R.drawable.ic_moon, "Night", 0, pal.night, false, () -> {
            store.setNight(!store.night());
            recreate();
        }), new LinearLayout.LayoutParams(0, -2, 1));
        r2.addView(menuItem(R.drawable.ic_refresh, "Refresh", 0, false, cur.home, () -> cur.web.reload()), new LinearLayout.LayoutParams(0, -2, 1));
        r2.addView(menuItem(R.drawable.ic_feedback, "Feedback", 0, false, false, this::feedback), new LinearLayout.LayoutParams(0, -2, 1));
        r2.addView(menuItem(R.drawable.ic_sharebox, "Share", 0, false, false, this::share), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams r2p = new LinearLayout.LayoutParams(-1, -2);
        r2p.topMargin = dp(22);
        r2p.bottomMargin = dp(16);
        sheetBox.addView(r2, r2p);

        View line = new View(this);
        line.setBackgroundColor(pal.line);
        sheetBox.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        View b1 = barBtn(R.drawable.ic_hexgear, () -> {
            closeMenu();
            openSettings();
        });
        View b2 = barBtn(R.drawable.ic_chevron, this::closeMenu);
        View b3 = barBtn(R.drawable.ic_power, () -> {
            closeMenu();
            confirmExit();
        });
        bar.addView(b1, new LinearLayout.LayoutParams(0, dp(54), 1));
        bar.addView(b2, new LinearLayout.LayoutParams(0, dp(54), 1));
        bar.addView(b3, new LinearLayout.LayoutParams(0, dp(54), 1));
        sheetBox.addView(bar, new LinearLayout.LayoutParams(-1, -2));
    }

    private View menuItem(int icon, String label, int circle, boolean on, boolean off, final Runnable action) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout holder = new FrameLayout(this);
        if (circle != 0) {
            holder.setBackground(oval(circle));
            holder.addView(Ui.icon(this, icon, 26, Color.WHITE), new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
        } else {
            holder.addView(Ui.icon(this, icon, 30, on ? pal.accent : pal.icon), new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER));
        }
        v.addView(holder, new LinearLayout.LayoutParams(dp(54), dp(54)));
        TextView t = Ui.text(this, tr(label), 12, on ? pal.accent : (circle != 0 ? pal.fg : pal.icon), false);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(2);
        t.setPadding(0, dp(7), 0, 0);
        v.addView(t, new LinearLayout.LayoutParams(-1, -2));
        v.setAlpha(off ? 0.35f : 1f);
        if (!off) {
            v.setOnClickListener(x -> {
                closeMenu();
                action.run();
            });
        }
        return v;
    }

    private void share() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, cur.home ? "S.R Browser - Made in India" : cur.url);
        startActivity(Intent.createChooser(i, "Share"));
    }

    private void feedback() {
        final EditText e = new EditText(this);
        e.setHint("Apna feedback likho");
        e.setMinLines(3);
        e.setGravity(Gravity.TOP);
        LinearLayout l = new LinearLayout(this);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        l.addView(e, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this).setTitle(tr("Feedback")).setView(l)
                .setPositiveButton("Send", (d, w) -> {
                    String m = e.getText().toString().trim();
                    if (m.isEmpty()) return;
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_SUBJECT, "S.R Browser feedback");
                    i.putExtra(Intent.EXTRA_TEXT, m);
                    startActivity(Intent.createChooser(i, "Send feedback"));
                }).setNegativeButton("Cancel", null).show();
    }

    private void cycleSize() {
        int n = (store.textSize() + 1) % 3;
        store.setTextSize(n);
        applyAllWebPrefs();
        toast("Text size: " + SIZE_NAMES[n]);
    }

    private void toggleDesktop(boolean v) {
        store.setDesktop(v);
        applyAllWebPrefs();
        if (!cur.home) cur.web.reload();
    }

    private void about() {
        new AlertDialog.Builder(this).setTitle("S.R Browser")
                .setMessage("Version 1.1\n" + tr("Made in India") + "\nSearch, videos, social aur shopping ek hi jagah.")
                .setPositiveButton("OK", null).show();
    }

    /* ------------------------------------------------------------------ */
    /* Tab switcher (UC style)                                            */
    /* ------------------------------------------------------------------ */

    private void captureThumb(Tab t) {
        try {
            View v = t.home ? homeView : t.web;
            int w = v.getWidth(), h = v.getHeight();
            if (w <= 0 || h <= 0 || v.getVisibility() != View.VISIBLE) return;
            Bitmap b = Bitmap.createBitmap(w / 2, h / 2, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            c.scale(0.5f, 0.5f);
            v.draw(c);
            t.thumb = b;
        } catch (Throwable ignored) {
        }
    }

    private void openTabs() {
        if (cur != null) captureThumb(cur);
        buildTabsView();
    }

    private void closeTabsView() {
        if (tabsView != null) {
            screen.removeView(tabsView);
            tabsView = null;
        }
        showCurrent();
    }

    private void buildTabsView() {
        if (tabsView != null) screen.removeView(tabsView);
        final boolean inc = store.incognito();
        int bg = inc ? 0xFF272240 : 0xFF3A3A3C;
        final int ac = inc ? PURPLE : Pal.RED;
        int sw = getResources().getDisplayMetrics().widthPixels;
        int sh = getResources().getDisplayMetrics().heightPixels;

        FrameLayout f = new FrameLayout(this);
        f.setBackgroundColor(bg);
        f.setClickable(true);

        ImageView more = Ui.icon(this, R.drawable.ic_dots, 26, 0xFFFFFFFF);
        more.setPadding(dp(10), dp(10), dp(10), dp(10));
        FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP | Gravity.END);
        mp.topMargin = dp(36);
        mp.rightMargin = dp(8);
        more.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setItems(new String[]{"Saare tabs band karo"}, (d, which) -> {
                    List<Tab> copy = new ArrayList<>(tabs);
                    for (Tab t : copy) closeTab(t);
                    buildTabsView();
                }).show());
        f.addView(more, mp);

        if (inc) {
            LinearLayout info = new LinearLayout(this);
            info.setOrientation(LinearLayout.VERTICAL);
            info.setGravity(Gravity.CENTER_HORIZONTAL);
            info.setPadding(dp(20), dp(80), dp(20), 0);
            info.addView(Ui.text(this, tr("Incognito mode on"), 19, 0xFFFFFFFF, false));
            TextView d = Ui.text(this, "Browsing history aur search history save nahi hogi. Downloaded files aur bookmarks bachenge.", 13.5f, 0xCCFFFFFF, false);
            d.setGravity(Gravity.CENTER);
            d.setPadding(0, dp(8), 0, 0);
            info.addView(d);
            f.addView(info, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        }

        int cardW = (int) (sw * 0.62f);
        int cardH = (int) Math.min(cardW * 1.9f, sh * 0.52f);
        int gap = dp(18);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout rowL = new LinearLayout(this);
        rowL.setOrientation(LinearLayout.HORIZONTAL);
        rowL.setPadding((sw - cardW) / 2, 0, (sw - cardW) / 2, 0);
        int curIdx = Math.max(0, tabs.indexOf(cur));
        for (final Tab t : new ArrayList<>(tabs)) {
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);

            LinearLayout tl = new LinearLayout(this);
            tl.setOrientation(LinearLayout.HORIZONTAL);
            tl.setGravity(Gravity.CENTER_VERTICAL);
            View bar = new View(this);
            bar.setBackgroundColor(ac);
            tl.addView(bar, new LinearLayout.LayoutParams(dp(2), dp(18)));
            String title = t.home ? "S.R Browser" : (t.title == null || t.title.isEmpty() ? host(t.url) : t.title);
            TextView tt = Ui.oneLine(Ui.text(this, title, 16, ac, false));
            tt.setPadding(dp(8), 0, 0, 0);
            tl.addView(tt, new LinearLayout.LayoutParams(0, -2, 1));
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(cardW, -2);
            tlp.bottomMargin = dp(10);
            col.addView(tl, tlp);

            FrameLayout card = new FrameLayout(this);
            card.setBackground(Ui.round(this, pal.bg, 6));
            card.setClipToOutline(true);
            if (t.thumb != null) {
                ImageView iv = new ImageView(this);
                iv.setImageBitmap(t.thumb);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                card.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            } else {
                String hn = t.home ? "S.R" : host(t.url);
                String letter = hn.isEmpty() ? "?" : hn.substring(0, 1).toUpperCase();
                TextView l = Ui.text(this, letter, 40, pal.accent, true);
                l.setGravity(Gravity.CENTER);
                card.addView(l, new FrameLayout.LayoutParams(-1, -1));
            }
            FrameLayout bottom = new FrameLayout(this);
            bottom.setBackgroundColor(0xAA000000);
            ImageView x = Ui.icon(this, R.drawable.ic_close, 26, 0xFFFFFFFF);
            bottom.addView(x, new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER));
            bottom.setOnClickListener(v -> {
                closeTab(t);
                buildTabsView();
            });
            card.addView(bottom, new FrameLayout.LayoutParams(-1, dp(52), Gravity.BOTTOM));
            card.setOnClickListener(v -> {
                switchTo(t);
                closeTabsView();
            });
            col.addView(card, new LinearLayout.LayoutParams(cardW, cardH));

            LinearLayout.LayoutParams colp = new LinearLayout.LayoutParams(-2, -2);
            colp.rightMargin = gap;
            rowL.addView(col, colp);
        }
        hs.addView(rowL, new ViewGroup.LayoutParams(-2, -2));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER_VERTICAL);
        hp.topMargin = dp(inc ? 70 : 20);
        f.addView(hs, hp);
        final int scrollTo = curIdx * (cardW + gap);
        hs.post(() -> hs.scrollTo(scrollTo, 0));

        // Bottom: incognito, new tab, undo
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);

        FrameLayout g = new FrameLayout(this);
        g.addView(Ui.icon(this, R.drawable.ic_ghost, 32, inc ? PURPLE : 0xFFFFFFFF),
                new FrameLayout.LayoutParams(dp(32), dp(32), Gravity.CENTER));
        g.setOnClickListener(v -> {
            store.setIncognito(!store.incognito());
            updateTabBtn();
            buildTabsView();
        });
        bar.addView(g, new LinearLayout.LayoutParams(dp(64), dp(64)));

        FrameLayout plus = new FrameLayout(this);
        plus.setBackground(oval(ac));
        plus.addView(Ui.icon(this, R.drawable.ic_plus, 34, 0xFFFFFFFF), new FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER));
        plus.setElevation(dp(4));
        plus.setOnClickListener(v -> {
            closeTabsView();
            newTab();
        });
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(dp(66), dp(66));
        plp.leftMargin = dp(28);
        plp.rightMargin = dp(28);
        bar.addView(plus, plp);

        FrameLayout u = new FrameLayout(this);
        u.addView(Ui.icon(this, R.drawable.ic_undo, 30, 0xFFFFFFFF), new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER));
        u.setOnClickListener(v -> {
            if (closedUrls.isEmpty()) {
                toast("Koi band tab nahi hai");
                return;
            }
            String last = closedUrls.remove(closedUrls.size() - 1);
            Tab nt = newTab();
            if (!last.isEmpty()) loadIn(nt, last);
            buildTabsView();
        });
        bar.addView(u, new LinearLayout.LayoutParams(dp(64), dp(64)));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        bp.bottomMargin = dp(36);
        f.addView(bar, bp);

        tabsView = f;
        screen.addView(f, new FrameLayout.LayoutParams(-1, -1));
    }

    /* ------------------------------------------------------------------ */
    /* Panels (stack)                                                     */
    /* ------------------------------------------------------------------ */

    private PanelState openPanel(String title, String rightLabel, Runnable rightAction,
                                 String bottomLabel, Runnable bottomAction, Renderer r) {
        final PanelState ps = new PanelState();
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackgroundColor(pal.bg);
        p.setClickable(true);

        FrameLayout head = new FrameLayout(this);
        head.setBackgroundColor(pal.bg);
        ImageView back = Ui.icon(this, R.drawable.ic_back, 26, pal.fg);
        back.setPadding(dp(10), dp(10), dp(10), dp(10));
        back.setOnClickListener(v -> closePanel());
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER_VERTICAL | Gravity.START);
        bl.leftMargin = dp(6);
        head.addView(back, bl);
        TextView tt = Ui.text(this, title, 19, pal.fg, true);
        head.addView(tt, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        if (rightLabel != null) {
            TextView a = Ui.text(this, rightLabel, 14.5f, pal.accent, true);
            a.setPadding(dp(10), dp(10), dp(10), dp(10));
            a.setOnClickListener(v -> rightAction.run());
            FrameLayout.LayoutParams al = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_VERTICAL | Gravity.END);
            al.rightMargin = dp(10);
            head.addView(a, al);
        }
        p.addView(head, new LinearLayout.LayoutParams(-1, dp(56)));

        ScrollView sv = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(6), dp(14), dp(24));
        sv.addView(body, new ViewGroup.LayoutParams(-1, -2));
        p.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        if (bottomLabel != null) {
            View line = new View(this);
            line.setBackgroundColor(pal.line);
            p.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
            TextView bt = Ui.text(this, bottomLabel, 17, pal.muted, false);
            bt.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
            bt.setPadding(dp(24), 0, dp(24), 0);
            bt.setBackgroundColor(pal.bar);
            bt.setOnClickListener(v -> bottomAction.run());
            p.addView(bt, new LinearLayout.LayoutParams(-1, dp(58)));
        }

        ps.view = p;
        ps.body = body;
        ps.renderer = r;
        ps.id = title;
        panels.add(ps);
        screen.addView(p, new FrameLayout.LayoutParams(-1, -1));
        r.render(body);
        return ps;
    }

    private PanelState openPanel(String title, String rightLabel, Runnable rightAction, Renderer r) {
        return openPanel(title, rightLabel, rightAction, null, null, r);
    }

    private void refreshPanel() {
        if (panels.isEmpty()) return;
        PanelState ps = panels.get(panels.size() - 1);
        ps.body.removeAllViews();
        ps.renderer.render(ps.body);
    }

    private void closePanel() {
        if (panels.isEmpty()) return;
        PanelState ps = panels.remove(panels.size() - 1);
        screen.removeView(ps.view);
        refreshPanel();
    }

    private void closeAllPanels() {
        while (!panels.isEmpty()) {
            PanelState ps = panels.remove(panels.size() - 1);
            screen.removeView(ps.view);
        }
    }

    private LinearLayout card(LinearLayout body) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Ui.round(this, pal.surface, 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(14);
        body.addView(c, lp);
        return c;
    }

    private void emptyState(LinearLayout body, int icon, String msg) {
        LinearLayout e = new LinearLayout(this);
        e.setOrientation(LinearLayout.VERTICAL);
        e.setGravity(Gravity.CENTER);
        e.setPadding(dp(16), dp(90), dp(16), dp(40));
        if (icon != 0) {
            ImageView iv = Ui.icon(this, icon, 84, pal.line);
            e.addView(iv, new LinearLayout.LayoutParams(dp(84), dp(84)));
        }
        TextView t = Ui.text(this, msg, 17, pal.muted, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(18), 0, 0);
        e.addView(t);
        body.addView(e, new LinearLayout.LayoutParams(-1, -2));
    }

    private void renderRows(LinearLayout body, List<Row> rows, String empty, int emptyIcon) {
        if (rows.isEmpty()) {
            emptyState(body, emptyIcon, empty);
            return;
        }
        LinearLayout c = card(body);
        for (int i = 0; i < rows.size(); i++) {
            final Row r = rows.get(i);
            if (i > 0) {
                View d = new View(this);
                d.setBackgroundColor(pal.line);
                c.addView(d, new LinearLayout.LayoutParams(-1, dp(1)));
            }
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(11), dp(8), dp(11));

            FrameLayout ib = new FrameLayout(this);
            ib.setBackground(Ui.round(this, pal.surface2, 11));
            if (r.icon != 0) {
                ib.addView(Ui.icon(this, r.icon, 20, pal.accent), new FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER));
            } else {
                String l = r.title.isEmpty() ? "?" : r.title.substring(0, 1).toUpperCase();
                TextView lt = Ui.text(this, l, 16, pal.accent, true);
                lt.setGravity(Gravity.CENTER);
                ib.addView(lt, new FrameLayout.LayoutParams(-1, -1));
            }
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(38), dp(38));
            ip.rightMargin = dp(12);
            row.addView(ib, ip);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(Ui.oneLine(Ui.text(this, r.title, 15, pal.fg, true)));
            if (r.sub != null && !r.sub.isEmpty()) col.addView(Ui.oneLine(Ui.text(this, r.sub, 12, pal.muted, false)));
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));

            if (r.delete != null) {
                ImageView x = Ui.icon(this, R.drawable.ic_close, 20, pal.muted);
                x.setPadding(dp(10), dp(10), dp(10), dp(10));
                x.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
                x.setOnClickListener(v -> r.delete.run());
                row.addView(x);
            }
            row.setOnClickListener(v -> {
                if (r.click != null) r.click.run();
            });
            c.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    /* ---- Bookmarks ---- */

    private void openBookmarks() {
        openPanel(tr("Bookmarks"), "+ Add", this::promptAddSite, body -> {
            List<Row> rows = new ArrayList<>();
            List<Store.Item> l = store.list("bm");
            for (int i = 0; i < l.size(); i++) {
                final Store.Item it = l.get(i);
                final int idx = i;
                rows.add(new Row(it.title, host(it.url), 0, () -> {
                    closeAllPanels();
                    loadIn(cur, it.url);
                }, () -> {
                    store.remove("bm", idx);
                    refreshHome();
                    refreshPanel();
                }));
            }
            renderRows(body, rows, "Koi bookmark nahi. Menu ke star se page save karo.", R.drawable.ic_bookmark_o);
        });
    }

    /* ---- History (Video / Website) ---- */

    private void openHistory() {
        openPanel(tr("History"), null, null, tr("Edit"), this::editHistory, this::renderHistory);
    }

    private void editHistory() {
        final String key = histTab == 0 ? "vhist" : "hist";
        new AlertDialog.Builder(this).setTitle(histTab == 0 ? "Video history" : "Website history")
                .setItems(new String[]{"Sab saaf karo"}, (d, which) -> {
                    store.clear(key);
                    refreshPanel();
                }).show();
    }

    private void renderHistory(LinearLayout body) {
        LinearLayout tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {tr("Video"), tr("Website")};
        for (int i = 0; i < 2; i++) {
            final int idx = i;
            LinearLayout c = new LinearLayout(this);
            c.setOrientation(LinearLayout.VERTICAL);
            c.setGravity(Gravity.CENTER_HORIZONTAL);
            TextView t = Ui.text(this, names[i], 18, i == histTab ? pal.fg : pal.muted, i == histTab);
            t.setPadding(0, dp(8), 0, dp(6));
            c.addView(t);
            View u = new View(this);
            u.setBackgroundColor(i == histTab ? pal.fg : Color.TRANSPARENT);
            c.addView(u, new LinearLayout.LayoutParams(dp(48), dp(3)));
            c.setOnClickListener(v -> {
                histTab = idx;
                refreshPanel();
            });
            tabsRow.addView(c, new LinearLayout.LayoutParams(0, -2, 1));
        }
        body.addView(tabsRow, new LinearLayout.LayoutParams(-1, -2));

        List<Row> rows = new ArrayList<>();
        final String key = histTab == 0 ? "vhist" : "hist";
        List<Store.Item> l = store.list(key);
        for (int i = 0; i < l.size(); i++) {
            final Store.Item it = l.get(i);
            final int idx = i;
            rows.add(new Row(it.title, host(it.url), histTab == 0 ? R.drawable.ic_video : 0, () -> {
                closeAllPanels();
                loadIn(cur, it.url);
            }, () -> {
                store.remove(key, idx);
                refreshPanel();
            }));
        }
        LinearLayout holder = new LinearLayout(this);
        holder.setOrientation(LinearLayout.VERTICAL);
        holder.setPadding(0, dp(12), 0, 0);
        body.addView(holder, new LinearLayout.LayoutParams(-1, -2));
        renderRows(holder, rows, histTab == 0 ? "All your player history will be showed here" : "Abhi koi website visit nahi hui",
                R.drawable.ic_video);
    }

    /* ---- Downloader ---- */

    private String dlInfo(long id, boolean[] done) {
        done[0] = false;
        try {
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            Cursor c = dm.query(new DownloadManager.Query().setFilterById(id));
            if (c == null) return "";
            try {
                if (!c.moveToFirst()) return "Hata diya gaya";
                int st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                long got = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
                long total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES));
                if (st == DownloadManager.STATUS_SUCCESSFUL) {
                    done[0] = true;
                    return "Complete" + (total > 0 ? " · " + (total / 1024 / 1024) + " MB" : "");
                }
                if (st == DownloadManager.STATUS_FAILED) return "Fail ho gaya";
                if (st == DownloadManager.STATUS_PAUSED) return "Ruka hua";
                if (st == DownloadManager.STATUS_PENDING) return "Intezaar...";
                return total > 0 ? "Download ho raha hai " + (int) (got * 100 / total) + "%" : "Download ho raha hai...";
            } finally {
                c.close();
            }
        } catch (Exception e) {
            return "";
        }
    }

    private void openDownloadedFile(long id) {
        try {
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            Uri u = dm.getUriForDownloadedFile(id);
            String m = dm.getMimeTypeForDownloadedFile(id);
            if (u == null) {
                toast("File nahi mili");
                return;
            }
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, m);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        } catch (Exception e) {
            toast("Is file ko kholne ke liye app nahi mili");
        }
    }

    private void openDownloader() {
        final PanelState[] holder = new PanelState[1];
        holder[0] = openPanel(tr("Downloads"), "+ Link", this::promptDownloadLink, body -> {
            List<Row> rows = new ArrayList<>();
            List<Store.Item> l = store.list("dl");
            boolean anyActive = false;
            for (int i = 0; i < l.size(); i++) {
                final Store.Item it = l.get(i);
                final int idx = i;
                final long id = Long.parseLong(it.url);
                boolean[] done = new boolean[1];
                String info = dlInfo(id, done);
                if (!done[0] && info.startsWith("Download")) anyActive = true;
                rows.add(new Row(it.title, info, R.drawable.ic_download, () -> {
                    if (done[0]) openDownloadedFile(id);
                }, () -> {
                    try {
                        ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).remove(id);
                    } catch (Exception ignored) {
                    }
                    store.remove("dl", idx);
                    refreshPanel();
                }));
            }
            renderRows(body, rows, "Abhi koi download nahi", R.drawable.ic_dl_hex);
            if (anyActive) {
                ui.postDelayed(() -> {
                    if (!panels.isEmpty() && panels.get(panels.size() - 1) == holder[0]) refreshPanel();
                }, 1500);
            }
        });
    }

    private void promptDownloadLink() {
        final EditText e = new EditText(this);
        e.setHint("https://site.com/file.mp4");
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        LinearLayout l = new LinearLayout(this);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        l.addView(e, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this).setTitle("File ka direct link").setView(l)
                .setPositiveButton("Download", (d, w) -> {
                    String u = e.getText().toString().trim();
                    if (!u.startsWith("http")) {
                        toast("Poora link daalo, https:// ke saath");
                        return;
                    }
                    startDownload(u, mobileUa, null, null);
                    ui.postDelayed(this::refreshPanel, 500);
                }).setNegativeButton("Cancel", null).show();
    }

    /* ---- Notes ---- */

    private void openNotes() {
        openPanel(tr("Notes"), "+ New", () -> editNote(-1), body -> {
            List<Row> rows = new ArrayList<>();
            List<Store.Item> l = store.list("notes");
            for (int i = 0; i < l.size(); i++) {
                final Store.Item it = l.get(i);
                final int idx = i;
                String first = it.title.split("\n")[0];
                rows.add(new Row(first, it.title.length() > first.length() ? it.title.substring(first.length()).trim() : "",
                        R.drawable.ic_notes, () -> editNote(idx), () -> {
                    store.remove("notes", idx);
                    refreshPanel();
                }));
            }
            renderRows(body, rows, "Koi note nahi. + New dabao.", R.drawable.ic_notes);
        });
    }

    private void editNote(final int idx) {
        final EditText e = new EditText(this);
        e.setHint("Note likho");
        e.setMinLines(4);
        e.setGravity(Gravity.TOP);
        if (idx >= 0) e.setText(store.list("notes").get(idx).title);
        LinearLayout l = new LinearLayout(this);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        l.addView(e, new LinearLayout.LayoutParams(-1, -2));
        new AlertDialog.Builder(this).setTitle("Note").setView(l)
                .setPositiveButton("Save", (d, w) -> {
                    String m = e.getText().toString().trim();
                    if (m.isEmpty()) return;
                    if (idx >= 0) store.replace("notes", idx, m, String.valueOf(System.currentTimeMillis()));
                    else store.add("notes", m, String.valueOf(System.currentTimeMillis()), 200, true);
                    refreshPanel();
                }).setNegativeButton("Cancel", null).show();
    }

    /* ---- More tools ---- */

    private void openMoreTools() {
        openPanel(tr("More Tools"), null, null, body -> {
            body.setPadding(0, 0, 0, dp(24));
            flatRow(body, "Desktop Site", "Computer jaisa page dikhao", null, sw(store.desktop(), this::toggleDesktop), null);
            flatRow(body, "Full Screen", null, null, null, () -> {
                closeAllPanels();
                fullscreen = true;
                applySystemUi();
            });
            flatRow(body, "Add-ons", null, null, chev(), this::openAddons);
            flatRow(body, "My Videos", null, null, chev(), this::openVideos);
            flatRow(body, "Text Size", null, SIZE_NAMES[store.textSize()], null, () -> {
                cycleSize();
                refreshPanel();
            });
            flatRow(body, "Clear Cache", null, null, null, () -> {
                for (Tab t : tabs) t.web.clearCache(true);
                toast("Cache saaf ho gaya");
            });
        });
    }

    private void openVideos() {
        openPanel("My Videos", "+ This page", () -> {
            if (cur.home) {
                toast("Pehle koi video page kholo");
                return;
            }
            String t = cur.title == null || cur.title.isEmpty() ? host(cur.url) : cur.title;
            store.add("vid", t, cur.url, 200, true);
            refreshPanel();
            toast("Video save ho gaya");
        }, body -> {
            List<Row> rows = new ArrayList<>();
            List<Store.Item> l = store.list("vid");
            for (int i = 0; i < l.size(); i++) {
                final Store.Item it = l.get(i);
                final int idx = i;
                rows.add(new Row(it.title, host(it.url), R.drawable.ic_video, () -> {
                    closeAllPanels();
                    loadIn(cur, it.url);
                }, () -> {
                    store.remove("vid", idx);
                    refreshPanel();
                }));
            }
            renderRows(body, rows, "Koi video page kholo, phir yahan \"+ This page\" dabao.", R.drawable.ic_video);
        });
    }

    private void openAddons() {
        openPanel("Add-ons", null, null, body -> {
            String[][] a = {
                    {"Google Translate", "Kisi bhi bhasha ka anuvaad", "https://translate.google.com", "ic_translate"},
                    {"Maps", "Raste aur jagah dhundho", "https://maps.google.com", "ic_map"},
                    {"News", "Taaza khabrein", "https://news.google.com", "ic_news"},
                    {"Weather", "Aaj ka mausam", "https://www.google.com/search?q=weather", "ic_sun"},
                    {"Cricket score", "Live score", "https://www.google.com/search?q=cricket+score", "ic_ball"}
            };
            List<Row> rows = new ArrayList<>();
            for (final String[] x : a) {
                int res = getResources().getIdentifier(x[3], "drawable", getPackageName());
                rows.add(new Row(x[0], x[1], res, () -> {
                    closeAllPanels();
                    loadIn(cur, x[2]);
                }, null));
            }
            renderRows(body, rows, "", 0);
        });
    }

    /* ---- Theme zone ---- */

    private boolean hasWallpaper() {
        return new File(getFilesDir(), "wall.jpg").exists();
    }

    private void openThemes() {
        openPanel(tr("Theme Zone"), null, null, body -> {
            int sw = getResources().getDisplayMetrics().widthPixels;
            int cw = (sw - dp(28) - dp(16)) / 3;
            int ch = (int) (cw * 1.45f);
            List<View> cards = new ArrayList<>();
            for (int i = 0; i < THEME_COLORS.length; i++) {
                final int idx = i;
                FrameLayout c = new FrameLayout(this);
                if (i == 0) {
                    GradientDrawable g = Ui.round(this, 0xFFFFFFFF, 8);
                    g.setStroke(dp(1), pal.line);
                    c.setBackground(g);
                    ImageView li = new ImageView(this);
                    li.setImageResource(R.drawable.logo);
                    li.setScaleType(ImageView.ScaleType.FIT_CENTER);
                    li.setPadding(dp(10), dp(10), dp(10), dp(10));
                    c.addView(li, new FrameLayout.LayoutParams(-1, -1));
                } else {
                    GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, THEME_COLORS[i]);
                    g.setCornerRadius(dp(8));
                    c.setBackground(g);
                    TextView nm = Ui.text(this, THEME_NAMES[i], 12, 0xFFFFFFFF, true);
                    nm.setGravity(Gravity.CENTER);
                    c.addView(nm, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
                    nm.setPadding(0, 0, 0, dp(10));
                }
                if (store.theme() == i) addCheck(c);
                c.setOnClickListener(v -> {
                    store.setTheme(idx);
                    refreshHome();
                    refreshPanel();
                });
                cards.add(c);
            }
            if (hasWallpaper()) {
                FrameLayout c = new FrameLayout(this);
                File f = new File(getFilesDir(), "wall.jpg");
                Bitmap b = BitmapFactory.decodeFile(f.getPath());
                ImageView iv = new ImageView(this);
                if (b != null) iv.setImageBitmap(b);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setBackground(Ui.round(this, pal.surface2, 8));
                iv.setClipToOutline(true);
                c.addView(iv, new FrameLayout.LayoutParams(-1, -1));
                if (store.theme() == 5) addCheck(c);
                c.setOnClickListener(v -> {
                    store.setTheme(5);
                    refreshHome();
                    refreshPanel();
                });
                cards.add(c);
            }
            FrameLayout add = new FrameLayout(this);
            add.setBackground(Ui.round(this, pal.surface2, 8));
            add.addView(Ui.icon(this, R.drawable.ic_plus, 34, pal.muted), new FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER));
            add.setOnClickListener(v -> {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("image/*");
                try {
                    startActivityForResult(i, REQ_PHOTO);
                } catch (Exception e) {
                    toast("Gallery nahi mili");
                }
            });
            cards.add(add);

            for (int i = 0; i < cards.size(); i += 3) {
                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                for (int j = 0; j < 3; j++) {
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(cw, ch);
                    lp.rightMargin = dp(8);
                    lp.bottomMargin = dp(8);
                    if (i + j < cards.size()) row.addView(cards.get(i + j), lp);
                    else row.addView(new View(this), lp);
                }
                body.addView(row, new LinearLayout.LayoutParams(-1, -2));
            }
            TextView lp = Ui.text(this, tr("Local Photos"), 16, pal.fg, false);
            lp.setPadding(dp(4), dp(18), 0, 0);
            body.addView(lp);
        });
    }

    private void addCheck(FrameLayout c) {
        FrameLayout badge = new FrameLayout(this);
        badge.setBackground(oval(pal.accent));
        badge.addView(Ui.icon(this, R.drawable.ic_check, 16, 0xFFFFFFFF), new FrameLayout.LayoutParams(dp(16), dp(16), Gravity.CENTER));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.BOTTOM | Gravity.END);
        bp.rightMargin = dp(6);
        bp.bottomMargin = dp(6);
        c.addView(badge, bp);
    }

    private void saveWallpaper(Uri uri) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, o);
            }
            int sw = getResources().getDisplayMetrics().widthPixels;
            int sh = getResources().getDisplayMetrics().heightPixels;
            int sample = 1;
            while (o.outWidth / (sample * 2) >= sw && o.outHeight / (sample * 2) >= sh) sample *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            Bitmap b;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                b = BitmapFactory.decodeStream(in, null, o);
            }
            if (b == null) {
                toast("Photo nahi khul payi");
                return;
            }
            // Crop to the screen shape so it fills the home screen without stretching
            float target = sw / (float) sh;
            int cw = b.getWidth(), chh = b.getHeight();
            int nw = cw, nh = chh;
            if (cw / (float) chh > target) nw = Math.round(chh * target);
            else nh = Math.round(cw / target);
            Bitmap out = Bitmap.createBitmap(b, (cw - nw) / 2, (chh - nh) / 2, nw, nh);
            try (FileOutputStream fo = new FileOutputStream(new File(getFilesDir(), "wall.jpg"))) {
                out.compress(Bitmap.CompressFormat.JPEG, 88, fo);
            }
            store.setTheme(5);
            refreshHome();
            refreshPanel();
            toast("Wallpaper lag gaya");
        } catch (Exception e) {
            toast("Photo set nahi ho payi");
        }
    }

    /* ------------------------------------------------------------------ */
    /* Settings (UC style list)                                           */
    /* ------------------------------------------------------------------ */

    private View chev() {
        return Ui.icon(this, R.drawable.ic_chev_right, 22, pal.muted);
    }

    private Switch sw(boolean on, final BoolCb cb) {
        Switch s = new Switch(this);
        s.setChecked(on);
        s.setOnCheckedChangeListener((b, v) -> cb.on(v));
        return s;
    }

    private void flatRow(LinearLayout body, String title, String sub, String right, View trailing, final Runnable click) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(22), dp(18), dp(20), dp(18));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(Ui.text(this, tr(title), 17, pal.fg, false));
        if (sub != null) {
            TextView s = Ui.text(this, sub, 12.5f, pal.muted, false);
            s.setPadding(0, dp(3), 0, 0);
            col.addView(s);
        }
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        if (right != null) {
            TextView r = Ui.text(this, right, 14.5f, pal.muted, false);
            r.setPadding(dp(8), 0, dp(6), 0);
            row.addView(r);
        }
        if (trailing != null) row.addView(trailing);
        if (click != null) row.setOnClickListener(v -> click.run());
        body.addView(row, new LinearLayout.LayoutParams(-1, -2));
        View d = new View(this);
        d.setBackgroundColor(pal.line);
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(-1, dp(1));
        dl.leftMargin = dp(22);
        dl.rightMargin = dp(22);
        body.addView(d, dl);
    }

    private boolean isDefaultBrowser() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
                return rm != null && rm.isRoleHeld(RoleManager.ROLE_BROWSER);
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private void openDefaultSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));
        } catch (Exception e) {
            toast("Phone ki Settings > Apps > Default apps mein jaao");
        }
    }

    private void openSettings() {
        openPanel(tr("Settings"), null, null, this::renderSettings);
    }

    private void renderSettings(LinearLayout b) {
        b.setPadding(0, 0, 0, dp(24));
        flatRow(b, "AD Setting", null, null, chev(), this::openAdSettings);
        flatRow(b, "Customized Banner", null, null, chev(), this::openBannerSettings);
        final boolean def = isDefaultBrowser();
        flatRow(b, "Set as Default Browser", null, null, sw(def, v -> openDefaultSettings()), null);
        flatRow(b, "Browsing Settings", null, null, chev(), this::openBrowsingSettings);
        flatRow(b, "Download Settings", null, null, chev(), this::openDownloadSettings);
        flatRow(b, "Notification Settings", null, null, chev(), () -> {
            try {
                Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                i.putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName());
                startActivity(i);
            } catch (Exception e) {
                toast("Notification settings nahi khuli");
            }
        });
        flatRow(b, "Search Settings", null, null, chev(), this::openSearchSettings);
        flatRow(b, "Social Media Downloader Settings", null, null, chev(), this::openSocialSettings);
        flatRow(b, "Themes", null, null, chev(), this::openThemes);
        flatRow(b, "Data Saver", null, store.dataSaver() ? "ON" : "OFF", Ui.icon(this, R.drawable.ic_dots, 22, pal.muted), () -> {
            store.setDataSaver(!store.dataSaver());
            applyAllWebPrefs();
            toast(store.dataSaver() ? "Data Saver on: images band" : "Data Saver off");
            refreshPanel();
        });
        flatRow(b, "Language", null, "hi".equals(store.lang()) ? "हिन्दी" : "English", chev(), () ->
                new AlertDialog.Builder(this).setTitle("Language")
                        .setSingleChoiceItems(new String[]{"English", "हिन्दी"}, "hi".equals(store.lang()) ? 1 : 0, (d, which) -> {
                            store.setLang(which == 1 ? "hi" : "en");
                            d.dismiss();
                            recreate();
                        }).show());
        flatRow(b, "Clear Records", null, null, Ui.icon(this, R.drawable.ic_dots, 22, pal.muted), this::clearRecords);
        flatRow(b, "About", "S.R Browser 1.1 · " + tr("Made in India"), null, null, this::about);
    }

    private void openAdSettings() {
        openPanel(tr("AD Setting"), null, null, b -> {
            flatRow(b, "Block ads", "Jaane-pehchane ad aur tracker band", null, sw(store.adblock(), store::setAdblock), null);
            flatRow(b, "Block pop-ups", "Apne aap khulne wali windows band", null, sw(store.popupBlock(), store::setPopupBlock), null);
        });
    }

    private void openBannerSettings() {
        openPanel(tr("Customized Banner"), null, null, b -> {
            flatRow(b, "Quick buttons on home", "Downloader, Notes, History, Bookmark", null,
                    sw(store.showQuick(), v -> {
                        store.setShowQuick(v);
                        refreshHome();
                    }), null);
            flatRow(b, "Show 'Made in India' line", null, null, sw(store.showIndia(), v -> {
                store.setShowIndia(v);
                refreshHome();
            }), null);
            flatRow(b, "Home message", store.homeNote().isEmpty() ? "Logo ke neeche apna text likho" : store.homeNote(), null, chev(), () -> {
                final EditText e = new EditText(this);
                e.setText(store.homeNote());
                e.setSingleLine(true);
                LinearLayout l = new LinearLayout(this);
                l.setPadding(dp(20), dp(8), dp(20), 0);
                l.addView(e, new LinearLayout.LayoutParams(-1, -2));
                new AlertDialog.Builder(this).setTitle("Home message").setView(l)
                        .setPositiveButton("Save", (d, w) -> {
                            store.setHomeNote(e.getText().toString().trim());
                            refreshHome();
                            refreshPanel();
                        }).setNegativeButton("Cancel", null).show();
            });
        });
    }

    private void openBrowsingSettings() {
        openPanel(tr("Browsing Settings"), null, null, b -> {
            flatRow(b, "Text Size", null, SIZE_NAMES[store.textSize()], chev(), () ->
                    new AlertDialog.Builder(this).setTitle("Text size")
                            .setSingleChoiceItems(SIZE_NAMES, store.textSize(), (d, which) -> {
                                store.setTextSize(which);
                                applyAllWebPrefs();
                                d.dismiss();
                                refreshPanel();
                            }).show());
            flatRow(b, "Desktop Site", "Computer jaisa page dikhao", null, sw(store.desktop(), this::toggleDesktop), null);
            flatRow(b, "JavaScript", "Band karne par kai sites nahi chalengi", null, sw(store.js(), v -> {
                store.setJs(v);
                applyAllWebPrefs();
            }), null);
            flatRow(b, "Incognito mode", "History save nahi hoti", null, sw(store.incognito(), v -> {
                store.setIncognito(v);
                updateTabBtn();
            }), null);
        });
    }

    private void openDownloadSettings() {
        openPanel(tr("Download Settings"), null, null, b -> {
            flatRow(b, "Download folder", "Phone ka Downloads folder", null, null, null);
            flatRow(b, "Download se pehle poochho", null, null, sw(store.askDownload(), store::setAskDownload), null);
            flatRow(b, "Open Downloads", null, null, chev(), this::openDownloader);
        });
    }

    private void openSearchSettings() {
        openPanel(tr("Search Settings"), null, null, b -> {
            flatRow(b, "Search engine", null, engineName(), chev(), this::pickEngine);
            flatRow(b, "Default search type", null, new String[]{"Web", "Videos", "Images"}[mode], chev(), () ->
                    new AlertDialog.Builder(this).setTitle("Search type")
                            .setSingleChoiceItems(new String[]{"Web", "Videos", "Images"}, mode, (d, which) -> {
                                mode = which;
                                store.setSearchMode(which);
                                d.dismiss();
                                refreshHome();
                                refreshPanel();
                            }).show());
        });
    }

    private void openSocialSettings() {
        openPanel(tr("Social Media Downloader Settings"), null, null, b -> {
            flatRow(b, "Detect videos on pages", "Direct video file milne par Download video button aata hai",
                    null, sw(store.detectVideo(), store::setDetectVideo), null);
            TextView n = Ui.text(this, "Dhyan do: YouTube, Instagram aur Facebook apne videos ko protect karte hain, isliye wahan ye button nahi aata. Jahan seedhi video file ho (mp4), wahan kaam karta hai.", 13, pal.muted, false);
            n.setPadding(dp(22), dp(16), dp(22), 0);
            b.addView(n);
        });
    }

    private void clearRecords() {
        final boolean[] sel = {true, true, false, false};
        new AlertDialog.Builder(this).setTitle(tr("Clear Records"))
                .setMultiChoiceItems(new String[]{"Browsing history", "Cache", "Cookies (sab se logout)", "Saved videos aur video history"},
                        sel, (d, which, checked) -> sel[which] = checked)
                .setPositiveButton("Clear", (d, w) -> {
                    if (sel[0]) {
                        store.clear("hist");
                    }
                    if (sel[1]) for (Tab t : tabs) t.web.clearCache(true);
                    if (sel[2]) CookieManager.getInstance().removeAllCookies(null);
                    if (sel[3]) {
                        store.clear("vid");
                        store.clear("vhist");
                    }
                    toast("Saaf ho gaya");
                    refreshPanel();
                }).setNegativeButton("Cancel", null).show();
    }
}
