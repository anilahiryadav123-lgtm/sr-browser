package com.sr.browser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/** S.R Browser: a UC style browser built on Android WebView. */
public class MainActivity extends Activity {

    interface Renderer {
        void render(LinearLayout body);
    }

    interface BoolCb {
        void on(boolean v);
    }

    static final class Row {
        final String title, sub;
        final int icon;
        final Runnable click, delete;

        Row(String title, String sub, int icon, Runnable click, Runnable delete) {
            this.title = title;
            this.sub = sub;
            this.icon = icon;
            this.click = click;
            this.delete = delete;
        }
    }

    static final class Tab {
        WebView web;
        String title = "New tab";
        String url = "";
        boolean home = true;
    }

    private static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    private static final int REQ_FILE = 11;
    private static final String[][] SITES = {
            {"yt", "YouTube", "https://m.youtube.com"},
            {"fb", "Facebook", "https://m.facebook.com"},
            {"ig", "Instagram", "https://www.instagram.com"},
            {"wa", "WhatsApp", "https://web.whatsapp.com"},
            {"tg", "Telegram", "https://web.telegram.org"},
            {"wk", "Wikipedia", "https://www.wikipedia.org"},
            {"am", "Amazon", "https://www.amazon.in"},
            {"fk", "Flipkart", "https://www.flipkart.com"},
            {"gg", "Google", "https://www.google.com"}
    };
    private static final int[] SITE_BG = {
            0xFFE62117, 0xFF1877F2, 0xFFC32AA3, 0xFF25B45A, 0xFF2A9BD8,
            0xFFF3F3F1, 0xFF232F3E, 0xFF2874F0, 0xFFFFFFFF
    };
    private static final String[][] ENGINES = {
            {"google", "Google"}, {"bing", "Bing"}, {"ddg", "DuckDuckGo"}, {"yahoo", "Yahoo"}
    };
    private static final String[] SIZE_NAMES = {"Small", "Medium", "Large"};
    private static final int[] SIZE_ZOOM = {90, 100, 115};

    private Store store;
    private Pal pal;
    private String mobileUa;

    private FrameLayout screen;
    private LinearLayout root, topBar, bottomBar;
    private EditText urlEdit;
    private ImageView btnRefresh;
    private ProgressBar progress;
    private FrameLayout webHolder;
    private ScrollView homeView;
    private LinearLayout homeBox;
    private TextView tabCount;
    private View btnBack, btnFwd;

    private View scrim, sheet;
    private HorizontalScrollView pager;
    private LinearLayout pages, dots;

    private View panel;
    private LinearLayout panelBody;
    private Renderer panelRenderer;

    private final List<Tab> tabs = new ArrayList<>();
    private Tab cur;
    private int mode = 0;
    private boolean fullscreen = false;
    private boolean loading = false;

    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private ValueCallback<Uri[]> fileCb;

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    /* ------------------------------------------------------------------ */
    /* Lifecycle                                                          */
    /* ------------------------------------------------------------------ */

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        store = new Store(this);
        pal = new Pal(store.night());
        mobileUa = WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace("Version/4.0 ", "");
        CookieManager.getInstance().setAcceptCookie(true);
        getWindow().setStatusBarColor(pal.bar);
        getWindow().setNavigationBarColor(pal.bar);

        buildUi();
        buildSheet();
        setContentView(screen);
        applySystemUi();

        if (Build.VERSION.SDK_INT < 29
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }

        ArrayList<String> saveTabs = saved == null ? null : saved.getStringArrayList("tabs");
        if (saveTabs != null && !saveTabs.isEmpty()) {
            for (String s : saveTabs) {
                Tab t = newTab();
                if (!s.isEmpty()) loadIn(t, s);
            }
            int ci = saved.getInt("cur", 0);
            if (ci >= 0 && ci < tabs.size()) switchTo(tabs.get(ci));
        } else {
            handleIntent(getIntent());
        }
        if (tabs.isEmpty()) newTab();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        ArrayList<String> u = new ArrayList<>();
        for (Tab t : tabs) u.add(t.home ? "" : t.url);
        out.putStringArrayList("tabs", u);
        out.putInt("cur", tabs.indexOf(cur));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent i) {
        if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) {
            Tab t = newTab();
            loadIn(t, i.getData().toString());
        } else if (tabs.isEmpty()) {
            newTab();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (cur != null) cur.web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (cur != null) cur.web.onResume();
    }

    @Override
    protected void onDestroy() {
        for (Tab t : tabs) {
            try {
                webHolder.removeView(t.web);
                t.web.destroy();
            } catch (Exception ignored) {
            }
        }
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        } else {
            super.onActivityResult(req, res, data);
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustom();
        } else if (panel != null) {
            closePanel();
        } else if (sheet.getVisibility() == View.VISIBLE) {
            closeMenu();
        } else if (fullscreen) {
            fullscreen = false;
            applySystemUi();
        } else {
            goBack();
        }
    }

    private void applySystemUi() {
        int f = 0;
        if (fullscreen || customView != null) {
            f = View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        } else if (!store.night() && Build.VERSION.SDK_INT >= 23) {
            f = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        }
        getWindow().getDecorView().setSystemUiVisibility(f);
        boolean hide = fullscreen;
        topBar.setVisibility(hide ? View.GONE : View.VISIBLE);
        bottomBar.setVisibility(hide ? View.GONE : View.VISIBLE);
    }

    /* ------------------------------------------------------------------ */
    /* Main UI                                                            */
    /* ------------------------------------------------------------------ */

    private void buildUi() {
        screen = new FrameLayout(this);
        screen.setBackgroundColor(pal.bg);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        screen.addView(root, new FrameLayout.LayoutParams(-1, -1));

        // Top bar: app mark | Enter URL + Search | refresh
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setBackgroundColor(pal.bar);
        topBar.setPadding(dp(10), dp(8), dp(6), dp(8));

        ImageView mark = new ImageView(this);
        mark.setImageResource(R.drawable.logo);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(dp(30), dp(30));
        ml.rightMargin = dp(8);
        topBar.addView(mark, ml);

        LinearLayout urlBox = new LinearLayout(this);
        urlBox.setOrientation(LinearLayout.HORIZONTAL);
        urlBox.setGravity(Gravity.CENTER_VERTICAL);
        urlBox.setBackground(Ui.round(this, pal.surface2, 10));
        topBar.addView(urlBox, new LinearLayout.LayoutParams(0, dp(38), 1));

        urlEdit = new EditText(this);
        urlEdit.setHint("Enter URL");
        urlEdit.setHintTextColor(pal.muted);
        urlEdit.setTextColor(pal.fg);
        urlEdit.setTextSize(14);
        urlEdit.setSingleLine(true);
        urlEdit.setBackground(null);
        urlEdit.setSelectAllOnFocus(true);
        urlEdit.setPadding(dp(12), 0, dp(8), 0);
        urlEdit.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlEdit.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlEdit.setOnEditorActionListener((v, actionId, ev) -> {
            submit();
            return true;
        });
        urlBox.addView(urlEdit, new LinearLayout.LayoutParams(0, -1, 1));

        View div = new View(this);
        div.setBackgroundColor(pal.line);
        urlBox.addView(div, new LinearLayout.LayoutParams(dp(1), dp(20)));

        LinearLayout searchBtn = new LinearLayout(this);
        searchBtn.setOrientation(LinearLayout.HORIZONTAL);
        searchBtn.setGravity(Gravity.CENTER_VERTICAL);
        searchBtn.setPadding(dp(10), 0, dp(12), 0);
        ImageView si = Ui.icon(this, R.drawable.ic_search, 17, pal.gold);
        searchBtn.addView(si);
        TextView st = Ui.text(this, "Search", 13.5f, pal.fg, true);
        st.setPadding(dp(5), 0, 0, 0);
        searchBtn.addView(st);
        searchBtn.setOnClickListener(v -> submit());
        urlBox.addView(searchBtn, new LinearLayout.LayoutParams(-2, -1));

        btnRefresh = Ui.icon(this, R.drawable.ic_refresh, 24, pal.icon);
        btnRefresh.setPadding(dp(5), dp(5), dp(5), dp(5));
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(dp(38), dp(38));
        rl.leftMargin = dp(4);
        btnRefresh.setLayoutParams(rl);
        btnRefresh.setOnClickListener(v -> {
            if (cur.home) return;
            if (loading) cur.web.stopLoading();
            else cur.web.reload();
        });
        topBar.addView(btnRefresh);
        root.addView(topBar, new LinearLayout.LayoutParams(-1, -2));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(pal.gold));
        progress.setVisibility(View.INVISIBLE);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(2)));

        // Content: home screen or web pages
        FrameLayout content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        homeView = new ScrollView(this);
        homeView.setFillViewport(true);
        homeBox = new LinearLayout(this);
        homeBox.setOrientation(LinearLayout.VERTICAL);
        homeBox.setPadding(dp(14), dp(12), dp(14), dp(24));
        homeView.addView(homeBox, new ViewGroup.LayoutParams(-1, -2));
        content.addView(homeView, new FrameLayout.LayoutParams(-1, -1));

        webHolder = new FrameLayout(this);
        content.addView(webHolder, new FrameLayout.LayoutParams(-1, -1));

        // Bottom bar: back | forward | menu | tabs | home
        View line = new View(this);
        line.setBackgroundColor(pal.line);
        root.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));

        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setBackgroundColor(pal.bar);
        btnBack = barBtn(R.drawable.ic_back, this::goBack);
        btnFwd = barBtn(R.drawable.ic_forward, () -> {
            if (!cur.home && cur.web.canGoForward()) cur.web.goForward();
        });
        View btnMenu = barBtn(R.drawable.ic_menu, this::openMenu);
        FrameLayout tabsBtn = new FrameLayout(this);
        tabsBtn.addView(Ui.icon(this, R.drawable.ic_tabs, 24, pal.icon), new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
        tabCount = Ui.text(this, "1", 11, pal.icon, true);
        tabCount.setGravity(Gravity.CENTER);
        tabsBtn.addView(tabCount, new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
        tabsBtn.setOnClickListener(v -> openTabs());
        View btnHome = barBtn(R.drawable.ic_home, () -> {
            cur.home = true;
            showCurrent();
        });
        bottomBar.addView(btnBack, new LinearLayout.LayoutParams(0, dp(48), 1));
        bottomBar.addView(btnFwd, new LinearLayout.LayoutParams(0, dp(48), 1));
        bottomBar.addView(btnMenu, new LinearLayout.LayoutParams(0, dp(48), 1));
        bottomBar.addView(tabsBtn, new LinearLayout.LayoutParams(0, dp(48), 1));
        bottomBar.addView(btnHome, new LinearLayout.LayoutParams(0, dp(48), 1));
        root.addView(bottomBar, new LinearLayout.LayoutParams(-1, -2));

        refreshHome();
    }

    private View barBtn(int res, Runnable r) {
        FrameLayout f = new FrameLayout(this);
        f.addView(Ui.icon(this, res, 24, pal.icon), new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
        f.setOnClickListener(v -> r.run());
        return f;
    }

    /* ------------------------------------------------------------------ */
    /* Home screen                                                        */
    /* ------------------------------------------------------------------ */

    private Bitmap assetBitmap(String path) {
        try (InputStream in = getAssets().open(path)) {
            return BitmapFactory.decodeStream(in);
        } catch (Exception e) {
            return null;
        }
    }

    private String engineName() {
        for (String[] e : ENGINES) if (e[0].equals(store.engine())) return e[1];
        return "Google";
    }

    private void refreshHome() {
        homeBox.removeAllViews();
        homeBox.setGravity(Gravity.CENTER_HORIZONTAL);

        // Search engine logo on top (drop assets/engines/<engine>.png to use the official logo)
        Bitmap eb = assetBitmap("engines/" + store.engine() + ".png");
        if (eb != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(eb);
            iv.setAdjustViewBounds(true);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(220), dp(64));
            p.topMargin = dp(18);
            homeBox.addView(iv, p);
        } else {
            TextView t = Ui.text(this, engineName(), 40, pal.fg, true);
            t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD_ITALIC));
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(18), 0, 0);
            homeBox.addView(t);
        }
        TextView sub = Ui.text(this, "Search with " + engineName(), 12.5f, pal.muted, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(6), 0, dp(12));
        homeBox.addView(sub);

        // Web / Videos / Images
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setGravity(Gravity.CENTER);
        String[] names = {"Web", "Videos", "Images"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            TextView c = Ui.text(this, names[i], 13, i == mode ? pal.onGold : pal.muted, true);
            c.setPadding(dp(16), dp(7), dp(16), dp(7));
            c.setBackground(Ui.round(this, i == mode ? pal.gold : pal.surface, 20));
            c.setOnClickListener(v -> {
                mode = idx;
                refreshHome();
            });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
            cp.leftMargin = dp(4);
            cp.rightMargin = dp(4);
            chips.addView(c, cp);
        }
        homeBox.addView(chips);

        // Grid of sites: 4 per row
        List<View> tiles = new ArrayList<>();
        for (int i = 0; i < SITES.length; i++) {
            final String url = SITES[i][2];
            GradientDrawable bg;
            if (SITES[i][0].equals("ig")) {
                bg = new GradientDrawable(GradientDrawable.Orientation.BL_TR,
                        new int[]{0xFFFDB53C, 0xFFF0443D, 0xFFC32AA3, 0xFF6A3DE8});
                bg.setCornerRadius(dp(13));
            } else {
                bg = Ui.round(this, SITE_BG[i], 13);
            }
            int res = getResources().getIdentifier("t_" + SITES[i][0], "drawable", getPackageName());
            tiles.add(tile(SITES[i][1], bg, res, null, "icons/" + SITES[i][0] + ".png",
                    () -> loadIn(cur, url), null));
        }
        List<Store.Item> bms = store.list("bm");
        for (int i = 0; i < bms.size(); i++) {
            final Store.Item b = bms.get(i);
            final int idx = i;
            String letter = b.title.isEmpty() ? "?" : b.title.substring(0, 1).toUpperCase();
            tiles.add(tile(b.title, Ui.round(this, pal.surface2, 13), 0, letter, null,
                    () -> loadIn(cur, b.url),
                    () -> new AlertDialog.Builder(this).setTitle("Remove " + b.title + "?")
                            .setPositiveButton("Remove", (d, which) -> {
                                store.remove("bm", idx);
                                refreshHome();
                            }).setNegativeButton("Cancel", null).show()));
        }
        GradientDrawable addBg = Ui.round(this, pal.surface, 13);
        addBg.setStroke(dp(1), pal.gold);
        tiles.add(tile("Add", addBg, R.drawable.ic_plus, null, null, this::promptAddSite, null));

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setPadding(0, dp(18), 0, 0);
        for (int i = 0; i < tiles.size(); i += 4) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for (int j = 0; j < 4; j++) {
                View v = i + j < tiles.size() ? tiles.get(i + j) : new View(this);
                row.addView(v, new LinearLayout.LayoutParams(0, -2, 1));
            }
            grid.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
        homeBox.addView(grid, new LinearLayout.LayoutParams(-1, -2));
    }

    private View tile(String name, GradientDrawable bg, int iconRes, String letter, String assetPath,
                      final Runnable click, final Runnable longClick) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setPadding(dp(2), dp(9), dp(2), dp(9));

        FrameLayout box = new FrameLayout(this);
        box.setBackground(bg);
        box.setElevation(dp(2));
        Bitmap real = assetPath == null ? null : assetBitmap(assetPath);
        if (real != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(real);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setBackground(bg);
            iv.setClipToOutline(true);
            box.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        } else if (letter != null) {
            TextView l = Ui.text(this, letter, 24, pal.gold, true);
            l.setGravity(Gravity.CENTER);
            box.addView(l, new FrameLayout.LayoutParams(-1, -1));
        } else if (iconRes != 0) {
            int tint = iconRes == R.drawable.ic_plus ? pal.gold : 0;
            ImageView ic = Ui.icon(this, iconRes, 30, tint);
            box.addView(ic, new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER));
        }
        t.addView(box, new LinearLayout.LayoutParams(dp(56), dp(56)));

        TextView n = Ui.oneLine(Ui.text(this, name, 12, pal.fg, false));
        n.setGravity(Gravity.CENTER);
        n.setPadding(0, dp(6), 0, 0);
        t.addView(n, new LinearLayout.LayoutParams(-1, -2));

        t.setOnClickListener(v -> click.run());
        if (longClick != null) {
            t.setOnLongClickListener(v -> {
                longClick.run();
                return true;
            });
        }
        return t;
    }

    private void promptAddSite() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(20), dp(8), dp(20), 0);
        final EditText name = new EditText(this);
        name.setHint("Name (jaise Hotstar)");
        name.setSingleLine(true);
        final EditText addr = new EditText(this);
        addr.setHint("https://example.com");
        addr.setSingleLine(true);
        addr.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        l.addView(name);
        l.addView(addr);
        new AlertDialog.Builder(this).setTitle("Add to home").setView(l)
                .setPositiveButton("Add", (d, which) -> {
                    String nm = name.getText().toString().trim();
                    String ad = addr.getText().toString().trim();
                    if (ad.isEmpty()) {
                        toast("Address daalo");
                        return;
                    }
                    String url = toUrl(ad);
                    if (nm.isEmpty()) nm = host(url);
                    store.add("bm", nm, url, 100, false);
                    refreshHome();
                    toast(nm + " home par add ho gaya");
                }).setNegativeButton("Cancel", null).show();
    }

    private void addBookmark() {
        if (cur.home) {
            promptAddSite();
        } else {
            String t = cur.title == null || cur.title.isEmpty() ? host(cur.url) : cur.title;
            store.add("bm", t, cur.url, 100, false);
            refreshHome();
            toast("Bookmark save ho gaya");
        }
    }

    /* ------------------------------------------------------------------ */
    /* Tabs and WebView                                                   */
    /* ------------------------------------------------------------------ */

    private Tab newTab() {
        Tab t = new Tab();
        t.web = makeWeb(t);
        webHolder.addView(t.web, new FrameLayout.LayoutParams(-1, -1));
        tabs.add(t);
        switchTo(t);
        return t;
    }

    private void switchTo(Tab t) {
        if (cur != null && cur != t) cur.web.onPause();
        cur = t;
        t.web.onResume();
        showCurrent();
    }

    private void showCurrent() {
        for (Tab t : tabs) t.web.setVisibility(t == cur && !t.home ? View.VISIBLE : View.GONE);
        homeView.setVisibility(cur.home ? View.VISIBLE : View.GONE);
        webHolder.setVisibility(cur.home ? View.GONE : View.VISIBLE);
        urlEdit.setText(cur.home ? "" : cur.url);
        urlEdit.clearFocus();
        tabCount.setText(String.valueOf(tabs.size()));
        loading = false;
        progress.setVisibility(View.INVISIBLE);
        btnRefresh.setImageResource(R.drawable.ic_refresh);
        btnRefresh.setAlpha(cur.home ? 0.35f : 1f);
        updateNav();
    }

    private void updateNav() {
        btnBack.setAlpha(cur.home && tabs.size() < 2 ? 0.35f : 1f);
        btnFwd.setAlpha(!cur.home && cur.web.canGoForward() ? 1f : 0.35f);
    }

    private void loadIn(Tab t, String url) {
        t.home = false;
        t.url = url;
        if (t == cur) showCurrent();
        t.web.loadUrl(url);
    }

    private void closeTab(Tab t) {
        int idx = tabs.indexOf(t);
        tabs.remove(t);
        webHolder.removeView(t.web);
        t.web.destroy();
        if (tabs.isEmpty()) {
            newTab();
        } else if (cur == t) {
            switchTo(tabs.get(Math.max(0, idx - 1)));
        } else {
            showCurrent();
        }
    }

    private void goBack() {
        if (!cur.home) {
            if (cur.web.canGoBack()) {
                cur.web.goBack();
            } else {
                cur.home = true;
                showCurrent();
            }
        } else if (tabs.size() > 1) {
            closeTab(cur);
        } else {
            new AlertDialog.Builder(this).setTitle("Exit S.R Browser?")
                    .setPositiveButton("Exit", (d, w) -> finishAffinity())
                    .setNegativeButton("Stay", null).show();
        }
    }

    private void applyWebPrefs(WebView w) {
        WebSettings s = w.getSettings();
        s.setTextZoom(SIZE_ZOOM[Math.max(0, Math.min(2, store.textSize()))]);
        s.setUserAgentString(store.desktop() ? DESKTOP_UA : mobileUa);
    }

    private void applyAllWebPrefs() {
        for (Tab t : tabs) applyWebPrefs(t.web);
    }

    private WebView makeWeb(final Tab t) {
        final WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        applyWebPrefs(w);
        w.setBackgroundColor(Color.WHITE);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);

        w.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                startDownload(url, ua, cd, mime);
            }
        });

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String sc = r.getUrl().getScheme();
                if (sc == null) return false;
                if (sc.equals("http") || sc.equals("https") || sc.equals("about")
                        || sc.equals("data") || sc.equals("blob") || sc.equals("javascript")) {
                    return false;
                }
                if (sc.equals("file")) return true;
                try {
                    Intent in;
                    if (sc.equals("intent")) in = Intent.parseUri(r.getUrl().toString(), Intent.URI_INTENT_SCHEME);
                    else in = new Intent(Intent.ACTION_VIEW, r.getUrl());
                    in.addCategory(Intent.CATEGORY_BROWSABLE);
                    in.setComponent(null);
                    in.setSelector(null);
                    startActivity(in);
                } catch (Exception e) {
                    toast("Is link ke liye app nahi mili");
                }
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap fav) {
                t.url = url;
                if (t == cur && !urlEdit.hasFocus()) urlEdit.setText(url);
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                t.url = url;
                String title = v.getTitle();
                t.title = title == null || title.isEmpty() ? host(url) : title;
                if (t == cur && !urlEdit.hasFocus()) urlEdit.setText(url);
                if (!store.incognito() && url != null && url.startsWith("http")) {
                    store.add("hist", t.title, url, 200, true);
                }
                if (t == cur) updateNav();
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) {
                    String u = r.getUrl().toString();
                    String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                            + "<body style='font-family:sans-serif;text-align:center;padding:56px 18px;color:#555'>"
                            + "<h2>Page nahi khul paya</h2><p>" + TextUtils.htmlEncode(String.valueOf(e.getDescription()))
                            + "</p><p><a href='" + TextUtils.htmlEncode(u) + "'>Dobara try karo</a></p></body></html>";
                    v.loadDataWithBaseURL(u, html, "text/html", "utf-8", u);
                }
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                if (t != cur) return;
                loading = p < 100;
                progress.setProgress(p);
                progress.setVisibility(loading ? View.VISIBLE : View.INVISIBLE);
                btnRefresh.setImageResource(loading ? R.drawable.ic_close : R.drawable.ic_refresh);
            }

            @Override
            public void onReceivedTitle(WebView v, String title) {
                if (title != null && !title.isEmpty()) t.title = title;
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean dialog, boolean gesture, Message msg) {
                Tab nt = newTab();
                nt.home = false;
                showCurrent();
                WebView.WebViewTransport tr = (WebView.WebViewTransport) msg.obj;
                tr.setWebView(nt.web);
                msg.sendToTarget();
                return true;
            }

            @Override
            public void onShowCustomView(View v, CustomViewCallback cb) {
                if (customView != null) {
                    cb.onCustomViewHidden();
                    return;
                }
                customView = v;
                customCb = cb;
                v.setBackgroundColor(Color.BLACK);
                screen.addView(v, new FrameLayout.LayoutParams(-1, -1));
                root.setVisibility(View.GONE);
                applySystemUi();
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    toast("File chunne ke liye app nahi mili");
                    return false;
                }
                return true;
            }
        });

        w.setOnLongClickListener(v -> {
            WebView.HitTestResult hr = w.getHitTestResult();
            String extra = hr.getExtra();
            int type = hr.getType();
            if (extra == null) return false;
            if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                linkMenu(extra, false);
                return true;
            }
            if (type == WebView.HitTestResult.IMAGE_TYPE) {
                linkMenu(extra, true);
                return true;
            }
            return false;
        });
        return w;
    }

    private void hideCustom() {
        if (customView == null) return;
        screen.removeView(customView);
        customView = null;
        root.setVisibility(View.VISIBLE);
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        applySystemUi();
    }

    private void linkMenu(final String url, boolean image) {
        final String[] items = image
                ? new String[]{"Image naye tab mein kholo", "Image download karo", "Link copy karo"}
                : new String[]{"Naye tab mein kholo", "Link copy karo"};
        new AlertDialog.Builder(this).setItems(items, (d, which) -> {
            String pick = items[which];
            if (pick.startsWith("Link")) {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("link", url));
                toast("Link copy ho gaya");
            } else if (pick.startsWith("Image download")) {
                startDownload(url, mobileUa, null, null);
            } else {
                Tab nt = newTab();
                loadIn(nt, url);
            }
        }).show();
    }

    private void startDownload(String url, String ua, String cd, String mime) {
        try {
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            String name = URLUtil.guessFileName(url, cd, mime);
            if (mime != null && !mime.isEmpty()) r.setMimeType(mime);
            if (ua != null) r.addRequestHeader("User-Agent", ua);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) r.addRequestHeader("Cookie", cookie);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(r);
            toast("Download shuru: " + name);
        } catch (Exception e) {
            toast("Download nahi ho paya");
        }
    }

    /* ------------------------------------------------------------------ */
    /* Address bar                                                        */
    /* ------------------------------------------------------------------ */

    private void submit() {
        String q = urlEdit.getText().toString().trim();
        if (q.isEmpty()) return;
        InputMethodManager m = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (m != null) m.hideSoftInputFromWindow(urlEdit.getWindowToken(), 0);
        urlEdit.clearFocus();
        loadIn(cur, toUrl(q));
    }

    private String toUrl(String q) {
        if (q.startsWith("http://") || q.startsWith("https://")) return q;
        if (!q.contains(" ") && q.contains(".") && Patterns.WEB_URL.matcher(q).matches()) return "https://" + q;
        return searchUrl(q);
    }

    private String searchUrl(String q) {
        String e = store.engine();
        String en = Uri.encode(q);
        switch (e) {
            case "bing":
                if (mode == 1) return "https://www.bing.com/videos/search?q=" + en;
                if (mode == 2) return "https://www.bing.com/images/search?q=" + en;
                return "https://www.bing.com/search?q=" + en;
            case "ddg":
                if (mode == 1) return "https://duckduckgo.com/?q=" + en + "&iax=videos&ia=videos";
                if (mode == 2) return "https://duckduckgo.com/?q=" + en + "&iax=images&ia=images";
                return "https://duckduckgo.com/?q=" + en;
            case "yahoo":
                return "https://search.yahoo.com/search?p=" + en;
            default:
                if (mode == 1) return "https://www.google.com/search?q=" + en + "&tbm=vid";
                if (mode == 2) return "https://www.google.com/search?q=" + en + "&tbm=isch";
                return "https://www.google.com/search?q=" + en;
        }
    }

    private String host(String url) {
        try {
            String h = Uri.parse(url).getHost();
            return h == null ? url : h.replaceFirst("^www\\.", "");
        } catch (Exception e) {
            return url;
        }
    }

    /* ------------------------------------------------------------------ */
    /* Menu sheet (2 pages, like UC)                                      */
    /* ------------------------------------------------------------------ */

    private void buildSheet() {
        scrim = new View(this);
        scrim.setBackgroundColor(0x99000000);
        scrim.setVisibility(View.GONE);
        scrim.setOnClickListener(v -> closeMenu());
        screen.addView(scrim, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout sh = new LinearLayout(this);
        sh.setOrientation(LinearLayout.VERTICAL);
        sh.setBackground(Ui.roundTop(this, pal.sheet, 18));
        sh.setVisibility(View.GONE);
        sh.setClickable(true);

        pager = new HorizontalScrollView(this);
        pager.setHorizontalScrollBarEnabled(false);
        pager.setOverScrollMode(View.OVER_SCROLL_NEVER);
        pages = new LinearLayout(this);
        pages.setOrientation(LinearLayout.HORIZONTAL);
        pager.addView(pages, new ViewGroup.LayoutParams(-2, -2));
        pager.setOnTouchListener((v, ev) -> {
            if (ev.getAction() == MotionEvent.ACTION_UP || ev.getAction() == MotionEvent.ACTION_CANCEL) {
                pager.postDelayed(() -> {
                    int w = Math.max(1, pager.getWidth());
                    int page = Math.round(pager.getScrollX() / (float) w);
                    pager.smoothScrollTo(page * w, 0);
                }, 90);
            }
            return false;
        });
        pager.setOnScrollChangeListener((v, x, y, ox, oy) -> setDots(Math.round(x / (float) Math.max(1, pager.getWidth()))));
        sh.addView(pager, new LinearLayout.LayoutParams(-1, -2));

        dots = new LinearLayout(this);
        dots.setOrientation(LinearLayout.HORIZONTAL);
        dots.setGravity(Gravity.CENTER);
        for (int i = 0; i < 2; i++) {
            View d = new View(this);
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(Ui.dp(this, 16), Ui.dp(this, 4));
            dp.leftMargin = dp.rightMargin = Ui.dp(this, 3);
            dots.addView(d, dp);
        }
        sh.addView(dots, new LinearLayout.LayoutParams(-1, dp(18)));

        View line = new View(this);
        line.setBackgroundColor(pal.line);
        sh.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        View b1 = barBtn(R.drawable.ic_starplus, () -> {
            closeMenu();
            addBookmark();
        });
        View b2 = barBtn(R.drawable.ic_chevron, this::closeMenu);
        ((ImageView) ((FrameLayout) b2).getChildAt(0)).setColorFilter(pal.gold, android.graphics.PorterDuff.Mode.SRC_IN);
        View b3 = barBtn(R.drawable.ic_share, () -> {
            closeMenu();
            share();
        });
        bar.addView(b1, new LinearLayout.LayoutParams(0, dp(48), 1));
        bar.addView(b2, new LinearLayout.LayoutParams(0, dp(48), 1));
        bar.addView(b3, new LinearLayout.LayoutParams(0, dp(48), 1));
        sh.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        sheet = sh;
        screen.addView(sh, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
    }

    private void setDots(int active) {
        for (int i = 0; i < dots.getChildCount(); i++) {
            dots.getChildAt(i).setBackground(Ui.round(this, i == active ? pal.gold : pal.line, 2));
        }
    }

    private void openMenu() {
        if (sheet.getVisibility() == View.VISIBLE) {
            closeMenu();
            return;
        }
        pages.removeAllViews();
        int w = getResources().getDisplayMetrics().widthPixels;
        pages.addView(menuPage(1), new LinearLayout.LayoutParams(w, -2));
        pages.addView(menuPage(2), new LinearLayout.LayoutParams(w, -2));
        scrim.setVisibility(View.VISIBLE);
        sheet.setVisibility(View.VISIBLE);
        pager.scrollTo(0, 0);
        setDots(0);
    }

    private void closeMenu() {
        scrim.setVisibility(View.GONE);
        sheet.setVisibility(View.GONE);
    }

    private View menuPage(int n) {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(8), dp(22), dp(8), dp(2));
        View[] it;
        if (n == 1) {
            it = new View[]{
                    mi(R.drawable.ic_star, "Bookmarks", false, false, this::openBookmarks),
                    mi(R.drawable.ic_clock, "History", false, false, this::openHistory),
                    mi(R.drawable.ic_refresh, "Refresh", false, cur.home, () -> cur.web.reload()),
                    mi(R.drawable.ic_full, "Full Screen", fullscreen, false, () -> {
                        fullscreen = !fullscreen;
                        applySystemUi();
                    }),
                    mi(R.drawable.ic_addons, "Add-ons", false, false, this::openAddons),
                    mi(R.drawable.ic_video, "My Videos", false, false, this::openVideos),
                    mi(R.drawable.ic_download, "Downloads", false, false, this::openDownloads),
                    mi(R.drawable.ic_power, "Exit", false, false, () ->
                            new AlertDialog.Builder(this).setTitle("Exit S.R Browser?")
                                    .setPositiveButton("Exit", (d, w) -> finishAffinity())
                                    .setNegativeButton("Stay", null).show())
            };
        } else {
            it = new View[]{
                    mi(R.drawable.ic_gear, "Settings", false, false, this::openSettings),
                    mi(R.drawable.ic_moon, "Night Mode", store.night(), false, () -> {
                        store.setNight(!store.night());
                        recreate();
                    }),
                    mi(R.drawable.ic_mask, "Incognito", store.incognito(), false, () -> {
                        store.setIncognito(!store.incognito());
                        toast(store.incognito() ? "Incognito on" : "Incognito off");
                    }),
                    mi(R.drawable.ic_aa, "Text Size", false, false, this::cycleSize),
                    mi(R.drawable.ic_trash, "Clear Records", false, false, () -> {
                        store.clear("hist");
                        toast("History saaf ho gayi");
                    }),
                    mi(R.drawable.ic_desktop, "Desktop Site", store.desktop(), false, this::toggleDesktop),
                    mi(R.drawable.ic_brush, "Clear Cache", false, false, () -> {
                        for (Tab t : tabs) t.web.clearCache(true);
                        toast("Cache saaf ho gaya");
                    }),
                    mi(R.drawable.ic_info, "About", false, false, this::about)
            };
        }
        for (int r = 0; r < 2; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, 0, 0, dp(20));
            for (int c = 0; c < 4; c++) row.addView(it[r * 4 + c], new LinearLayout.LayoutParams(0, -2, 1));
            page.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
        return page;
    }

    private View mi(int res, String label, boolean on, boolean off, final Runnable action) {
        LinearLayout v = new LinearLayout(this);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setGravity(Gravity.CENTER_HORIZONTAL);
        int color = on ? pal.gold : pal.icon;
        v.addView(Ui.icon(this, res, 28, color));
        TextView t = Ui.oneLine(Ui.text(this, label, 12, color, false));
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(8), 0, 0);
        v.addView(t, new LinearLayout.LayoutParams(-1, -2));
        v.setAlpha(off ? 0.35f : 1f);
        if (!off) {
            v.setOnClickListener(x -> {
                closeMenu();
                action.run();
            });
        }
        return v;
    }

    private void share() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, cur.home ? "S.R Browser" : cur.url);
        startActivity(Intent.createChooser(i, "Share"));
    }

    private void cycleSize() {
        int n = (store.textSize() + 1) % 3;
        store.setTextSize(n);
        applyAllWebPrefs();
        toast("Text size: " + SIZE_NAMES[n]);
    }

    private void toggleDesktop() {
        store.setDesktop(!store.desktop());
        applyAllWebPrefs();
        if (!cur.home) cur.web.reload();
        toast(store.desktop() ? "Desktop site on" : "Desktop site off");
    }

    private void about() {
        new AlertDialog.Builder(this).setTitle("S.R Browser")
                .setMessage("Version 1.0\nSearch, videos, social aur shopping ek hi jagah.")
                .setPositiveButton("OK", null).show();
    }

    /* ------------------------------------------------------------------ */
    /* Full-screen panels                                                 */
    /* ------------------------------------------------------------------ */

    private void openPanel(String title, String actionLabel, final Runnable action, Renderer r) {
        closePanel();
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackgroundColor(pal.bg);
        p.setClickable(true);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setBackgroundColor(pal.bar);
        head.setPadding(dp(6), dp(6), dp(14), dp(6));
        ImageView back = Ui.icon(this, R.drawable.ic_back, 26, pal.fg);
        back.setPadding(dp(8), dp(8), dp(8), dp(8));
        back.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(44)));
        back.setOnClickListener(v -> closePanel());
        head.addView(back);
        TextView tt = Ui.text(this, title, 19, pal.fg, true);
        tt.setTypeface(Typeface.create("sans-serif", Typeface.BOLD_ITALIC));
        head.addView(tt, new LinearLayout.LayoutParams(0, -2, 1));
        if (actionLabel != null) {
            TextView a = Ui.text(this, actionLabel, 14, pal.gold, true);
            a.setPadding(dp(8), dp(8), 0, dp(8));
            a.setOnClickListener(v -> action.run());
            head.addView(a);
        }
        p.addView(head, new LinearLayout.LayoutParams(-1, -2));

        ScrollView sv = new ScrollView(this);
        panelBody = new LinearLayout(this);
        panelBody.setOrientation(LinearLayout.VERTICAL);
        panelBody.setPadding(dp(14), dp(14), dp(14), dp(24));
        sv.addView(panelBody, new ViewGroup.LayoutParams(-1, -2));
        p.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        panel = p;
        panelRenderer = r;
        screen.addView(p, new FrameLayout.LayoutParams(-1, -1));
        refreshPanel();
    }

    private void refreshPanel() {
        if (panel == null || panelRenderer == null) return;
        panelBody.removeAllViews();
        panelRenderer.render(panelBody);
    }

    private void closePanel() {
        if (panel != null) {
            screen.removeView(panel);
            panel = null;
            panelRenderer = null;
        }
    }

    private LinearLayout card(LinearLayout body) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(Ui.round(this, pal.surface, 16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(14);
        body.addView(c, lp);
        return c;
    }

    private void renderRows(LinearLayout body, List<Row> rows, String empty) {
        if (rows.isEmpty()) {
            TextView e = Ui.text(this, empty, 14, pal.muted, false);
            e.setGravity(Gravity.CENTER);
            e.setPadding(dp(16), dp(40), dp(16), dp(40));
            body.addView(e);
            return;
        }
        LinearLayout c = card(body);
        for (int i = 0; i < rows.size(); i++) {
            final Row r = rows.get(i);
            if (i > 0) {
                View d = new View(this);
                d.setBackgroundColor(pal.line);
                c.addView(d, new LinearLayout.LayoutParams(-1, dp(1)));
            }
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(14), dp(11), dp(8), dp(11));

            FrameLayout ib = new FrameLayout(this);
            ib.setBackground(Ui.round(this, pal.surface2, 11));
            if (r.icon != 0) {
                ib.addView(Ui.icon(this, r.icon, 20, pal.gold), new FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER));
            } else {
                String l = r.title.isEmpty() ? "?" : r.title.substring(0, 1).toUpperCase();
                TextView lt = Ui.text(this, l, 16, pal.gold, true);
                lt.setGravity(Gravity.CENTER);
                ib.addView(lt, new FrameLayout.LayoutParams(-1, -1));
            }
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(38), dp(38));
            ip.rightMargin = dp(12);
            row.addView(ib, ip);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.addView(Ui.oneLine(Ui.text(this, r.title, 15, pal.fg, true)));
            if (r.sub != null && !r.sub.isEmpty()) col.addView(Ui.oneLine(Ui.text(this, r.sub, 12, pal.muted, false)));
            row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));

            if (r.delete != null) {
                ImageView x = Ui.icon(this, R.drawable.ic_close, 20, pal.muted);
                x.setPadding(dp(10), dp(10), dp(10), dp(10));
                x.setLayoutParams(new LinearLayout.LayoutParams(dp(40), dp(40)));
                x.setOnClickListener(v -> r.delete.run());
                row.addView(x);
            }
            row.setOnClickListener(v -> {
                if (r.click != null) r.click.run();
            });
            c.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    private void openBookmarks() {
        openPanel("Bookmarks", "+ Add", this::promptAddSite, body -> {
            List<Row> rows = new ArrayList<>();
            List<Store.Item> l = store.list("bm");
            for (int i = 0; i < l.size(); i++) {
                final Store.Item it = l.get(i);
                final int idx = i;
                rows.add(new Row(it.title, host(it.url), 0, () -> {
                    closePanel();
                    loadIn(cur, it.url);
                }, () -> {
                    store.remove("bm", idx);
                    refreshHome();
                    refreshPanel();
                }));
            }
            renderRows(body, rows, "Koi bookmark nahi. Menu ke star+ se page save karo.");
        });
    }

    private void openHistory() {
        openPanel("History", "Clear", () -> {
            store.clear("hist");
            refreshPanel();
        }, body -> {
            List<Row> rows = new ArrayList<>();
            List<Store.Item> l = store.list("hist");
            for (int i = 0; i < l.size(); i++) {
                final Store.Item it = l.get(i);
                final int idx = i;
                rows.add(new Row(it.title, host(it.url), 0, () -> {
                    closePanel();
                    loadIn(cur, it.url);
                }, () -> {
                    store.remove("hist", idx);
                    refreshPanel();
                }));
            }
            renderRows(body, rows, "History khaali hai.");
        });
    }

    private void openVideos() {
        openPanel("My Videos", "+ This page", () -> {
            if (cur.home) {
                toast("Pehle koi video page kholo");
                return;
            }
            String t = cur.title == null || cur.title.isEmpty() ? host(cur.url) : cur.title;
            store.add("vid", t, cur.url, 200, true);
            refreshPanel();
            toast("Video save ho gaya");
        }, body -> {
            List<Row> rows = new ArrayList<>();
            List<Store.Item> l = store.list("vid");
            for (int i = 0; i < l.size(); i++) {
                final Store.Item it = l.get(i);
                final int idx = i;
                rows.add(new Row(it.title, host(it.url), R.drawable.ic_video, () -> {
                    closePanel();
                    loadIn(cur, it.url);
                }, () -> {
                    store.remove("vid", idx);
                    refreshPanel();
                }));
            }
            renderRows(body, rows, "Koi video page kholo, phir yahan \"+ This page\" dabao.");
        });
    }

    private void openDownloads() {
        try {
            startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));
        } catch (Exception e) {
            toast("Downloads app nahi mili");
        }
    }

    private void openAddons() {
        openPanel("Add-ons", null, null, body -> {
            String[][] a = {
                    {"Google Translate", "Kisi bhi bhasha ka anuvaad", "https://translate.google.com", "ic_translate"},
                    {"Maps", "Raste aur jagah dhundho", "https://maps.google.com", "ic_map"},
                    {"News", "Taaza khabrein", "https://news.google.com", "ic_news"},
                    {"Weather", "Aaj ka mausam", "https://www.google.com/search?q=weather", "ic_sun"},
                    {"Cricket score", "Live score", "https://www.google.com/search?q=cricket+score", "ic_ball"}
            };
            List<Row> rows = new ArrayList<>();
            for (final String[] x : a) {
                int res = getResources().getIdentifier(x[3], "drawable", getPackageName());
                rows.add(new Row(x[0], x[1], res, () -> {
                    closePanel();
                    loadIn(cur, x[2]);
                }, null));
            }
            renderRows(body, rows, "");
        });
    }

    private void openTabs() {
        openPanel("Tabs", "+ New tab", () -> {
            closePanel();
            newTab();
        }, body -> {
            List<Row> rows = new ArrayList<>();
            for (final Tab t : new ArrayList<>(tabs)) {
                String title = t.home ? "Home" : (t.title == null || t.title.isEmpty() ? host(t.url) : t.title);
                rows.add(new Row(title, t.home ? "S.R Browser" : host(t.url), R.drawable.ic_tabs, () -> {
                    closePanel();
                    switchTo(t);
                }, () -> {
                    closeTab(t);
                    refreshPanel();
                }));
            }
            renderRows(body, rows, "");
        });
    }

    /* ------------------------------------------------------------------ */
    /* Settings                                                           */
    /* ------------------------------------------------------------------ */

    private void openSettings() {
        openPanel("Settings", null, null, this::renderSettings);
    }

    private LinearLayout group(LinearLayout body, String name) {
        TextView h = Ui.text(this, name.toUpperCase(), 11.5f, pal.muted, true);
        h.setLetterSpacing(0.1f);
        h.setPadding(dp(4), dp(4), 0, dp(8));
        body.addView(h);
        return card(body);
    }

    private Switch sw(boolean on, final BoolCb cb) {
        Switch s = new Switch(this);
        s.setChecked(on);
        s.setOnCheckedChangeListener((b, v) -> cb.on(v));
        return s;
    }

    private void setRow(LinearLayout c, String title, String sub, View trailing, final Runnable click) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(13), dp(14), dp(13));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(Ui.text(this, title, 15, pal.fg, true));
        if (sub != null) col.addView(Ui.text(this, sub, 12, pal.muted, false));
        row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
        if (trailing != null) row.addView(trailing);
        if (click != null) row.setOnClickListener(v -> click.run());
        if (c.getChildCount() > 0) {
            View d = new View(this);
            d.setBackgroundColor(pal.line);
            c.addView(d, new LinearLayout.LayoutParams(-1, dp(1)));
        }
        c.addView(row, new LinearLayout.LayoutParams(-1, -2));
    }

    private void renderSettings(LinearLayout body) {
        LinearLayout c = group(body, "Search");
        setRow(c, "Search engine", engineName(), null, this::pickEngine);

        c = group(body, "Display");
        setRow(c, "Night mode", "Black and gold look", sw(store.night(), v -> {
            store.setNight(v);
            recreate();
        }), null);
        setRow(c, "Text size", SIZE_NAMES[store.textSize()], null, () -> {
            new AlertDialog.Builder(this).setTitle("Text size")
                    .setSingleChoiceItems(SIZE_NAMES, store.textSize(), (d, which) -> {
                        store.setTextSize(which);
                        applyAllWebPrefs();
                        d.dismiss();
                        refreshPanel();
                    }).show();
        });
        setRow(c, "Desktop site", "Computer jaisa page dikhao", sw(store.desktop(), v -> {
            store.setDesktop(v);
            applyAllWebPrefs();
            if (!cur.home) cur.web.reload();
        }), null);

        c = group(body, "Privacy");
        setRow(c, "Incognito mode", "History save nahi hoti", sw(store.incognito(), v -> store.setIncognito(v)), null);
        setRow(c, "Clear history", null, null, () -> {
            store.clear("hist");
            toast("History saaf ho gayi");
        });
        setRow(c, "Clear cache", null, null, () -> {
            for (Tab t : tabs) t.web.clearCache(true);
            toast("Cache saaf ho gaya");
        });
        setRow(c, "Clear cookies", "Sab sites se logout ho jaoge", null, () -> {
            CookieManager.getInstance().removeAllCookies(null);
            toast("Cookies saaf ho gayi");
        });

        c = group(body, "Browser");
        setRow(c, "Set as default browser", "Links S.R Browser mein khulenge", null, () -> {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));
            } catch (Exception e) {
                toast("Phone ki Settings > Apps > Default apps mein jaao");
            }
        });
        setRow(c, "About", "S.R Browser 1.0", null, this::about);
    }

    private void pickEngine() {
        String[] names = new String[ENGINES.length];
        int sel = 0;
        for (int i = 0; i < ENGINES.length; i++) {
            names[i] = ENGINES[i][1];
            if (ENGINES[i][0].equals(store.engine())) sel = i;
        }
        new AlertDialog.Builder(this).setTitle("Search engine")
                .setSingleChoiceItems(names, sel, (d, which) -> {
                    store.setEngine(ENGINES[which][0]);
                    d.dismiss();
                    refreshHome();
                    refreshPanel();
                }).show();
    }
}
