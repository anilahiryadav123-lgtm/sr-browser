package com.sr.browser;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * In-app video downloader for streaming videos (HLS / m3u8), like UC's fast download.
 * Downloads every segment, decrypts AES-128 if needed, joins them and converts to MP4.
 * Tasks get negative ids so they can live in the same list as Android DownloadManager ids.
 */
final class Grabber {

    static final int PENDING = 0, RUNNING = 1, DONE = 2, FAILED = 3, CANCELLED = 4;

    static final class Task {
        long id;
        String name, src, ua, cookie, referer, audio;
        volatile int status = PENDING;
        volatile long got, total, speed;
        volatile int segDone, segTotal;
        volatile boolean cancel;
        String uri = "", error = "";
        private long lastGot, lastTime;
    }

    /** One variant from a master playlist. */
    static final class Variant {
        String url, audio;
        int height;
        long bandwidth;
    }

    interface Listener {
        void changed(Task t);
    }

    static final Map<Long, Task> tasks = new ConcurrentHashMap<>();
    static Listener listener;
    private static ExecutorService pool;
    private static int poolSize;
    private static final Handler main = new Handler(Looper.getMainLooper());
    private static final String CH = "sr_downloads";

    private Grabber() {
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("srdl", Context.MODE_PRIVATE);
    }

    static synchronized ExecutorService pool(int size) {
        size = Math.max(1, Math.min(3, size));
        if (pool == null || poolSize != size) {
            if (pool != null) pool.shutdown();
            pool = Executors.newFixedThreadPool(size);
            poolSize = size;
        }
        return pool;
    }

    static boolean active() {
        for (Task t : tasks.values()) if (t.status == PENDING || t.status == RUNNING) return true;
        return false;
    }

    /** State of a task from memory, or the saved result after an app restart. */
    static Task state(Context c, long id) {
        Task t = tasks.get(id);
        if (t != null) return t;
        String js = prefs(c).getString(String.valueOf(id), null);
        t = new Task();
        t.id = id;
        if (js == null) {
            t.status = FAILED;
            t.error = "Interrupted";
            return t;
        }
        try {
            JSONObject o = new JSONObject(js);
            t.status = o.optInt("s", FAILED);
            t.uri = o.optString("u");
            t.total = o.optLong("z");
            t.got = t.total;
            t.error = o.optString("e");
            if (t.status == RUNNING || t.status == PENDING) {
                t.status = FAILED;
                t.error = "Interrupted";
            }
        } catch (Exception e) {
            t.status = FAILED;
        }
        return t;
    }

    static void forget(Context c, long id) {
        Task t = tasks.remove(id);
        if (t != null) t.cancel = true;
        prefs(c).edit().remove(String.valueOf(id)).apply();
    }

    static void cancel(long id) {
        Task t = tasks.get(id);
        if (t != null) t.cancel = true;
    }

    private static void save(Context c, Task t) {
        try {
            JSONObject o = new JSONObject();
            o.put("s", t.status);
            o.put("u", t.uri);
            o.put("z", t.total);
            o.put("e", t.error);
            prefs(c).edit().putString(String.valueOf(t.id), o.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    static long newId(Context c) {
        SharedPreferences p = prefs(c);
        long id = p.getLong("seq", -1000) - 1;
        p.edit().putLong("seq", id).apply();
        return id;
    }

    static Task start(final Context app, String src, String audio, String name, String ua, String cookie,
                      String referer, int threads, final boolean notify) {
        final Task t = new Task();
        t.id = newId(app);
        t.src = src;
        t.audio = audio;
        t.name = name;
        t.ua = ua;
        t.cookie = cookie;
        t.referer = referer;
        tasks.put(t.id, t);
        save(app, t);
        try {
            Intent si = new Intent(app, DlService.class);
            if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(si);
            else app.startService(si);
        } catch (Exception ignored) {
        }
        pool(threads).execute(() -> run(app, t, notify));
        return t;
    }

    /* ------------------------------------------------------------------ */
    /* Network                                                            */
    /* ------------------------------------------------------------------ */

    private static HttpURLConnection open(String url, String ua, String cookie, String referer) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(25000);
        c.setInstanceFollowRedirects(true);
        if (ua != null) c.setRequestProperty("User-Agent", ua);
        if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);
        if (referer != null && !referer.isEmpty()) {
            c.setRequestProperty("Referer", referer);
            try {
                Uri r = Uri.parse(referer);
                c.setRequestProperty("Origin", r.getScheme() + "://" + r.getHost());
            } catch (Exception ignored) {
            }
        }
        return c;
    }

    static byte[] fetch(String url, String ua, String cookie, String referer, int maxBytes) throws Exception {
        HttpURLConnection c = open(url, ua, cookie, referer);
        try {
            int code = c.getResponseCode();
            if (code >= 400) throw new Exception("HTTP " + code);
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] b = new byte[32768];
                int n;
                while ((n = in.read(b)) > 0) {
                    bo.write(b, 0, n);
                    if (maxBytes > 0 && bo.size() > maxBytes) break;
                }
                return bo.toByteArray();
            }
        } finally {
            c.disconnect();
        }
    }

    static String fetchText(String url, String ua, String cookie, String referer) throws Exception {
        return new String(fetch(url, ua, cookie, referer, 4 * 1024 * 1024), "UTF-8");
    }

    /** Size of a direct file via HEAD (or -1). */
    static long size(String url, String ua, String cookie, String referer) {
        HttpURLConnection c = null;
        try {
            c = open(url, ua, cookie, referer);
            c.setRequestMethod("HEAD");
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            if (c.getResponseCode() >= 400) return -1;
            return c.getContentLength() > 0 ? c.getContentLength() : parseLong(c.getHeaderField("Content-Length"));
        } catch (Exception e) {
            return -1;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static long parseLong(String s) {
        try {
            return Long.parseLong(s.trim());
        } catch (Exception e) {
            return -1;
        }
    }

    static String resolve(String base, String rel) {
        try {
            return new URL(new URL(base), rel.trim()).toString();
        } catch (Exception e) {
            return rel;
        }
    }

    static String attr(String line, String key) {
        int i = line.indexOf(key + "=");
        if (i < 0) return null;
        i += key.length() + 1;
        if (i < line.length() && line.charAt(i) == '"') {
            int e = line.indexOf('"', i + 1);
            return e < 0 ? line.substring(i + 1) : line.substring(i + 1, e);
        }
        int e = line.indexOf(',', i);
        return e < 0 ? line.substring(i) : line.substring(i, e);
    }

    static boolean isMaster(String text) {
        return text.contains("#EXT-X-STREAM-INF");
    }

    /** Lists the qualities in a master playlist, highest first. */
    static List<Variant> variants(String masterUrl, String text) {
        Map<String, String> audioGroups = new HashMap<>();
        String[] lines = text.split("\n");
        for (String l : lines) {
            l = l.trim();
            if (l.startsWith("#EXT-X-MEDIA") && "AUDIO".equals(attr(l, "TYPE"))) {
                String g = attr(l, "GROUP-ID"), u = attr(l, "URI");
                if (g != null && u != null && (!audioGroups.containsKey(g) || "YES".equals(attr(l, "DEFAULT"))))
                    audioGroups.put(g, resolve(masterUrl, u));
            }
        }
        List<Variant> out = new ArrayList<>();
        for (int i = 0; i < lines.length; i++) {
            String l = lines[i].trim();
            if (!l.startsWith("#EXT-X-STREAM-INF")) continue;
            String next = null;
            for (int j = i + 1; j < lines.length; j++) {
                String n = lines[j].trim();
                if (n.isEmpty() || n.startsWith("#")) continue;
                next = n;
                break;
            }
            if (next == null) continue;
            Variant v = new Variant();
            v.url = resolve(masterUrl, next);
            String res = attr(l, "RESOLUTION");
            if (res != null && res.contains("x")) {
                try {
                    v.height = Integer.parseInt(res.substring(res.indexOf('x') + 1).trim());
                } catch (Exception ignored) {
                }
            }
            String bw = attr(l, "BANDWIDTH");
            if (bw != null) v.bandwidth = parseLong(bw);
            String ag = attr(l, "AUDIO");
            if (ag != null) v.audio = audioGroups.get(ag);
            if (attr(l, "CODECS") != null && attr(l, "CODECS").startsWith("mp4a") && v.height == 0 && res == null) continue;
            out.add(v);
        }
        java.util.Collections.sort(out, (a, b) -> a.height != b.height ? b.height - a.height : Long.compare(b.bandwidth, a.bandwidth));
        return out;
    }

    /* ------------------------------------------------------------------ */
    /* Download                                                           */
    /* ------------------------------------------------------------------ */

    private static final class Seg {
        String url, keyUrl, iv;
        long seq;
        boolean aes;
    }

    private static final class Playlist {
        List<Seg> segs = new ArrayList<>();
        String init;
        boolean sampleAes;
    }

    private static Playlist parse(String url, String text) {
        Playlist p = new Playlist();
        long seq = 0;
        boolean aes = false;
        String keyUrl = null, iv = null;
        for (String l : text.split("\n")) {
            l = l.trim();
            if (l.isEmpty()) continue;
            if (l.startsWith("#EXT-X-MEDIA-SEQUENCE:")) {
                seq = parseLong(l.substring(22));
                if (seq < 0) seq = 0;
            } else if (l.startsWith("#EXT-X-KEY")) {
                String m = attr(l, "METHOD");
                aes = "AES-128".equals(m);
                if ("SAMPLE-AES".equals(m) || (m != null && m.startsWith("SAMPLE-AES"))) p.sampleAes = true;
                String u = attr(l, "URI");
                keyUrl = u == null ? null : resolve(url, u);
                iv = attr(l, "IV");
            } else if (l.startsWith("#EXT-X-MAP")) {
                String u = attr(l, "URI");
                if (u != null) p.init = resolve(url, u);
            } else if (!l.startsWith("#")) {
                Seg s = new Seg();
                s.url = resolve(url, l);
                s.seq = seq++;
                s.aes = aes;
                s.keyUrl = keyUrl;
                s.iv = iv;
                p.segs.add(s);
            }
        }
        return p;
    }

    private static Playlist load(String url, Task t) throws Exception {
        String text = fetchText(url, t.ua, t.cookie, t.referer);
        if (isMaster(text)) {
            List<Variant> v = variants(url, text);
            if (v.isEmpty()) throw new Exception("No video found");
            if (t.audio == null) t.audio = v.get(0).audio;
            url = v.get(0).url;
            text = fetchText(url, t.ua, t.cookie, t.referer);
        }
        if (!text.contains("#EXTM3U") && !text.contains("#EXTINF")) throw new Exception("Not a video playlist");
        Playlist p = parse(url, text);
        if (p.sampleAes) throw new Exception("This video is DRM protected");
        if (p.segs.isEmpty()) throw new Exception("Empty playlist");
        return p;
    }

    private static byte[] ivFor(Seg s) {
        byte[] iv = new byte[16];
        if (s.iv != null) {
            String h = s.iv.startsWith("0x") || s.iv.startsWith("0X") ? s.iv.substring(2) : s.iv;
            while (h.length() < 32) h = "0" + h;
            for (int i = 0; i < 16; i++) iv[i] = (byte) Integer.parseInt(h.substring(i * 2, i * 2 + 2), 16);
        } else {
            long q = s.seq;
            for (int i = 15; i >= 8; i--) {
                iv[i] = (byte) (q & 0xFF);
                q >>= 8;
            }
        }
        return iv;
    }

    /** Downloads all segments of a playlist into one file. */
    private static void grab(Context app, Playlist p, File out, Task t, int part, int parts, boolean notify) throws Exception {
        Map<String, byte[]> keys = new HashMap<>();
        try (OutputStream os = new FileOutputStream(out)) {
            if (p.init != null) os.write(withRetry(p.init, t));
            int n = p.segs.size();
            for (int i = 0; i < n; i++) {
                if (t.cancel) throw new InterruptedException();
                Seg s = p.segs.get(i);
                byte[] data = withRetry(s.url, t);
                if (s.aes && s.keyUrl != null) {
                    byte[] key = keys.get(s.keyUrl);
                    if (key == null) {
                        key = withRetry(s.keyUrl, t);
                        keys.put(s.keyUrl, key);
                    }
                    Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
                    c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(ivFor(s)));
                    data = c.doFinal(data);
                }
                os.write(data);
                t.got += data.length;
                t.segDone = part * n + i + 1;
                t.segTotal = n * parts;
                // estimate final size from the average segment so far
                t.total = t.got * t.segTotal / Math.max(1, t.segDone);
                tick(app, t, notify);
            }
        }
    }

    private static byte[] withRetry(String url, Task t) throws Exception {
        Exception last = null;
        for (int a = 0; a < 4; a++) {
            if (t.cancel) throw new InterruptedException();
            try {
                return fetch(url, t.ua, t.cookie, t.referer, 0);
            } catch (Exception e) {
                last = e;
                Thread.sleep(700L * (a + 1));
            }
        }
        throw last == null ? new Exception("Network error") : last;
    }

    private static void run(Context app, Task t, boolean notify) {
        File dir = new File(app.getCacheDir(), "grab_" + (-t.id));
        try {
            t.status = RUNNING;
            post(t);
            dir.mkdirs();
            Playlist video = load(t.src, t);
            Playlist audio = null;
            if (t.audio != null && !t.audio.equals(t.src)) {
                try {
                    audio = load(t.audio, t);
                } catch (Exception ignored) {
                }
            }
            int parts = audio == null ? 1 : 2;
            boolean fmp4 = video.init != null;
            File vf = new File(dir, fmp4 ? "v.mp4" : "v.ts");
            grab(app, video, vf, t, 0, parts, notify);
            File af = null;
            if (audio != null) {
                af = new File(dir, audio.init != null ? "a.mp4" : "a.ts");
                grab(app, audio, af, t, 1, parts, notify);
            }
            if (t.cancel) throw new InterruptedException();

            // Convert to MP4
            File mp4 = new File(dir, "out.mp4");
            List<File> ins = new ArrayList<>();
            ins.add(vf);
            if (af != null) ins.add(af);
            File result;
            String ext;
            if (remux(ins, mp4)) {
                result = mp4;
                ext = "mp4";
            } else {
                result = vf;
                ext = fmp4 ? "mp4" : "ts";
            }
            String base = t.name;
            int dot = base.lastIndexOf('.');
            if (dot > 0) base = base.substring(0, dot);
            t.name = base + "." + ext;
            t.uri = publish(app, result, t.name, ext.equals("ts") ? "video/mp2t" : "video/mp4");
            t.total = result.length();
            t.got = t.total;
            t.status = DONE;
        } catch (InterruptedException e) {
            t.status = CANCELLED;
            t.error = "Cancelled";
        } catch (Throwable e) {
            t.status = t.cancel ? CANCELLED : FAILED;
            String m = e.getMessage();
            t.error = m == null || m.isEmpty() ? "Download failed" : m;
        } finally {
            deleteDir(dir);
        }
        save(app, t);
        finishNote(app, t, notify);
        post(t);
        if (!active()) {
            try {
                app.stopService(new Intent(app, DlService.class));
            } catch (Exception ignored) {
            }
        }
    }

    private static void deleteDir(File d) {
        File[] fs = d.listFiles();
        if (fs != null) for (File f : fs) f.delete();
        d.delete();
    }

    /** Joins video and audio tracks into one MP4 using Android's own media tools. */
    static boolean remux(List<File> ins, File out) {
        MediaMuxer mux = null;
        List<MediaExtractor> exs = new ArrayList<>();
        try {
            List<int[]> map = new ArrayList<>(); // {extractorIndex, muxTrack}
            boolean haveV = false, haveA = false;
            mux = new MediaMuxer(out.getPath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int maxSize = 2 * 1024 * 1024;
            for (File f : ins) {
                MediaExtractor probe = new MediaExtractor();
                probe.setDataSource(f.getPath());
                int n = probe.getTrackCount();
                for (int i = 0; i < n; i++) {
                    MediaFormat fm = probe.getTrackFormat(i);
                    String mime = fm.getString(MediaFormat.KEY_MIME);
                    if (mime == null) continue;
                    boolean v = mime.startsWith("video/"), a = mime.startsWith("audio/");
                    if ((v && haveV) || (a && haveA) || (!v && !a)) continue;
                    MediaExtractor ex = new MediaExtractor();
                    ex.setDataSource(f.getPath());
                    ex.selectTrack(i);
                    int mt = mux.addTrack(fm);
                    if (fm.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE))
                        maxSize = Math.max(maxSize, fm.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE));
                    exs.add(ex);
                    map.add(new int[]{exs.size() - 1, mt});
                    if (v) haveV = true;
                    else haveA = true;
                }
                probe.release();
            }
            if (!haveV) return false;
            long base = Long.MAX_VALUE;
            for (MediaExtractor ex : exs) {
                long st = ex.getSampleTime();
                if (st >= 0) base = Math.min(base, st);
            }
            if (base == Long.MAX_VALUE) base = 0;
            mux.start();
            ByteBuffer buf = ByteBuffer.allocate(maxSize);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            for (int[] m : map) {
                MediaExtractor ex = exs.get(m[0]);
                long last = -1;
                while (true) {
                    buf.clear();
                    int sz = ex.readSampleData(buf, 0);
                    if (sz < 0) break;
                    long pts = Math.max(0, ex.getSampleTime() - base);
                    if (pts <= last) pts = last + 1;
                    last = pts;
                    info.offset = 0;
                    info.size = sz;
                    info.presentationTimeUs = pts;
                    info.flags = (ex.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0 ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                    mux.writeSampleData(m[1], buf, info);
                    ex.advance();
                }
            }
            mux.stop();
            return out.length() > 0;
        } catch (Throwable e) {
            return false;
        } finally {
            for (MediaExtractor ex : exs) ex.release();
            if (mux != null) {
                try {
                    mux.release();
                } catch (Throwable ignored) {
                }
            }
        }
    }

    /** Copies the finished file into the phone's Download folder and returns its content uri. */
    private static String publish(Context c, File f, String name, String mime) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri u = c.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (u == null) throw new Exception("Could not save file");
            try (OutputStream os = c.getContentResolver().openOutputStream(u); InputStream in = new FileInputStream(f)) {
                copy(in, os);
            }
            cv.clear();
            cv.put(MediaStore.MediaColumns.IS_PENDING, 0);
            c.getContentResolver().update(u, cv, null, null);
            return u.toString();
        }
        File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        dir.mkdirs();
        File dst = new File(dir, name);
        int k = 1;
        while (dst.exists()) {
            int dot = name.lastIndexOf('.');
            dst = new File(dir, (dot > 0 ? name.substring(0, dot) : name) + " (" + k++ + ")" + (dot > 0 ? name.substring(dot) : ""));
        }
        try (OutputStream os = new FileOutputStream(dst); InputStream in = new FileInputStream(f)) {
            copy(in, os);
        }
        MediaScannerConnection.scanFile(c, new String[]{dst.getPath()}, new String[]{mime}, null);
        return Uri.fromFile(dst).toString();
    }

    private static void copy(InputStream in, OutputStream os) throws Exception {
        if (os == null) throw new Exception("Could not save file");
        byte[] b = new byte[65536];
        int n;
        while ((n = in.read(b)) > 0) os.write(b, 0, n);
    }

    /* ------------------------------------------------------------------ */
    /* Progress + notifications                                           */
    /* ------------------------------------------------------------------ */

    private static void tick(Context app, Task t, boolean notify) {
        long now = System.currentTimeMillis();
        if (t.lastTime == 0) {
            t.lastTime = now;
            t.lastGot = t.got;
        } else if (now - t.lastTime >= 1000) {
            t.speed = (t.got - t.lastGot) * 1000 / (now - t.lastTime);
            t.lastTime = now;
            t.lastGot = t.got;
            if (notify) progressNote(app, t);
            post(t);
        }
    }

    private static void post(final Task t) {
        main.post(() -> {
            if (listener != null) listener.changed(t);
        });
    }

    static void channel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = c.getSystemService(NotificationManager.class);
            if (nm != null && nm.getNotificationChannel(CH) == null) {
                NotificationChannel ch = new NotificationChannel(CH, "Downloads", NotificationManager.IMPORTANCE_LOW);
                nm.createNotificationChannel(ch);
            }
        }
    }

    static Notification.Builder builder(Context c) {
        channel(c);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CH) : new Notification.Builder(c);
        Intent i = new Intent(c, MainActivity.class).setAction("sr.OPEN_DOWNLOADS").addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int fl = Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT : PendingIntent.FLAG_UPDATE_CURRENT;
        b.setContentIntent(PendingIntent.getActivity(c, 7, i, fl));
        b.setSmallIcon(android.R.drawable.stat_sys_download);
        return b;
    }

    private static void progressNote(Context c, Task t) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            int pct = t.segTotal > 0 ? t.segDone * 100 / t.segTotal : 0;
            Notification n = builder(c).setContentTitle(t.name).setContentText(pct + "%")
                    .setProgress(100, pct, t.segTotal == 0).setOngoing(true).setOnlyAlertOnce(true).build();
            nm.notify((int) (-t.id), n);
        } catch (Exception ignored) {
        }
    }

    private static void finishNote(Context c, Task t, boolean notify) {
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.cancel((int) (-t.id));
            if (!notify || t.status == CANCELLED) return;
            Notification.Builder b = builder(c).setContentTitle(t.name).setAutoCancel(true)
                    .setContentText(t.status == DONE ? "Download complete" : "Download failed: " + t.error);
            b.setSmallIcon(t.status == DONE ? android.R.drawable.stat_sys_download_done : android.R.drawable.stat_notify_error);
            nm.notify((int) (-t.id), b.build());
        } catch (Exception ignored) {
        }
    }
}
