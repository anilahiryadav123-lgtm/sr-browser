package com.sr.browser;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/** Keeps the app alive while streaming videos are being downloaded in the background. */
public class DlService extends Service {
    private static final int NOTE = 4242;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification n = Grabber.builder(this).setContentTitle("S.R Browser")
                .setContentText("Downloading videos...").setOngoing(true).build();
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            else startForeground(NOTE, n);
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!Grabber.active()) stopSelf();
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
