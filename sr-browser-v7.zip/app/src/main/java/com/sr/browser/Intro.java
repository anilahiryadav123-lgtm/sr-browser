package com.sr.browser;

import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * First-run intro in the same style as UC Browser:
 * 1) a pin with a light trail rises from the bottom of the screen while soft shapes float around,
 * 2) it turns into the logo in the middle of tilted orbits with coloured feature icons going round,
 * 3) the app name, slogan, agreement text and the "Agree and Continue" button fade in at the bottom.
 * All drawing is done in code with S.R Browser's red colour and logo.
 */
final class Intro extends FrameLayout {

    interface Done {
        void finish(String lang);
    }

    private static final int RED = 0xFFE5121B;
    private static final long RISE = 1500;   // pin rising
    private static final long GROW = 900;    // orbits appear

    private final Done done;
    private String lang;
    private Stage stage;
    private LinearLayout bottom;
    private TextView langChip;
    private boolean shown;

    Intro(Context c, String startLang, Done done) {
        super(c);
        this.done = done;
        this.lang = "hi".equals(startLang) ? "hi" : "en";
        setBackgroundColor(Color.WHITE);
        setClickable(true);
        stage = new Stage(c);
        addView(stage, new LayoutParams(-1, -1));
        stage.onReady = this::showBottom;
        buildBottom();
    }

    private int dp(float v) {
        return Ui.dp(getContext(), v);
    }

    private String t(String en, String hi) {
        return "hi".equals(lang) ? hi : en;
    }

    /** Back key on the intro closes the app, like UC. */
    boolean back() {
        return false;
    }

    private void buildBottom() {
        Context c = getContext();
        if (bottom != null) removeView(bottom);
        if (langChip != null) removeView(langChip);

        bottom = new LinearLayout(c);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setGravity(Gravity.CENTER_HORIZONTAL);
        bottom.setPadding(dp(28), 0, dp(28), dp(26));

        TextView name = Ui.text(c, "S.R Browser", 40, 0xFF2A2D34, false);
        name.setTypeface(Typeface.create("sans-serif-thin", Typeface.NORMAL));
        name.setGravity(Gravity.CENTER);
        bottom.addView(name);
        TextView slogan = Ui.text(c, t("Faster speed, Richer content", "तेज़ स्पीड, ज़्यादा कंटेंट"), 17, 0xFF8A90A0, false);
        slogan.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        slogan.setGravity(Gravity.CENTER);
        slogan.setPadding(0, dp(2), 0, dp(40));
        bottom.addView(slogan);

        TextView terms = terms();
        terms.setPadding(0, 0, 0, dp(16));
        bottom.addView(terms, new LinearLayout.LayoutParams(-1, -2));

        final TextView go = Ui.text(c, t("Agree and Continue", "सहमत हैं, आगे बढ़ें"), 17, Color.WHITE, true);
        go.setGravity(Gravity.CENTER);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xFFFF4B2B, RED});
        g.setCornerRadius(dp(27));
        go.setBackground(g);
        go.setElevation(dp(2));
        go.setOnClickListener(v -> {
            go.setEnabled(false);
            animate().alpha(0f).setDuration(260).withEndAction(() -> done.finish(lang)).start();
        });
        bottom.addView(go, new LinearLayout.LayoutParams(dp(280), dp(54)));
        addView(bottom, new LayoutParams(-1, -2, Gravity.BOTTOM));

        langChip = Ui.text(c, ("hi".equals(lang) ? "हिन्दी" : "English") + "  ▾", 14, 0xFF3B4150, true);
        langChip.setPadding(dp(14), dp(8), dp(14), dp(8));
        GradientDrawable lg = new GradientDrawable();
        lg.setCornerRadius(dp(18));
        lg.setColor(0xFFF2F3F6);
        langChip.setBackground(lg);
        langChip.setOnClickListener(v -> new AlertDialog.Builder(getContext())
                .setTitle("Language / भाषा")
                .setSingleChoiceItems(new String[]{"English", "हिन्दी"}, "hi".equals(lang) ? 1 : 0, (d, which) -> {
                    lang = which == 1 ? "hi" : "en";
                    d.dismiss();
                    buildBottom();
                }).show());
        LayoutParams lp = new LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        lp.topMargin = dp(16);
        lp.rightMargin = dp(16);
        addView(langChip, lp);

        if (!shown) {
            bottom.setAlpha(0f);
            bottom.setTranslationY(dp(30));
            langChip.setAlpha(0f);
        }
    }

    private void showBottom() {
        shown = true;
        bottom.animate().alpha(1f).translationY(0).setDuration(600).setInterpolator(new DecelerateInterpolator()).start();
        langChip.animate().alpha(1f).setDuration(600).start();
    }

    private TextView terms() {
        final String ua = t("User Agreement", "यूज़र एग्रीमेंट");
        final String pp = t("Privacy Policy", "प्राइवेसी पॉलिसी");
        String full = "hi".equals(lang)
                ? "आगे बढ़कर आप S.R Browser के " + ua + " और " + pp + " को स्वीकार करते हैं।"
                : "By tapping Agree and Continue, you accept the " + ua + " and " + pp + ".";
        SpannableString ss = new SpannableString(full);
        link(ss, full, ua, () -> info(getContext(), lang, true));
        link(ss, full, pp, () -> info(getContext(), lang, false));
        TextView tv = Ui.text(getContext(), "", 12.5f, 0xFF8A90A0, false);
        tv.setText(ss);
        tv.setGravity(Gravity.CENTER);
        tv.setMovementMethod(LinkMovementMethod.getInstance());
        tv.setHighlightColor(Color.TRANSPARENT);
        return tv;
    }

    private static void link(SpannableString ss, String full, String word, final Runnable r) {
        int s = full.indexOf(word);
        if (s < 0) return;
        ss.setSpan(new ClickableSpan() {
            @Override
            public void onClick(View w) {
                r.run();
            }

            @Override
            public void updateDrawState(TextPaint p) {
                p.setColor(RED);
                p.setUnderlineText(false);
                p.setFakeBoldText(true);
            }
        }, s, s + word.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    /** User Agreement / Privacy Policy text, used here and in Settings. */
    static void info(Context c, String lang, boolean agreement) {
        boolean hi = "hi".equals(lang);
        String title = agreement ? (hi ? "यूज़र एग्रीमेंट" : "User Agreement") : (hi ? "प्राइवेसी पॉलिसी" : "Privacy Policy");
        String msg = agreement
                ? (hi ? "S.R Browser मुफ़्त है। कृपया इसे ज़िम्मेदारी से इस्तेमाल करें और जिन वेबसाइट पर जाएं उनके नियम मानें। सिर्फ़ वही वीडियो और फ़ाइलें डाउनलोड करें जिनकी आपको अनुमति है। डाउनलोड आपके फ़ोन में सेव होते हैं और उनकी ज़िम्मेदारी आपकी है।"
                : "S.R Browser is free to use. Please use it responsibly and follow the rules of the websites you visit. Only download videos and files you have the right to save. Downloads are stored on your phone and you are responsible for them.")
                : (hi ? "S.R Browser आपकी हिस्ट्री, बुकमार्क, नोट्स, डाउनलोड लिस्ट और सेटिंग्स सिर्फ़ इसी फ़ोन में रखता है। हम आपका डेटा नहीं बेचते और किसी सर्वर पर नहीं भेजते। इन्कॉग्निटो मोड में हिस्ट्री सेव नहीं होती। सब कुछ सेटिंग्स > रिकॉर्ड साफ़ करें से हटा सकते हैं।"
                : "S.R Browser keeps your history, bookmarks, notes, download list and settings only on this phone. We do not sell your data or send it to any server. Incognito mode does not save history. You can clear everything from Settings > Clear Records.");
        new AlertDialog.Builder(c).setTitle(title).setMessage(msg).setPositiveButton(hi ? "ठीक है" : "OK", null).show();
    }

    /* ------------------------------------------------------------------ */
    /* The animated scene                                                 */
    /* ------------------------------------------------------------------ */

    static final class Stage extends View {
        Runnable onReady;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rf = new RectF();
        private final Rect r = new Rect();
        private final Path path = new Path();
        private final float dens;
        private Bitmap logo;
        private ValueAnimator loop;
        private long start;
        private boolean readySent;

        // Feature icons going round: icon, colour from, colour to, orbit, start angle, size
        private final int[] icons = {R.drawable.ic_video, R.drawable.ic_search, R.drawable.ic_notes,
                R.drawable.ic_download, R.drawable.ic_cloud, R.drawable.ic_star};
        private final int[][] colors = {{0xFFFF3D7F, 0xFFFF6FB5}, {0xFFE8455B, 0xFFFF8A4C}, {0xFFFFB300, 0xFFFFD84D},
                {0xFF1E88E5, 0xFF4FC3F7}, {0xFF7E7FB8, 0xFF9AA5D6}, {0xFF7C4DFF, 0xFFB388FF}};
        private final int[] orbitOf = {2, 1, 2, 0, 1, 2};
        private final float[] startAngle = {-100, 200, 160, 10, -15, 60};
        private final float[] sizeOf = {0.13f, 0.10f, 0.155f, 0.088f, 0.115f, 0.10f};
        private final Drawable[] dr = new Drawable[icons.length];
        private Shader[] shaders;
        private Shader centre, trail;

        // Faint floating shapes for the rising part
        private final float[][] confetti = {
                {0.28f, 0.10f, 0, 0xFFE6F7FD}, {0.80f, 0.19f, 0, 0xFFFFFFE8}, {0.18f, 0.37f, 2, 0xFFFFEFEF},
                {0.77f, 0.37f, 1, 0xFFFFFAEB}, {0.80f, 0.55f, 0, 0xFFFFF5F6}, {0.12f, 0.62f, 0, 0xFFFFF5F6},
                {0.29f, 0.70f, 1, 0xFFF0FFF0}, {0.10f, 0.84f, 0, 0xFFFFF5F6}, {0.41f, 0.32f, 3, 0xFFDDF5FC},
                {0.54f, 0.83f, 3, 0xFFDDF5FC}, {0.37f, 0.55f, 4, 0xFFFFC52E}, {0.56f, 0.58f, 4, 0xFFFFC52E},
                {0.60f, 0.61f, 4, 0xFFFFC52E}, {0.35f, 0.63f, 4, 0xFFFFC52E}, {0.89f, 0.47f, 3, 0xFFE3FBE6},
        };

        Stage(Context c) {
            super(c);
            dens = c.getResources().getDisplayMetrics().density;
            for (int i = 0; i < icons.length; i++) {
                dr[i] = c.getDrawable(icons[i]).mutate();
                dr[i].setTint(Color.WHITE);
            }
            try {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inSampleSize = 2;
                logo = BitmapFactory.decodeResource(c.getResources(), R.drawable.intro_logo, o);
            } catch (Throwable ignored) {
            }
            line.setStyle(Paint.Style.STROKE);
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            start = System.currentTimeMillis();
            loop = ValueAnimator.ofFloat(0f, 1f);
            loop.setDuration(10000);
            loop.setRepeatCount(ValueAnimator.INFINITE);
            loop.setInterpolator(new LinearInterpolator());
            loop.addUpdateListener(a -> invalidate());
            loop.start();
        }

        @Override
        protected void onDetachedFromWindow() {
            if (loop != null) loop.cancel();
            loop = null;
            super.onDetachedFromWindow();
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            float base = Math.min(w, h * 0.6f);
            shaders = new Shader[icons.length];
            for (int i = 0; i < icons.length; i++) {
                float s = base * sizeOf[i] / 2f;
                shaders[i] = new LinearGradient(-s, -s, s, s, colors[i][0], colors[i][1], Shader.TileMode.CLAMP);
            }
            float cr = base * 0.13f;
            centre = new LinearGradient(-cr, -cr, cr, cr, 0xFFFF4B2B, 0xFFC70F18, Shader.TileMode.CLAMP);
            trail = new LinearGradient(0, 0, 0, h * 0.3f, RED, 0x00E5121B, Shader.TileMode.CLAMP);
        }

        private static float ease(float t) {
            t = Math.max(0f, Math.min(1f, t));
            return 1f - (1f - t) * (1f - t) * (1f - t);
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight();
            if (w == 0 || shaders == null) return;
            long el = System.currentTimeMillis() - start;
            float cx = w / 2f, cy = h * 0.36f;
            float base = Math.min(w, h * 0.6f);

            // 1) Rising pin with a trail, soft shapes around it
            float rise = ease(el / (float) RISE);
            float grow = ease((el - RISE * 0.75f) / (float) GROW);
            float fadeA = 1f - Math.max(0f, Math.min(1f, (el - RISE * 0.7f) / 400f));
            if (fadeA > 0) {
                for (float[] c : confetti) {
                    float drift = (float) Math.sin((el / 900.0) + c[0] * 9) * 6 * dens;
                    float x = c[0] * w, y = c[1] * h + drift - rise * 40 * dens;
                    int col = (int) c[3];
                    p.setColor(col);
                    p.setAlpha((int) (255 * fadeA * Math.min(1f, el / 300f)));
                    p.setStyle(Paint.Style.FILL);
                    float s = 22 * dens;
                    switch ((int) c[2]) {
                        case 0: // square
                            cv.drawRect(x - s, y - s, x + s, y + s, p);
                            break;
                        case 1: // triangle
                            path.reset();
                            path.moveTo(x, y - s);
                            path.lineTo(x + s, y + s * 0.8f);
                            path.lineTo(x - s, y + s * 0.8f);
                            path.close();
                            cv.drawPath(path, p);
                            break;
                        case 2: // ring
                            p.setStyle(Paint.Style.STROKE);
                            p.setStrokeWidth(9 * dens);
                            cv.drawCircle(x, y, 13 * dens, p);
                            break;
                        case 3: // cross
                            p.setStyle(Paint.Style.STROKE);
                            p.setStrokeWidth(9 * dens);
                            p.setStrokeCap(Paint.Cap.ROUND);
                            cv.drawLine(x - 10 * dens, y + 6 * dens, x + 10 * dens, y - 6 * dens, p);
                            cv.drawLine(x - 4 * dens, y - 10 * dens, x + 4 * dens, y + 10 * dens, p);
                            break;
                        default: // small plus
                            p.setStyle(Paint.Style.STROKE);
                            p.setStrokeWidth(2.5f * dens);
                            p.setStrokeCap(Paint.Cap.ROUND);
                            cv.drawLine(x - 7 * dens, y, x + 7 * dens, y, p);
                            cv.drawLine(x, y - 7 * dens, x, y + 7 * dens, p);
                    }
                }
                p.setStyle(Paint.Style.FILL);
                p.setStrokeCap(Paint.Cap.BUTT);
                // pin
                float py = h + 20 * dens - (h + 20 * dens - cy) * rise;
                float tail = h * 0.3f;
                cv.save();
                cv.translate(cx, py);
                p.setShader(trail);
                p.setAlpha((int) (255 * fadeA));
                cv.drawRect(-3 * dens, 0, 3 * dens, tail, p);
                p.setShader(null);
                cv.restore();
                p.setColor(RED);
                p.setAlpha((int) (255 * fadeA));
                cv.drawCircle(cx, py, 16 * dens, p);
                p.setColor(Color.WHITE);
                p.setAlpha((int) (255 * fadeA));
                cv.drawCircle(cx, py, 7 * dens, p);
                p.setAlpha(255);
            }

            if (grow <= 0) return;

            // 2) Tilted orbits
            float[] rx = {base * 0.36f, base * 0.52f, base * 0.70f};
            float[] ry = {base * 0.17f, base * 0.27f, base * 0.37f};
            float tilt = 22f;
            cv.save();
            cv.rotate(tilt, cx, cy);
            line.setColor(0xFFCFD2D8);
            line.setStrokeWidth(1.2f * dens);
            line.setAlpha((int) (255 * grow));
            for (int i = 0; i < 3; i++) {
                float k = 0.6f + 0.4f * grow;
                rf.set(cx - rx[i] * k, cy - ry[i] * k, cx + rx[i] * k, cy + ry[i] * k);
                cv.drawOval(rf, line);
            }
            cv.restore();

            // little dots and triangles
            float t = el / 1000f;
            int[] dotCol = {0xFFC9A7F0, 0xFF7A8FE8, 0xFFA9C8F5, 0xFFFFC89A, 0xFFA3A7C9};
            for (int i = 0; i < dotCol.length; i++) {
                double a = Math.toRadians(i * 72 + t * 8);
                float o = i % 2 == 0 ? 1 : 2;
                float x = cx + (float) Math.cos(a) * rx[(int) o] * 1.02f, y = cy + (float) Math.sin(a) * ry[(int) o] * 1.02f;
                float[] pt = rot(x, y, cx, cy, tilt);
                p.setColor(dotCol[i]);
                p.setAlpha((int) (255 * grow));
                cv.drawCircle(pt[0], pt[1], (3 + i % 3) * dens, p);
            }

            // 3) Icons going round (back half first so the centre covers them)
            for (int pass = 0; pass < 2; pass++) {
                for (int i = 0; i < icons.length; i++) {
                    int o = orbitOf[i];
                    double a = Math.toRadians(startAngle[i] + t * (14 - o * 3));
                    boolean front = Math.sin(a) > 0;
                    if ((pass == 0) == front) continue;
                    float k = 0.6f + 0.4f * grow;
                    float x = cx + (float) Math.cos(a) * rx[o] * k, y = cy + (float) Math.sin(a) * ry[o] * k;
                    float[] pt = rot(x, y, cx, cy, tilt);
                    float s = base * sizeOf[i] / 2f * (0.85f + 0.15f * (float) Math.sin(a)) * grow;
                    cv.save();
                    cv.translate(pt[0], pt[1]);
                    p.setShader(shaders[i]);
                    p.setAlpha(255);
                    p.setShadowLayer(6 * dens, 0, 3 * dens, 0x22000000);
                    cv.drawCircle(0, 0, s, p);
                    p.clearShadowLayer();
                    p.setShader(null);
                    int ir = (int) (s * 0.52f);
                    r.set(-ir, -ir, ir, ir);
                    dr[i].setBounds(r);
                    dr[i].draw(cv);
                    cv.restore();
                }
                if (pass == 0) drawCentre(cv, cx, cy, base, grow);
            }

            if (!readySent && el > RISE + GROW * 0.6f) {
                readySent = true;
                if (onReady != null) post(onReady);
            }
        }

        private void drawCentre(Canvas cv, float cx, float cy, float base, float grow) {
            float cr = base * 0.13f * (0.5f + 0.5f * grow) * 1.0f;
            cv.save();
            cv.translate(cx, cy);
            float bob = (float) Math.sin((System.currentTimeMillis() - start) / 700.0) * 2 * dens;
            cv.translate(0, bob);
            p.setShader(centre);
            p.setShadowLayer(14 * dens, 0, 6 * dens, 0x55C70F18);
            cv.drawCircle(0, 0, cr, p);
            p.clearShadowLayer();
            p.setShader(null);
            p.setColor(Color.WHITE);
            cv.drawCircle(0, 0, cr * 0.82f, p);
            if (logo != null) {
                float lr = cr * 0.74f;
                rf.set(-lr, -lr, lr, lr);
                cv.drawBitmap(logo, null, rf, p);
            }
            cv.restore();
        }

        private static float[] rot(float x, float y, float cx, float cy, float deg) {
            double a = Math.toRadians(deg);
            float dx = x - cx, dy = y - cy;
            return new float[]{cx + (float) (dx * Math.cos(a) - dy * Math.sin(a)), cy + (float) (dx * Math.sin(a) + dy * Math.cos(a))};
        }
    }
}
