# S.R Browser 1.6 (Android) - Made in India
WebView browser with UC style screens: welcome, home, 5-icon menu, tab switcher, history (Video/Website),
downloader, notes, settings list, theme zone, ad block, Hindi/English.
Official logos (optional): app/src/main/assets/engines/google.png and app/src/main/assets/icons/yt.png etc.

New in 1.5: UC style first-run intro (language, animated feature slides, Skip, Agree & Continue),
UC style downloads (Downloading/Downloaded tabs, categories, live progress + speed, storage bar,
rename before download, Wi-Fi only), grouped UC style settings, and download-complete pop-up.

New in 1.6: UC style launch splash + welcome page (Agree and Continue, language switch), default browser
offer and first-run tips; red download button on videos with a Fast Download quality sheet (MP4 and
streaming m3u8 videos, saved as MP4); history grouped by day with search; full UC style settings
(font size slider, gestures, rotation, keep screen on, PiP, background play, privacy, site permissions...).
